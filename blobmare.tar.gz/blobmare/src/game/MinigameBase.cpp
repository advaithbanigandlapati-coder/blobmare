#include "game/MinigameBase.h"
#include "core/GameContext.h"
#include "raymath.h"
#include <cmath>

void MinigameBase::setup(GameContext& ctx, std::vector<Blob*>& blobs) {
    world_.clear();
    finished_ = false;
    result_ = MinigameResult{};
    elapsed_ = 0.0f;
    onSetup(ctx, blobs);
}

void MinigameBase::update(GameContext& ctx, std::vector<Blob*>& blobs,
                          float dt, bool inputEnabled) {
    if (inputEnabled && !finished_) elapsed_ += dt;
    onUpdate(ctx, blobs, dt);
}

void MinigameBase::draw3D(GameContext& ctx, std::vector<Blob*>& blobs) {
    onDraw3D(ctx, blobs);
}

void MinigameBase::drawHUD(GameContext& ctx, std::vector<Blob*>& blobs) {
    onDrawHUD(ctx, blobs);
}

void MinigameBase::win(int blobId) {
    if (finished_) return;
    finished_ = true;
    result_.draw = false;
    result_.winner = blobId;
}

void MinigameBase::declareDraw() {
    if (finished_) return;
    finished_ = true;
    result_.draw = true;
    result_.winner = -1;
}

bool MinigameBase::resolveLastStanding(std::vector<Blob*>& blobs) {
    if (finished_) return true;
    int aliveCount = 0, aliveId = -1;
    for (Blob* b : blobs) {
        if (b->alive()) { ++aliveCount; aliveId = b->id(); }
    }
    if (aliveCount == 1) { win(aliveId); return true; }
    if (aliveCount == 0) { declareDraw(); return true; }
    return false;
}

void MinigameBase::resolveByScore(int s0, int s1) {
    result_.score[0] = s0;
    result_.score[1] = s1;
    if (s0 == s1) declareDraw();
    else          win(s0 > s1 ? 0 : 1);
}

void MinigameBase::blobBump(GameContext& ctx, std::vector<Blob*>& blobs,
                            float restitution) {
    if (blobs.size() < 2) return;
    Blob* a = blobs[0];
    Blob* b = blobs[1];
    Vector3 pa = a->position(), pb = b->position();
    Vector3 d = Vector3Subtract(pb, pa);
    d.y *= 0.5f;  // bias toward horizontal so blobs don't pop over each other
    float dist = Vector3Length(d);
    float minDist = a->radius() + b->radius();
    if (dist >= minDist || dist < 1e-4f) return;

    Vector3 n = Vector3Scale(d, 1.0f / dist);
    float overlap = minDist - dist;

    // Positional separation, split by mass.
    float ma = a->tuning().mass, mb = b->tuning().mass;
    float wa = mb / (ma + mb), wb = ma / (ma + mb);
    a->setPosition(Vector3Subtract(pa, Vector3Scale(n, overlap * wa)));
    b->setPosition(Vector3Add(pb,      Vector3Scale(n, overlap * wb)));

    // Exchange velocity along the contact normal (elastic-ish).
    Vector3 va = a->velocity(), vb = b->velocity();
    float relVel = Vector3DotProduct(Vector3Subtract(vb, va), n);
    if (relVel < 0.0f) {
        float j = -(1.0f + restitution) * relVel / (1.0f/ma + 1.0f/mb);
        Vector3 imp = Vector3Scale(n, j);
        a->addImpulse(Vector3Negate(imp));
        b->addImpulse(imp);
        // Feedback on a solid hit.
        if (-relVel > 4.0f) {
            ctx.shake.add(0.18f);
            Vector3 mid = Vector3Lerp(pa, pb, 0.5f);
            ctx.particles.impact(mid, n, 10, Color{255,230,180,255});
            ctx.audio.play(Sfx::Bounce, 0.6f, 0.12f);
        }
    }
}
