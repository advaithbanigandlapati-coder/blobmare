#include "game/Minigame.h"
#include "blob/Blob.h"

std::vector<Vector3> Minigame::cameraTargets(std::vector<Blob*>& blobs) const {
    std::vector<Vector3> pts;
    pts.reserve(blobs.size());
    for (Blob* b : blobs) {
        // Dead blobs still count for framing so the camera doesn't snap.
        pts.push_back(b->position());
    }
    return pts;
}
