#pragma once
// MinigameBase provides the boilerplate every minigame shares: a physics
// World, a countdown-aware timer, and result bookkeeping. Concrete minigames
// override the small hooks (onSetup / onUpdate / onDraw3D / onDrawHUD).
//
// This keeps each individual minigame file short and focused on its unique
// rules, which is what makes a 40-strong pool maintainable.
#include "game/Minigame.h"
#include "physics/World.h"
#include "blob/Blob.h"
#include <vector>

class MinigameBase : public Minigame {
public:
    // --- Minigame interface (mostly sealed; minigames use the hooks) -----
    void setup(GameContext& ctx, std::vector<Blob*>& blobs) final;
    void update(GameContext& ctx, std::vector<Blob*>& blobs,
                float dt, bool inputEnabled) final;
    void draw3D(GameContext& ctx, std::vector<Blob*>& blobs) final;
    void drawHUD(GameContext& ctx, std::vector<Blob*>& blobs) final;
    bool finished() const final { return finished_; }
    MinigameResult result() const final { return result_; }
    World* physicsWorld() final { return &world_; }

protected:
    // --- Hooks for concrete minigames ------------------------------------
    virtual void onSetup(GameContext& ctx, std::vector<Blob*>& blobs) = 0;
    virtual void onUpdate(GameContext& ctx, std::vector<Blob*>& blobs,
                          float dt) = 0;
    virtual void onDraw3D(GameContext& ctx, std::vector<Blob*>& blobs) = 0;
    virtual void onDrawHUD(GameContext& ctx, std::vector<Blob*>& blobs) {
        (void)ctx; (void)blobs;
    }

    // --- Helpers for concrete minigames ----------------------------------
    World& world() { return world_; }
    float  elapsed() const { return elapsed_; }   // play-time, excludes countdown

    // Finish the minigame with a specific winner / draw.
    void win(int blobId);
    void declareDraw();
    // Resolve by elimination: if exactly one blob is alive, it wins; if none,
    // it's a draw. Returns true if the game ended.
    bool resolveLastStanding(std::vector<Blob*>& blobs);
    // Resolve by score with a tie -> draw.
    void resolveByScore(int s0, int s1);

    // Standard blob-vs-blob soft collision (squishy bump). Call each step.
    void blobBump(GameContext& ctx, std::vector<Blob*>& blobs,
                  float restitution = 0.6f);

private:
    World world_;
    bool   finished_ = false;
    MinigameResult result_{};
    float  elapsed_ = 0.0f;
};
