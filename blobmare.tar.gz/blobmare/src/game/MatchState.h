#pragma once
// MatchState holds everything about an in-progress match that must survive
// scene switches (Hub <-> Match <-> Results): the random slate of minigames,
// the per-player score, and which minigame is up next.
//
// It lives inside GameContext so every scene can read and advance it.
#include <vector>
#include <cstdint>

struct MatchState {
    std::vector<int> slate;       // registry indices, one per minigame
    int   index   = 0;            // which slate entry is next / current
    int   score[2]= { 0, 0 };     // round wins per player
    int   lastWinner = -1;        // winner of the most recent minigame (-1 draw)
    bool  lastWasDraw = false;
    uint64_t seed = 0;

    void reset() {
        slate.clear();
        index = 0;
        score[0] = score[1] = 0;
        lastWinner = -1;
        lastWasDraw = false;
        isSuddenDeath = false;
    }

    bool hasMoreMinigames() const { return index < (int)slate.size(); }

    // The match ends when either a player reaches the round target, OR the
    // slate is exhausted AND there is a clear leader. If the slate runs out
    // on a TIE, the match is NOT over — a sudden-death round is appended.
    bool matchOver(int target) const {
        if (score[0] >= target || score[1] >= target) return true;
        if (hasMoreMinigames()) return false;
        return leader() != -1;          // slate done: over only if not tied
    }

    // True when the slate is spent but the score is level — the caller
    // should append one more (sudden-death) minigame to the slate.
    bool needsTiebreaker() const {
        return !hasMoreMinigames() && leader() == -1;
    }

    int leader() const {
        if (score[0] > score[1]) return 0;
        if (score[1] > score[0]) return 1;
        return -1; // tie
    }

    bool isSuddenDeath = false;   // set true while a tiebreaker round is live
};
