#include "game/MinigameRegistry.h"
#include <random>
#include <algorithm>
#include <numeric>

MinigameRegistry& MinigameRegistry::instance() {
    static MinigameRegistry reg;
    return reg;
}

void MinigameRegistry::add(MinigameFactory factory) {
    // Construct one probe instance to capture its static metadata. The probe
    // is discarded immediately; setup() is never called on it.
    MinigameInfo info = factory()->info();
    entries_.push_back(MinigameEntry{ info, std::move(factory) });
}

std::vector<int> MinigameRegistry::drawSlate(int n, uint64_t seed) const {
    std::vector<int> slate;
    if (entries_.empty() || n <= 0) return slate;

    std::mt19937_64 rng(seed);

    // Pool of all indices, shuffled.
    std::vector<int> pool(entries_.size());
    std::iota(pool.begin(), pool.end(), 0);
    std::shuffle(pool.begin(), pool.end(), rng);

    // Take distinct entries first.
    int take = std::min<int>(n, (int)pool.size());
    slate.assign(pool.begin(), pool.begin() + take);

    // If the pool is smaller than n, top up with more shuffled draws so the
    // match still gets a full slate (avoids back-to-back repeats where it can).
    while ((int)slate.size() < n) {
        std::shuffle(pool.begin(), pool.end(), rng);
        for (int idx : pool) {
            if ((int)slate.size() >= n) break;
            if (!slate.empty() && slate.back() == idx) continue; // no immediate repeat
            slate.push_back(idx);
        }
    }
    return slate;
}
