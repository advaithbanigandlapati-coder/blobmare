#pragma once
// The Minigame contract. Every one of the (up to 40) minigames is a class
// implementing this interface. The MatchScene owns the lifecycle:
//
//   construct -> setup() -> [ countdown ] -> update()* -> finished() true
//             -> result()  -> destruct
//
// A minigame NEVER touches global state directly: it receives blobs and the
// shared GameContext and reports a result. This is what makes the pool of 40
// trivially extensible — add a class, register it, done.
#include "raylib.h"
#include <vector>
#include <string>

class Blob;
class World;
struct GameContext;

// How a minigame decides who won.
enum class WinKind {
    LastStanding,   // survive longest (elimination)
    FirstToGoal,    // reach the objective first (race)
    HighScore,      // most points when time runs out
    Survival,       // everyone alive at timeout wins (co-op-ish vs hazard)
};

struct MinigameResult {
    bool   draw = false;          // true -> no points awarded
    int    winner = -1;           // blob id of the winner (if !draw)
    int    score[2] = { 0, 0 };   // optional display scores
};

// Static metadata used by menus and the "next minigame" splash.
struct MinigameInfo {
    std::string name;
    std::string tagline;     // one-line flavour
    std::string howTo;       // short control hint shown on the splash
    WinKind     winKind = WinKind::LastStanding;
};

class Minigame {
public:
    virtual ~Minigame() = default;

    // One-time setup: build the arena, place blobs at spawn points.
    // 'blobs' are the live player blobs; the minigame may move them.
    virtual void setup(GameContext& ctx, std::vector<Blob*>& blobs) = 0;

    // Fixed-step simulation. 'dt' is already scaled. 'inputEnabled' is false
    // during the pre-round countdown. Returns nothing; report status via
    // finished()/result().
    virtual void update(GameContext& ctx, std::vector<Blob*>& blobs,
                        float dt, bool inputEnabled) = 0;

    // Draw the 3D arena. Called inside BeginMode3D. Blobs are drawn by the
    // MatchScene, not here — but minigames draw their own props/hazards.
    virtual void draw3D(GameContext& ctx, std::vector<Blob*>& blobs) = 0;

    // Draw any minigame-specific 2D HUD (scores, objective markers).
    virtual void drawHUD(GameContext& ctx, std::vector<Blob*>& blobs) = 0;

    // True once a winner (or draw) has been decided.
    virtual bool finished() const = 0;
    virtual MinigameResult result() const = 0;

    // Metadata for menus / splash screens.
    virtual MinigameInfo info() const = 0;

    // Suggested time limit in seconds (the MatchScene shows a clock and can
    // force-resolve on timeout). Return <= 0 for "no clock".
    virtual float timeLimit() const { return 0.0f; }

    // Camera targets for this minigame. Default: follow all blobs.
    virtual std::vector<Vector3> cameraTargets(std::vector<Blob*>& blobs) const;

    // The physics World this minigame simulates in, if any. Networking's
    // client-side predictor needs it to re-simulate the local blob. Returns
    // nullptr for a minigame with no standard World. MinigameBase overrides
    // this; bespoke minigames may leave it null.
    virtual World* physicsWorld() { return nullptr; }
};
