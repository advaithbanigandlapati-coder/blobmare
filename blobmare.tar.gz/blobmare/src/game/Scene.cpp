#include "game/Scene.h"
#include "core/GameContext.h"
#include "core/UIText.h"

#include "scenes/SplashScene.h"
#include "scenes/TitleScene.h"
#include "scenes/MenuScene.h"
#include "scenes/LobbyScene.h"
#include "scenes/EditorScene.h"
#include "scenes/HubScene.h"
#include "scenes/MatchScene.h"
#include "scenes/ResultsScene.h"

#include <cmath>

std::unique_ptr<Scene> SceneManager::makeScene(SceneId id) {
    switch (id) {
        case SceneId::Splash:  return std::make_unique<SplashScene>();
        case SceneId::Title:   return std::make_unique<TitleScene>();
        case SceneId::Menu:    return std::make_unique<MenuScene>();
        case SceneId::Lobby:   return std::make_unique<LobbyScene>();
        case SceneId::Editor:  return std::make_unique<EditorScene>();
        case SceneId::Hub:     return std::make_unique<HubScene>();
        case SceneId::Match:   return std::make_unique<MatchScene>();
        case SceneId::Results: return std::make_unique<ResultsScene>();
        case SceneId::Quit:    return nullptr;
    }
    return nullptr;
}

void SceneManager::start(GameContext& ctx, SceneId first) {
    currentId_ = pendingId_ = first;
    scene_ = makeScene(first);
    if (scene_) scene_->enter(ctx, *this);
    phase_ = Phase::FadeIn;
    fade_  = 1.0f;
}

void SceneManager::requestSwitch(SceneId next) {
    if (phase_ != Phase::Idle) return;     // ignore during a transition
    if (next == currentId_)    return;
    pendingId_ = next;
    phase_ = Phase::FadeOut;
}

void SceneManager::doSwitch(GameContext& ctx) {
    if (scene_) scene_->exit(ctx);

    if (pendingId_ == SceneId::Quit) {
        ctx.quitRequested = true;
        return;
    }
    currentId_ = pendingId_;
    scene_ = makeScene(currentId_);
    if (scene_) scene_->enter(ctx, *this);
}

void SceneManager::update(GameContext& ctx, float dt) {
    switch (phase_) {
        case Phase::Idle:
            if (scene_) scene_->update(ctx, *this, dt);
            break;
        case Phase::FadeOut:
            fade_ += kFadeSpeed * dt;
            if (fade_ >= 1.0f) {
                fade_ = 1.0f;
                doSwitch(ctx);
                if (ctx.quitRequested) return;
                phase_ = Phase::FadeIn;
            }
            break;
        case Phase::FadeIn:
            fade_ -= kFadeSpeed * dt;
            if (fade_ <= 0.0f) { fade_ = 0.0f; phase_ = Phase::Idle; }
            // Let the new scene tick while fading in so it feels alive.
            if (scene_) scene_->update(ctx, *this, dt);
            break;
    }
}

void SceneManager::releaseScene(GameContext& ctx) {
    if (scene_) {
        scene_->exit(ctx);
        scene_.reset();
    }
}

void SceneManager::draw(GameContext& ctx) {
    if (scene_) scene_->draw(ctx);

    if (fade_ > 0.001f) {
        unsigned char a = (unsigned char)(255.0f * (fade_ > 1.0f ? 1.0f : fade_));
        DrawRectangle(0, 0, ctx.screenW, ctx.screenH, Color{0, 0, 0, a});
    }
}
