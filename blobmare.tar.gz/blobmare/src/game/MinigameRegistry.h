#pragma once
// The MinigameRegistry is the heart of the "40 minigames, pick 5" design.
//
// Every minigame self-registers a factory + its metadata. The registry can
// then (a) list everything for menus and (b) draw a random, non-repeating
// subset for a match. Growing the pool to 40 needs nothing more than writing
// a class and adding one REGISTER_MINIGAME line — no changes here, no changes
// in the match code.
#include "game/Minigame.h"
#include <functional>
#include <memory>
#include <vector>
#include <string>
#include <cstdint>

using MinigameFactory = std::function<std::unique_ptr<Minigame>()>;

struct MinigameEntry {
    MinigameInfo    info;
    MinigameFactory factory;
};

class MinigameRegistry {
public:
    static MinigameRegistry& instance();

    // Called by the REGISTER_MINIGAME macro at static-init time. The info is
    // captured by constructing one probe instance and asking it.
    void add(MinigameFactory factory);

    int  count() const { return (int)entries_.size(); }
    const MinigameEntry& at(int i) const { return entries_[i]; }

    std::unique_ptr<Minigame> create(int i) const { return entries_[i].factory(); }

    // Draw 'n' distinct minigame indices at random (seeded). If the pool has
    // fewer than 'n' entries, indices repeat to fill the requested count so a
    // match always has a full slate even early in development.
    std::vector<int> drawSlate(int n, uint64_t seed) const;

private:
    MinigameRegistry() = default;
    std::vector<MinigameEntry> entries_;
};

// --- Registration helper ---------------------------------------------------
// Usage at file scope in a minigame .cpp:
//   REGISTER_MINIGAME(SumoSmash);
struct MinigameRegistrar {
    explicit MinigameRegistrar(MinigameFactory f) {
        MinigameRegistry::instance().add(std::move(f));
    }
};

#define REGISTER_MINIGAME(ClassName)                                     \
    static MinigameRegistrar s_reg_##ClassName{                          \
        []() -> std::unique_ptr<Minigame> {                              \
            return std::make_unique<ClassName>();                        \
        }                                                                \
    }
