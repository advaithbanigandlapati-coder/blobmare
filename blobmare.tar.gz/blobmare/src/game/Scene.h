#pragma once
// Scene framework. The whole game is a small set of scenes:
//   TitleScene -> MenuScene -> HubScene <-> MatchScene -> ResultsScene
// SceneManager owns exactly one active scene and animates fade-to-black
// transitions between them. Scenes request a switch via the manager.
#include "raylib.h"
#include <memory>

struct GameContext;
class SceneManager;

enum class SceneId {
    Splash, Title, Menu, Lobby, Editor, Hub, Match, Results, Quit
};

class Scene {
public:
    virtual ~Scene() = default;
    virtual void enter(GameContext& ctx, SceneManager& mgr) { (void)ctx; (void)mgr; }
    virtual void exit(GameContext& ctx)  { (void)ctx; }
    virtual void update(GameContext& ctx, SceneManager& mgr, float dt) = 0;
    virtual void draw(GameContext& ctx) = 0;       // 2D + owns its 3D passes
};

class SceneManager {
public:
    void start(GameContext& ctx, SceneId first);
    void update(GameContext& ctx, float dt);
    void draw(GameContext& ctx);

    // Request a transition; takes effect after the fade-out.
    void requestSwitch(SceneId next);

    SceneId current() const { return currentId_; }
    bool transitioning() const { return phase_ != Phase::Idle; }

    // Destroy the active scene now (and thus its Blobs and their GPU meshes).
    // Call before tearing down the GL context at shutdown.
    void releaseScene(GameContext& ctx);

private:
    enum class Phase { Idle, FadeOut, FadeIn };

    std::unique_ptr<Scene> makeScene(SceneId id);

    std::unique_ptr<Scene> scene_;
    SceneId currentId_ = SceneId::Title;
    SceneId pendingId_ = SceneId::Title;
    Phase   phase_ = Phase::Idle;
    float   fade_  = 0.0f;        // 0 clear .. 1 black
    static constexpr float kFadeSpeed = 2.6f;

    void doSwitch(GameContext& ctx);
};
