#pragma once
// =============================================================================
//  NavGrid — a 2D walkability grid with A* pathfinding
// =============================================================================
//
//  Used by The Hunt's AI hunter to navigate a maze arena. The grid is a flat
//  array of walkable/blocked cells in the XZ plane; A* returns a path of world
//  positions. Deliberately simple and self-contained — no external deps, fully
//  deterministic, and small enough to re-path every few frames cheaply.
//
#include "raylib.h"
#include <vector>
#include <cstdint>

class NavGrid {
public:
    void build(int cols, int rows, float cellSize);

    void setBlocked(int cx, int cy, bool blocked);
    bool blocked(int cx, int cy) const;
    bool inBounds(int cx, int cy) const;

    int  cols() const { return cols_; }
    int  rows() const { return rows_; }
    float cellSize() const { return cell_; }

    Vector3 cellToWorld(int cx, int cy) const;
    void    worldToCell(Vector3 p, int& cx, int& cy) const;

    // A* from one world point to another. Fills 'outPath' with world-space
    // waypoints (cell centres). Returns false if no path exists.
    bool findPath(Vector3 start, Vector3 goal,
                  std::vector<Vector3>& outPath) const;

    // True if a straight XZ line between two points crosses no blocked cell.
    bool lineOfSight(Vector3 a, Vector3 b) const;

private:
    int   cols_ = 0, rows_ = 0;
    float cell_ = 1.0f;
    float originX_ = 0.0f, originZ_ = 0.0f;
    std::vector<uint8_t> blocked_;

    int idx(int cx, int cy) const { return cy * cols_ + cx; }
};
