#include "ai/NavGrid.h"
#include "raymath.h"
#include <queue>
#include <algorithm>
#include <cmath>

void NavGrid::build(int cols, int rows, float cellSize) {
    cols_ = cols;
    rows_ = rows;
    cell_ = cellSize;
    blocked_.assign((size_t)cols * rows, 0);
    // Centre the grid on the world origin.
    originX_ = -(cols - 1) * 0.5f * cell_;
    originZ_ = -(rows - 1) * 0.5f * cell_;
}

bool NavGrid::inBounds(int cx, int cy) const {
    return cx >= 0 && cx < cols_ && cy >= 0 && cy < rows_;
}

void NavGrid::setBlocked(int cx, int cy, bool b) {
    if (inBounds(cx, cy)) blocked_[idx(cx, cy)] = b ? 1 : 0;
}

bool NavGrid::blocked(int cx, int cy) const {
    if (!inBounds(cx, cy)) return true;          // out of bounds = wall
    return blocked_[idx(cx, cy)] != 0;
}

Vector3 NavGrid::cellToWorld(int cx, int cy) const {
    return Vector3{ originX_ + cx * cell_, 0.0f, originZ_ + cy * cell_ };
}

void NavGrid::worldToCell(Vector3 p, int& cx, int& cy) const {
    cx = (int)std::lround((p.x - originX_) / cell_);
    cy = (int)std::lround((p.z - originZ_) / cell_);
    cx = std::clamp(cx, 0, cols_ - 1);
    cy = std::clamp(cy, 0, rows_ - 1);
}

// --- A* ---------------------------------------------------------------------

namespace {
struct Node {
    int cell;
    float f;
    bool operator>(const Node& o) const { return f > o.f; }
};
}

bool NavGrid::findPath(Vector3 start, Vector3 goal,
                       std::vector<Vector3>& outPath) const {
    outPath.clear();
    if (cols_ == 0 || rows_ == 0) return false;

    int sx, sy, gx, gy;
    worldToCell(start, sx, sy);
    worldToCell(goal,  gx, gy);
    int startCell = idx(sx, sy);
    int goalCell  = idx(gx, gy);

    // If the goal cell is blocked, aim for the nearest open neighbour instead
    // so the hunter still pursues a player standing in/near a wall.
    if (blocked(gx, gy)) {
        const int dx[] = {1,-1,0,0,1,1,-1,-1};
        const int dy[] = {0,0,1,-1,1,-1,1,-1};
        for (int d = 0; d < 8; ++d) {
            if (!blocked(gx+dx[d], gy+dy[d])) {
                gx += dx[d]; gy += dy[d];
                goalCell = idx(gx, gy);
                break;
            }
        }
    }

    int total = cols_ * rows_;
    std::vector<float> g(total, 1e30f);
    std::vector<int>   came(total, -1);
    std::vector<uint8_t> closed(total, 0);

    auto heur = [&](int c) {
        int cx = c % cols_, cy = c / cols_;
        float ddx = (float)(cx - gx), ddy = (float)(cy - gy);
        // Octile distance — admissible for 8-connected grids.
        float adx = std::fabs(ddx), ady = std::fabs(ddy);
        return (adx + ady) + (1.41421356f - 2.0f) * std::min(adx, ady);
    };

    std::priority_queue<Node, std::vector<Node>, std::greater<Node>> open;
    g[startCell] = 0.0f;
    open.push({ startCell, heur(startCell) });

    const int dx[] = {1,-1,0,0,1,1,-1,-1};
    const int dy[] = {0,0,1,-1,1,-1,1,-1};
    const float stepCost[] = {1,1,1,1,1.41421356f,1.41421356f,1.41421356f,1.41421356f};

    bool found = false;
    while (!open.empty()) {
        Node cur = open.top(); open.pop();
        if (closed[cur.cell]) continue;
        closed[cur.cell] = 1;
        if (cur.cell == goalCell) { found = true; break; }

        int cx = cur.cell % cols_, cy = cur.cell / cols_;
        for (int d = 0; d < 8; ++d) {
            int nx = cx + dx[d], ny = cy + dy[d];
            if (!inBounds(nx, ny) || blocked(nx, ny)) continue;
            // Disallow diagonal moves that cut a wall corner.
            if (d >= 4) {
                if (blocked(cx + dx[d], cy) || blocked(cx, cy + dy[d]))
                    continue;
            }
            int nc = idx(nx, ny);
            if (closed[nc]) continue;
            float ng = g[cur.cell] + stepCost[d];
            if (ng < g[nc]) {
                g[nc] = ng;
                came[nc] = cur.cell;
                open.push({ nc, ng + heur(nc) });
            }
        }
    }

    if (!found) return false;

    // Reconstruct path goal->start, then reverse.
    std::vector<int> cells;
    for (int c = goalCell; c != -1; c = came[c]) cells.push_back(c);
    std::reverse(cells.begin(), cells.end());
    outPath.reserve(cells.size());
    for (int c : cells)
        outPath.push_back(cellToWorld(c % cols_, c / cols_));
    return true;
}

bool NavGrid::lineOfSight(Vector3 a, Vector3 b) const {
    // Sample the segment in small steps; if any sample is in a blocked cell,
    // sight is broken. Step < cell size so we never skip a wall cell.
    float dist = Vector3Distance(Vector3{a.x,0,a.z}, Vector3{b.x,0,b.z});
    int steps = (int)(dist / (cell_ * 0.4f)) + 1;
    for (int i = 0; i <= steps; ++i) {
        float t = (float)i / steps;
        Vector3 p{ a.x + (b.x-a.x)*t, 0.0f, a.z + (b.z-a.z)*t };
        int cx, cy;
        worldToCell(p, cx, cy);
        if (blocked(cx, cy)) return false;
    }
    return true;
}
