#include "blob/Blob.h"
#include "core/Input.h"
#include "core/Lighting.h"
#include "physics/World.h"
#include "fx/Easing.h"
#include "raymath.h"
#include <cmath>

void Blob::init(int id, Color color, float sizePersonality) {
    id_ = id;
    color_ = color;
    tuning_ = BlobTuning{};
    // sizePersonality in [-1,1]: small & nimble vs big & heavy.
    float s = ease::clamp01(0.5f + sizePersonality * 0.5f);
    tuning_.radius   = ease::lerp(0.52f, 0.74f, s);
    tuning_.mass     = ease::lerp(0.78f, 1.30f, s);
    tuning_.maxSpeed = ease::lerp(9.4f,  7.6f,  s);
    tuning_.moveAccel= ease::lerp(72.0f, 56.0f, s);
    tuning_.jumpSpeed= ease::lerp(12.2f, 10.9f, s);
    mesh_.reset();
    limbs_.configure(LimbLoadout::defaultCritter());
    jumpsLeft_ = tuning_.maxJumps;
    alive_ = true;
}

void Blob::setLimbs(const LimbLoadout& loadout) {
    limbs_.configure(loadout);
}

void Blob::respawn(Vector3 pos) {
    pos_ = prevPos_ = pos;
    vel_ = Vector3{0, 0, 0};
    wishDir_ = lastAccel_ = Vector3{0, 0, 0};
    grounded_ = wasGrounded_ = false;
    alive_ = true;
    limbs_.reset(pos);
    jumpsLeft_ = tuning_.maxJumps;
    dashTimer_ = dashCooldown_ = 0.0f;
    dashStarted_ = false;
    mesh_.reset();
}

Vector3 Blob::interpPosition(float alpha) const {
    return Vector3Lerp(prevPos_, pos_, alpha);
}

void Blob::addImpulse(Vector3 j) {
    vel_ = Vector3Add(vel_, Vector3Scale(j, 1.0f / tuning_.mass));
    mesh_.onHit(Vector3Length(j) * 0.06f);
}

void Blob::kill() {
    if (!alive_) return;
    alive_ = false;
    mesh_.setEmote(Emote::Dead);
}

void Blob::revive() {
    alive_ = true;
    mesh_.setEmote(Emote::Neutral);
}

void Blob::faceTowards(Vector3 worldDir) {
    worldDir.y = 0.0f;
    if (Vector3LengthSqr(worldDir) > 1e-4f)
        facing_ = Vector3Normalize(worldDir);
}

void Blob::control(const PlayerInput& in, float dt, bool allowMove, bool allowAbilities) {
    dashStarted_ = false;
    if (!alive_) { wishDir_ = Vector3{0,0,0}; wantJump_ = false; return; }

    // Input plane: x = world +X, input.y = world +Z (forward into screen).
    Vector3 wish{ in.move.x, 0.0f, in.move.y };
    if (!allowMove) wish = Vector3{0,0,0};
    wishDir_ = wish;

    if (Vector3LengthSqr(wish) > 0.02f)
        faceTowards(wish);

    if (allowAbilities && allowMove) {
        if (in.jumpPressed && jumpsLeft_ > 0) {
            wantJump_ = true;
        }
        if (in.dashPressed && dashCooldown_ <= 0.0f && dashTimer_ <= 0.0f) {
            dashTimer_   = tuning_.dashTime;
            dashCooldown_= tuning_.dashCooldown;
            dashStarted_ = true;
            Vector3 d = (Vector3LengthSqr(wish) > 0.02f) ? wish : facing_;
            dashDir_ = Vector3Normalize(d);
            mesh_.setEmote(Emote::Determined);
        }
    }
    if (dashCooldown_ > 0.0f) dashCooldown_ -= dt;
}

void Blob::integrate(World& world, float dt) {
    wasGrounded_ = grounded_;
    Vector3 before = vel_;

    if (dashTimer_ > 0.0f) {
        // Dash overrides horizontal control with a flat burst.
        dashTimer_ -= dt;
        vel_.x = dashDir_.x * tuning_.dashSpeed;
        vel_.z = dashDir_.z * tuning_.dashSpeed;
    } else {
        // Horizontal acceleration toward wishDir.
        float accel = grounded_ ? tuning_.moveAccel : tuning_.airAccel;
        Vector3 wish = wishDir_;
        if (Vector3LengthSqr(wish) > 0.02f) {
            wish = Vector3Normalize(wish);
            vel_.x += wish.x * accel * dt;
            vel_.z += wish.z * accel * dt;
        } else if (grounded_) {
            // Friction toward rest.
            float k = std::exp(-tuning_.friction * dt);
            vel_.x *= k;
            vel_.z *= k;
        }
        // Clamp horizontal speed.
        float hs = std::sqrt(vel_.x * vel_.x + vel_.z * vel_.z);
        if (hs > tuning_.maxSpeed) {
            float f = tuning_.maxSpeed / hs;
            vel_.x *= f; vel_.z *= f;
        }
    }

    // Jump.
    if (wantJump_) {
        vel_.y = tuning_.jumpSpeed;
        jumpsLeft_--;
        wantJump_ = false;
        grounded_ = false;
        mesh_.onJump();
    }

    // Gravity.
    vel_ = Vector3Add(vel_, Vector3Scale(world.gravity(), dt));

    // Integrate.
    prevPos_ = pos_;
    pos_ = Vector3Add(pos_, Vector3Scale(vel_, dt));

    // Collide.
    Vector3 gn;
    world.collideSphere(pos_, vel_, tuning_.radius, grounded_, gn);

    // Landing detection.
    if (grounded_ && !wasGrounded_) {
        float impact = std::fabs(before.y);
        mesh_.onLand(impact);
        jumpsLeft_ = tuning_.maxJumps;
    }

    // Void death.
    if (pos_.y < world.killY()) kill();

    // Drive the mesh.
    lastAccel_ = Vector3Scale(Vector3Subtract(vel_, before), 1.0f / (dt > 0 ? dt : 1));
    Vector3 horizAccel{ lastAccel_.x, 0.0f, lastAccel_.z };
    mesh_.update(dt, vel_, grounded_, horizAccel);
    mesh_.setLook(Vector3LengthSqr(wishDir_) > 0.02f ? Vector3Normalize(wishDir_) : facing_);

    // Step the procedural arms & legs — purely cosmetic, driven by the body.
    limbs_.update(pos_, vel_, lastAccel_, facing_, tuning_.radius,
                  grounded_, dt);
}

void Blob::draw(Lighting& lighting, float alpha, Vector3 renderOffset) const {
    Vector3 p = interpPosition(alpha);
    p = Vector3Add(p, renderOffset);   // cosmetic netcode-correction ease
    Color c = color_;
    if (!alive_) {
        // Desaturate dead blobs slightly.
        c.r = (unsigned char)(c.r * 0.55f + 40);
        c.g = (unsigned char)(c.g * 0.55f + 40);
        c.b = (unsigned char)(c.b * 0.55f + 40);
    }
    // Limbs draw first, then the body over them — so the body cleanly
    // overlaps the limb roots and there is no visible seam. Limb joints are
    // simulated at pos_; shift them to the interpolated render position.
    Vector3 shift = Vector3Subtract(p, pos_);
    limbs_.draw(lighting, Vector3{ (float)c.r, (float)c.g, (float)c.b },
                1.0f, shift);
    mesh_.draw(p, tuning_.radius, facing_, c, lighting, true);
}
