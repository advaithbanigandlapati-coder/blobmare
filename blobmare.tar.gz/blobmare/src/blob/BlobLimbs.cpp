#include "blob/BlobLimbs.h"
#include "core/Lighting.h"
#include "raymath.h"
#include "rlgl.h"
#include <cmath>

// --- Default loadout --------------------------------------------------------

LimbLoadout LimbLoadout::defaultCritter() {
    LimbLoadout L;
    // Two arms low on the sides, angled slightly down and forward.
    LimbConfig armL; armL.kind = LimbKind::Arm;
    armL.attach = Vector3{ -1.0f, -0.05f, 0.15f };
    armL.length = 0.95f; armL.thickness = 0.13f;
    LimbConfig armR = armL;
    armR.attach = Vector3{ 1.0f, -0.05f, 0.15f };
    // Two legs at the bottom, angled down and out.
    LimbConfig legL; legL.kind = LimbKind::Leg;
    legL.attach = Vector3{ -0.45f, -0.95f, 0.0f };
    legL.length = 0.85f; legL.thickness = 0.16f;
    LimbConfig legR = legL;
    legR.attach = Vector3{ 0.45f, -0.95f, 0.0f };
    L.limbs = { armL, armR, legL, legR };
    return L;
}

// --- BlobLimbs --------------------------------------------------------------

void BlobLimbs::configure(const LimbLoadout& loadout) {
    loadout_ = loadout;
    limbs_.clear();
    limbs_.reserve(loadout_.limbs.size());
    for (const auto& c : loadout_.limbs) {
        Limb limb;
        limb.cfg = c;
        for (int j = 0; j < 3; ++j) {
            limb.joint[j] = Vector3{0,0,0};
            limb.vel[j]   = Vector3{0,0,0};
        }
        limbs_.push_back(limb);
    }
}

Vector3 BlobLimbs::rootWorld(const LimbConfig& c, Vector3 bodyPos,
                             Vector3 facing, float radius) const {
    // Build the blob's local basis from facing.
    Vector3 fwd = facing;
    if (Vector3LengthSqr(fwd) < 1e-5f) fwd = Vector3{0,0,1};
    fwd = Vector3Normalize(fwd);
    Vector3 up    = Vector3{0,1,0};
    Vector3 right = Vector3Normalize(Vector3CrossProduct(up, fwd));

    Vector3 a = Vector3Normalize(c.attach);
    // Place the root just on the body surface in the attach direction.
    Vector3 local = Vector3Scale(a, radius * 0.92f);
    Vector3 w = bodyPos;
    w = Vector3Add(w, Vector3Scale(right, local.x));
    w = Vector3Add(w, Vector3Scale(up,    local.y));
    w = Vector3Add(w, Vector3Scale(fwd,   local.z));
    return w;
}

void BlobLimbs::reset(Vector3 bodyPos) {
    walkPhase_ = 0.0f;
    for (auto& limb : limbs_) {
        for (int j = 0; j < 3; ++j) {
            limb.joint[j] = bodyPos;
            limb.vel[j]   = Vector3{0,0,0};
        }
    }
}

void BlobLimbs::update(Vector3 bodyPos, Vector3 bodyVel, Vector3 bodyAccel,
                       Vector3 facing, float radius, bool grounded,
                       float dt) {
    if (limbs_.empty()) return;

    Vector3 fwd = facing;
    if (Vector3LengthSqr(fwd) < 1e-5f) fwd = Vector3{0,0,1};
    fwd = Vector3Normalize(fwd);
    Vector3 up    = Vector3{0,1,0};
    Vector3 right = Vector3Normalize(Vector3CrossProduct(up, fwd));

    // Horizontal speed drives the walk-cycle stride.
    Vector3 flatVel{ bodyVel.x, 0.0f, bodyVel.z };
    float   speed = Vector3Length(flatVel);
    walkPhase_ += dt * (3.0f + speed * 1.4f);

    for (size_t i = 0; i < limbs_.size(); ++i) {
        Limb& limb = limbs_[i];
        const LimbConfig& c = limb.cfg;

        // Root rigidly tracks the body surface.
        limb.joint[0] = rootWorld(c, bodyPos, facing, radius);

        Vector3 attach = Vector3Normalize(c.attach);
        // Outward direction the limb naturally hangs along.
        Vector3 outWorld =
            Vector3Add(Vector3Add(Vector3Scale(right, attach.x),
                                  Vector3Scale(up,    attach.y)),
                       Vector3Scale(fwd, attach.z));
        outWorld = Vector3Normalize(outWorld);

        float seg = c.length * 0.5f;

        // --- Rest pose -----------------------------------------------------
        // Arms hang down-and-out; legs hang mostly down. A per-limb stride
        // offset swings them fore/aft as the blob walks.
        float stridePhase = walkPhase_ + (float)i * 1.7f;
        float stride = std::sin(stridePhase) * (0.18f + speed * 0.10f);

        Vector3 down = Vector3{0,-1,0};
        Vector3 hang = (c.kind == LimbKind::Leg)
            ? Vector3Normalize(Vector3Add(down, Vector3Scale(outWorld, 0.25f)))
            : Vector3Normalize(Vector3Add(down, Vector3Scale(outWorld, 0.7f)));

        // Swing the rest pose along forward by the stride.
        Vector3 swing = Vector3Scale(fwd, stride);
        // Legs plant when grounded — shorten the swing, push the tip down.
        if (c.kind == LimbKind::Leg && grounded)
            swing = Vector3Scale(swing, 0.4f);

        Vector3 restElbow = Vector3Add(limb.joint[0],
            Vector3Add(Vector3Scale(hang, seg), Vector3Scale(swing, 0.5f)));
        Vector3 restTip = Vector3Add(restElbow,
            Vector3Add(Vector3Scale(hang, seg), swing));

        // --- Spring the joints toward the rest pose -----------------------
        // Stiffer for legs (they should look supportive), looser for arms
        // (they flail). Body acceleration shoves the targets so limbs lag.
        float stiff = (c.kind == LimbKind::Leg) ? 150.0f : 95.0f;
        float damp  = (c.kind == LimbKind::Leg) ? 22.0f  : 16.0f;

        Vector3 accelKick = Vector3Scale(bodyAccel, -0.012f);

        auto spring = [&](int j, Vector3 target) {
            target = Vector3Add(target, accelKick);
            Vector3 toT = Vector3Subtract(target, limb.joint[j]);
            Vector3 force = Vector3Subtract(
                Vector3Scale(toT, stiff),
                Vector3Scale(limb.vel[j], damp));
            limb.vel[j] = Vector3Add(limb.vel[j], Vector3Scale(force, dt));
            limb.joint[j] = Vector3Add(limb.joint[j],
                                       Vector3Scale(limb.vel[j], dt));
        };
        spring(1, restElbow);
        spring(2, restTip);

        // --- Hard length clamps so a limb can never stretch absurdly ------
        auto clampSeg = [&](int from, int to, float maxLen) {
            Vector3 d = Vector3Subtract(limb.joint[to], limb.joint[from]);
            float L = Vector3Length(d);
            if (L > maxLen && L > 1e-4f) {
                limb.joint[to] = Vector3Add(limb.joint[from],
                    Vector3Scale(d, maxLen / L));
            }
        };
        clampSeg(0, 1, seg * 1.35f);
        clampSeg(1, 2, seg * 1.35f);
    }
}

void BlobLimbs::draw(Lighting& lighting, Vector3 bodyColor,
                     float squashY, Vector3 renderShift) const {
    if (limbs_.empty()) return;
    (void)squashY;

    lighting.begin();
    for (const auto& limb : limbs_) {
        const LimbConfig& c = limb.cfg;
        // Render-space joints: sim joints shifted to the interpolated body
        // position so limbs stay locked to the body the eye sees.
        Vector3 j0 = Vector3Add(limb.joint[0], renderShift);
        Vector3 j1 = Vector3Add(limb.joint[1], renderShift);
        Vector3 j2 = Vector3Add(limb.joint[2], renderShift);
        // A limb tint of pure white means "use the body colour" (a touch
        // darker so limbs read as distinct from the body).
        Color col;
        if (c.tint.r == 255 && c.tint.g == 255 && c.tint.b == 255) {
            col = Color{
                (unsigned char)(bodyColor.x * 0.82f),
                (unsigned char)(bodyColor.y * 0.82f),
                (unsigned char)(bodyColor.z * 0.82f), 255 };
        } else {
            col = c.tint;
        }

        float rTop = c.thickness;
        float rMid = c.thickness * 0.8f;
        float rTip = c.thickness * 0.55f;

        // Upper segment: root -> elbow. Lower: elbow -> tip. Tapered.
        DrawCylinderEx(j0, j1, rTop, rMid, 8, col);
        DrawCylinderEx(j1, j2, rMid, rTip, 8, col);

        // Rounded joints + a hand/foot ball at the tip — reads cuter and
        // hides the segment seams.
        DrawSphereEx(j0, rTop * 1.02f, 8, 8, col);
        DrawSphereEx(j1, rMid * 1.05f, 8, 8, col);
        float tipR = (c.kind == LimbKind::Leg) ? rTip * 1.7f : rTip * 1.5f;
        DrawSphereEx(j2, tipR, 9, 9, col);
    }
    lighting.end();
}
