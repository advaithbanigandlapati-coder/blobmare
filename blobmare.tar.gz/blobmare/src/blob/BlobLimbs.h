#pragma once
// =============================================================================
//  BlobLimbs — procedural springy arms & legs for a blob
// =============================================================================
//
//  A blob on its own is a ball with a face. Limbs are what make it read as a
//  CHARACTER. This module hangs a configurable set of two-segment limbs off
//  the blob's body and animates them with light spring physics so they swing,
//  trail, and flail as the blob moves and jumps — the goofy Fall-Guys feel.
//
//  DESIGN
//    * A limb = a root attachment point on the body sphere + a 2-bone chain
//      (upper segment, lower segment) drawn as tapered capsules.
//    * The root rigidly follows the body. Each joint past it is a point mass
//      on a stiff spring toward its "rest" pose, but perturbed by the body's
//      velocity and acceleration — so the limb lags, swings, and overshoots.
//    * Purely cosmetic: limbs never touch collision or the sim. They can be
//      hard-clamped in length so they can never stretch absurdly.
//
//  EDITABLE
//    LimbConfig is plain data: per-limb attach direction, length, thickness,
//    and kind (arm/leg). The character editor (later) edits exactly this —
//    "drag a limb out of the body" sets an attach dir + length. A blob with
//    an empty config simply has no limbs (a plain ball), so this is safe to
//    add everywhere.
//
#include "raylib.h"
#include <vector>

class Lighting;

enum class LimbKind { Arm, Leg };

// One limb's static definition — this is the editable data.
struct LimbConfig {
    LimbKind kind   = LimbKind::Arm;
    // Attachment direction on the body, in the blob's local space
    // (x=right, y=up, z=forward). Normalised on use.
    Vector3  attach = { 1.0f, 0.0f, 0.0f };
    float    length = 0.9f;       // total limb length (both segments)
    float    thickness = 0.14f;   // capsule radius at the root
    Color    tint   = { 255, 255, 255, 255 };  // 255,255,255 = use body color
};

// A blob's whole limb loadout. Default = the standard 4-limb critter.
struct LimbLoadout {
    std::vector<LimbConfig> limbs;
    static LimbLoadout defaultCritter();   // 2 arms + 2 legs
};

// Runtime state + animation for one blob's limbs.
class BlobLimbs {
public:
    void configure(const LimbLoadout& loadout);
    void reset(Vector3 bodyPos);
    bool empty() const { return limbs_.empty(); }

    // Step the springy animation. 'bodyPos','bodyVel','bodyAccel' drive the
    // swing; 'facing' orients the loadout; 'radius' is the body radius;
    // 'grounded' lets legs plant a little.
    void update(Vector3 bodyPos, Vector3 bodyVel, Vector3 bodyAccel,
                Vector3 facing, float radius, bool grounded, float dt);

    // Draw all limbs. 'bodyColor' is used where a limb's tint is 255,255,255.
    void draw(Lighting& lighting, Vector3 bodyColor, float squashY,
              Vector3 renderShift = Vector3{0,0,0}) const;

    const LimbLoadout& loadout() const { return loadout_; }

private:
    struct Limb {
        LimbConfig cfg;
        // World-space joints: [0]=root (on body), [1]=elbow/knee, [2]=tip.
        Vector3 joint[3];
        Vector3 vel[3];          // spring velocity for joints 1 and 2
    };

    LimbLoadout         loadout_;
    std::vector<Limb>   limbs_;
    float               walkPhase_ = 0.0f;   // drives the leg stride cycle

    Vector3 rootWorld(const LimbConfig& c, Vector3 bodyPos,
                      Vector3 facing, float radius) const;
};
