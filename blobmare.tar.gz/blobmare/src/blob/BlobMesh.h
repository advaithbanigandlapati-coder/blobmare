#pragma once
// The blob's *visual* layer: a soft-body jiggle mesh that squashes, stretches
// and wobbles like the reference — a top-heavy jelly that sways and deforms
// locally rather than just scaling uniformly.
//
// HOW THE JIGGLE WORKS
// --------------------
// A unit sphere mesh is generated once. Around it sits a small lattice of
// "jiggle points" arranged in stacked rings. Each jiggle point is a 3D damped
// spring with an offset from its rest position. Forces (acceleration, landing,
// jumps, hits) push the points; springs pull them home. Every render frame the
// sphere's vertices are displaced by a smooth, distance-weighted blend of the
// nearby jiggle points — so the surface ripples and bulges softly.
//
// This is a genuine mass-spring soft body, but a SAFE one: the springs are
// per-point and independent (no chained vertex network that can feed back into
// itself), each point's offset is hard-clamped to a fraction of the radius,
// and velocities are damped every step. It physically cannot explode, and it
// never touches collision — the rigid body is still a clean sphere.
#include "raylib.h"
#include <vector>

class Lighting;

enum class Emote { Neutral, Happy, Scared, Dizzy, Dead, Determined };

class BlobMesh {
public:
    BlobMesh();
    ~BlobMesh();
    BlobMesh(const BlobMesh&) = delete;
    BlobMesh& operator=(const BlobMesh&) = delete;

    void ensureBuilt();
    void reset();

    // Per fixed step. bodyVel/grounded drive squash; accel adds directional
    // jiggle so the blob sloshes the way it is moving.
    void update(float dt, Vector3 bodyVel, bool grounded, Vector3 horizAccel);

    void onLand(float impactSpeed);          // big squash on landing
    void onJump();                           // stretch on take-off
    void onHit(float strength);              // chaotic wobble from a knock
    void onHit(Vector3 dir, float strength); // directional knock

    void setEmote(Emote e)  { emote_ = e; }
    Emote emote() const     { return emote_; }
    void setLook(Vector3 worldDir) { lookDir_ = worldDir; }

    void draw(Vector3 pos, float radius, Vector3 facing, Color color,
              Lighting& lighting, bool faceVisible = true) const;

private:
    struct Jiggle {
        Vector3 rest{};      // rest position on the unit sphere
        Vector3 offset{};    // current displacement from rest
        Vector3 vel{};       // displacement velocity
    };

    Mesh   mesh_{};
    Model  model_{};
    bool   built_    = false;
    mutable bool uploaded_ = false;
    std::vector<Vector3> baseVerts_;
    std::vector<Vector3> baseNorms_;

    std::vector<Jiggle> lattice_;

    float stretch_ = 0.0f, stretchVel_ = 0.0f;
    float wobble_  = 0.0f, wobbleVel_  = 0.0f;
    Vector3 lean_{0, 0, 0};

    float blink_ = 0.0f, blinkAmt_ = 0.0f;
    float wooze_ = 0.0f;
    Emote emote_ = Emote::Neutral;
    Vector3 lookDir_{0, 0, 1};

    void buildMesh();
    void buildLattice();
    Vector3 sampleDeform(Vector3 unitPos) const;
    void deformMesh(float radius, float sx, float sy, float sz) const;
};
