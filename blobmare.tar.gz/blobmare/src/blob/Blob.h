#pragma once
// The Blob: a sphere-bodied character. The rigid body is fully deterministic
// and steps at the fixed sim rate; BlobMesh handles all the squishy visuals.
// Render reads an interpolated position so motion stays smooth at 60 fps.
#include "raylib.h"
#include "blob/BlobMesh.h"
#include "blob/BlobLimbs.h"

class World;
class Lighting;
struct PlayerInput;

struct BlobTuning {
    float radius      = 0.62f;
    float moveAccel   = 64.0f;   // ground acceleration
    float airAccel    = 28.0f;
    float maxSpeed    = 8.5f;
    float friction    = 9.0f;    // ground damping toward zero
    float jumpSpeed   = 11.5f;
    int   maxJumps    = 1;       // TowerClimb raises this to 2
    float dashSpeed   = 16.0f;
    float dashTime    = 0.18f;
    float dashCooldown= 0.55f;
    float mass        = 1.0f;
};

class Blob {
public:
    void init(int id, Color color, float sizePersonality);
    void respawn(Vector3 pos);

    // Read input -> set intent. Call before integrate(). Returns nothing;
    // 'allowMove'/'allowAbilities' let minigames freeze blobs during
    // countdowns or after a win.
    void control(const PlayerInput& in, float dt, bool allowMove, bool allowAbilities);

    // Fixed-step physics: gravity, integration, world collision.
    void integrate(World& world, float dt);

    // 'renderOffset' is a cosmetic-only world offset added to the drawn
    // position (used by netcode reconciliation to ease a correction in). It
    // never affects physics — purely where the mesh appears this frame.
    void draw(Lighting& lighting, float alpha,
              Vector3 renderOffset = Vector3{0,0,0}) const;

    // --- Queries ---------------------------------------------------------
    int     id() const            { return id_; }
    Color   color() const         { return color_; }
    Vector3 position() const      { return pos_; }
    Vector3 interpPosition(float alpha) const;
    Vector3 velocity() const      { return vel_; }
    Vector3 facing() const        { return facing_; }
    float   radius() const        { return tuning_.radius; }
    bool    grounded() const      { return grounded_; }
    bool    alive() const         { return alive_; }
    bool    isDashing() const     { return dashTimer_ > 0.0f; }
    bool    dashStartedThisStep() const { return dashStarted_; }

    // --- Commands --------------------------------------------------------
    void setPosition(Vector3 p)   { pos_ = prevPos_ = p; }
    void setVelocity(Vector3 v)   { vel_ = v; }
    void addImpulse(Vector3 j);
    void kill();
    void revive();
    void setEmote(Emote e)        { mesh_.setEmote(e); }
    void faceTowards(Vector3 worldDir);

    BlobTuning&  tuning()         { return tuning_; }
    BlobMesh&    mesh()           { return mesh_; }
    const BlobMesh& mesh() const  { return mesh_; }

    // Procedural arms & legs. Set a loadout to give the blob limbs; the
    // default loadout is the standard 4-limb critter. An empty loadout
    // leaves the blob a plain ball.
    void setLimbs(const LimbLoadout& loadout);
    BlobLimbs&       limbs()       { return limbs_; }
    const BlobLimbs& limbs() const { return limbs_; }

private:
    int      id_ = 0;
    Color    color_{255, 255, 255, 255};
    BlobTuning tuning_;
    BlobMesh mesh_;
    BlobLimbs limbs_;

    Vector3  pos_{0, 0, 0}, prevPos_{0, 0, 0}, vel_{0, 0, 0};
    Vector3  facing_{0, 0, 1};
    Vector3  wishDir_{0, 0, 0};   // intent from control()
    Vector3  lastAccel_{0, 0, 0};
    bool     grounded_ = false;
    bool     wasGrounded_ = false;
    bool     alive_ = true;
    int      jumpsLeft_ = 1;
    bool     wantJump_ = false;
    float    dashTimer_ = 0.0f;
    float    dashCooldown_ = 0.0f;
    bool     dashStarted_ = false;
    Vector3  dashDir_{0, 0, 1};
};
