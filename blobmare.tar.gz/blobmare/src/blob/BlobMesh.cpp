#include "blob/BlobMesh.h"
#include "core/Lighting.h"
#include "fx/Easing.h"
#include "raymath.h"
#include "rlgl.h"
#include <cmath>
#include <cstring>

namespace {
// --- Mesh resolution --------------------------------------------------------
constexpr int   kRings   = 16;   // latitude divisions of the sphere mesh
constexpr int   kSlices  = 24;   // longitude divisions

// --- Jiggle lattice tuning --------------------------------------------------
constexpr int   kLatRings = 3;   // stacked rings of jiggle points (low/mid/high)
constexpr int   kLatSlices= 6;   // jiggle points per ring
constexpr float kJigOmega = 26.0f;  // jiggle spring frequency
constexpr float kJigZeta  = 0.28f;  // damping ratio — low = lively jelly
constexpr float kMaxOff   = 0.34f;  // hard clamp on offset (fraction of radius)
constexpr float kInfluence= 1.15f;  // how far a jiggle point reaches (unit-sphere)

// --- Global squash springs --------------------------------------------------
constexpr float kStretchOmega = 15.0f;
constexpr float kStretchZeta  = 0.6f;
constexpr float kWobbleOmega  = 28.0f;
constexpr float kWobbleZeta   = 0.22f;
constexpr float kVelToStretch = 0.045f;
constexpr float kMaxStretch   = 0.5f;
constexpr float kLeanAmount   = 0.02f;

void spring(float& x, float& v, float target, float omega, float zeta, float dt) {
    float a = -2.0f * zeta * omega * v - omega * omega * (x - target);
    v += a * dt;
    x += v * dt;
}

// 3D critically-tunable damped spring toward zero offset.
void spring3(Vector3& x, Vector3& v, float omega, float zeta, float dt) {
    Vector3 a {
        -2.0f*zeta*omega*v.x - omega*omega*x.x,
        -2.0f*zeta*omega*v.y - omega*omega*x.y,
        -2.0f*zeta*omega*v.z - omega*omega*x.z,
    };
    v = Vector3Add(v, Vector3Scale(a, dt));
    x = Vector3Add(x, Vector3Scale(v, dt));
}
} // namespace

BlobMesh::BlobMesh() = default;

BlobMesh::~BlobMesh() {
    if (built_) {
        // UnloadModel touches the GL context. If the window/context is already
        // gone (e.g. an object outliving CloseWindow), calling it would crash.
        // IsWindowReady() guards that: when false, the GL resources are already
        // invalid and the OS reclaims them on process exit anyway.
        if (IsWindowReady()) {
            UnloadModel(model_);
        }
        built_ = false;
    }
}

// --- Mesh + lattice construction -------------------------------------------

void BlobMesh::buildMesh() {
    // A UV sphere of unit radius. We keep our own CPU copy of base verts so we
    // can re-deform every frame without accumulating error.
    int vertsPerStrip = (kSlices + 1);
    int triCount = kRings * kSlices * 2;
    int vertCount = triCount * 3;

    mesh_ = Mesh{};
    mesh_.triangleCount = triCount;
    mesh_.vertexCount   = vertCount;
    mesh_.vertices  = (float*)MemAlloc(sizeof(float) * 3 * vertCount);
    mesh_.normals   = (float*)MemAlloc(sizeof(float) * 3 * vertCount);
    mesh_.texcoords = (float*)MemAlloc(sizeof(float) * 2 * vertCount);

    baseVerts_.clear();
    baseNorms_.clear();
    baseVerts_.reserve(vertCount);
    baseNorms_.reserve(vertCount);

    auto spherePoint = [](int ring, int slice) {
        float v = (float)ring  / kRings;          // 0..1 latitude
        float u = (float)slice / kSlices;         // 0..1 longitude
        float theta = v * PI;                     // 0..pi
        float phi   = u * 2.0f * PI;              // 0..2pi
        float st = std::sin(theta);
        return Vector3{ st * std::cos(phi),
                        std::cos(theta),
                        st * std::sin(phi) };
    };

    int w = 0;
    auto push = [&](Vector3 p) {
        mesh_.vertices[w*3+0] = p.x;
        mesh_.vertices[w*3+1] = p.y;
        mesh_.vertices[w*3+2] = p.z;
        mesh_.normals [w*3+0] = p.x;   // unit sphere: normal == position
        mesh_.normals [w*3+1] = p.y;
        mesh_.normals [w*3+2] = p.z;
        mesh_.texcoords[w*2+0] = 0.0f;
        mesh_.texcoords[w*2+1] = 0.0f;
        baseVerts_.push_back(p);
        baseNorms_.push_back(p);
        ++w;
    };

    for (int r = 0; r < kRings; ++r) {
        for (int s = 0; s < kSlices; ++s) {
            Vector3 a = spherePoint(r,   s);
            Vector3 b = spherePoint(r+1, s);
            Vector3 c = spherePoint(r+1, s+1);
            Vector3 d = spherePoint(r,   s+1);
            // Two triangles per quad, CCW.
            push(a); push(b); push(d);
            push(b); push(c); push(d);
        }
    }
    (void)vertsPerStrip;

    UploadMesh(&mesh_, true);                 // dynamic = true: we update verts
    model_ = LoadModelFromMesh(mesh_);
}

void BlobMesh::buildLattice() {
    lattice_.clear();
    // Stacked rings of jiggle points. The lowest ring sits a bit below the
    // equator, the highest near the top — biasing wobble toward the upper
    // body so the blob reads as top-heavy, like the reference image.
    const float ringY[kLatRings]      = { -0.45f, 0.15f, 0.7f };
    const float ringRad[kLatRings]    = {  0.9f,  1.0f, 0.72f };
    for (int r = 0; r < kLatRings; ++r) {
        for (int s = 0; s < kLatSlices; ++s) {
            float phi = (float)s / kLatSlices * 2.0f * PI
                      + (r * 0.5f);            // stagger rings
            Jiggle j;
            j.rest = Vector3{ std::cos(phi) * ringRad[r],
                              ringY[r],
                              std::sin(phi) * ringRad[r] };
            lattice_.push_back(j);
        }
    }
}

void BlobMesh::ensureBuilt() {
    if (built_) return;
    buildMesh();
    buildLattice();
    built_ = true;
    blink_ = (float)GetRandomValue(1, 4);
}

void BlobMesh::reset() {
    stretch_ = stretchVel_ = 0.0f;
    wobble_  = wobbleVel_  = 0.0f;
    lean_ = Vector3{0,0,0};
    blink_ = (float)GetRandomValue(1, 4);
    blinkAmt_ = 0.0f;
    wooze_ = 0.0f;
    emote_ = Emote::Neutral;
    for (auto& j : lattice_) { j.offset = Vector3{0,0,0}; j.vel = Vector3{0,0,0}; }
}

// --- Per-step update --------------------------------------------------------

void BlobMesh::update(float dt, Vector3 bodyVel, bool grounded,
                      Vector3 horizAccel) {
    ensureBuilt();

    // Global squash spring (tall when rising, squat when falling).
    float target = ease::clamp01(0.5f + bodyVel.y * kVelToStretch * 0.5f);
    target = (target - 0.5f) * 2.0f * kMaxStretch;
    if (grounded && bodyVel.y >= -0.5f) target *= 0.25f;
    spring(stretch_, stretchVel_, target, kStretchOmega, kStretchZeta, dt);
    spring(wobble_,  wobbleVel_,  0.0f,   kWobbleOmega,  kWobbleZeta,  dt);

    // Cosmetic lean.
    Vector3 leanTarget = Vector3Scale(horizAccel, kLeanAmount);
    lean_.x = ease::approach(lean_.x, leanTarget.x, 12.0f, dt);
    lean_.z = ease::approach(lean_.z, leanTarget.z, 12.0f, dt);

    // --- Jiggle lattice ---------------------------------------------------
    // Horizontal acceleration sloshes the lattice: points on the trailing
    // side of the motion lag behind, creating a directional bulge.
    Vector3 slosh = Vector3Scale(horizAccel, 0.012f);
    for (auto& j : lattice_) {
        // A push proportional to how much this point faces the slosh
        // direction. Trailing side gets pushed out, leading side pulled in.
        float facing = j.rest.x * slosh.x + j.rest.z * slosh.z;
        Vector3 push = Vector3Scale(slosh, -1.0f);          // body lags motion
        push.y += -std::fabs(facing) * 0.4f;                // slight sag
        j.vel = Vector3Add(j.vel, Vector3Scale(push, dt * 60.0f));

        // Integrate the damped spring back toward rest (offset -> 0).
        spring3(j.offset, j.vel, kJigOmega, kJigZeta, dt);

        // Hard safety clamp — the jiggle can never run away.
        float len = Vector3Length(j.offset);
        if (len > kMaxOff) {
            j.offset = Vector3Scale(j.offset, kMaxOff / len);
            // Bleed off velocity pushing further past the clamp.
            float vn = Vector3DotProduct(j.vel, Vector3Scale(j.offset, 1.0f/kMaxOff));
            if (vn > 0.0f)
                j.vel = Vector3Subtract(j.vel,
                          Vector3Scale(Vector3Scale(j.offset, 1.0f/kMaxOff), vn));
        }
    }

    // Blink + dizzy.
    blink_ -= dt;
    if (blink_ <= 0.0f) { blink_ = (float)GetRandomValue(2,6); blinkAmt_ = 1.0f; }
    blinkAmt_ = ease::approach(blinkAmt_, 0.0f, 16.0f, dt);
    if (emote_ == Emote::Dizzy) wooze_ += dt * 8.0f;
}

// --- Perturbations ----------------------------------------------------------

void BlobMesh::onLand(float impactSpeed) {
    float k = ease::clamp01(impactSpeed / 18.0f);
    wobble_    -= 0.4f * k;
    wobbleVel_ -= 5.0f * k;
    // Splat the lattice downward and outward.
    for (auto& j : lattice_) {
        j.vel.y -= 9.0f * k;
        j.vel = Vector3Add(j.vel, Vector3Scale(Vector3{j.rest.x,0,j.rest.z},
                                               4.0f * k));
    }
}

void BlobMesh::onJump() {
    wobble_    += 0.3f;
    wobbleVel_ += 6.0f;
    for (auto& j : lattice_) {
        j.vel.y += 7.0f;                              // stretch up
        j.vel = Vector3Add(j.vel, Vector3Scale(Vector3{j.rest.x,0,j.rest.z},
                                               -2.5f)); // pinch in
    }
}

void BlobMesh::onHit(float strength) {
    float k = ease::clamp01(strength);
    wobbleVel_ += (GetRandomValue(0,1) ? 1.0f : -1.0f) * 14.0f * k;
    for (auto& j : lattice_) {
        j.vel.x += (float)GetRandomValue(-100,100)/100.0f * 12.0f * k;
        j.vel.y += (float)GetRandomValue(-100,100)/100.0f * 12.0f * k;
        j.vel.z += (float)GetRandomValue(-100,100)/100.0f * 12.0f * k;
    }
}

void BlobMesh::onHit(Vector3 dir, float strength) {
    float k = ease::clamp01(strength);
    if (Vector3LengthSqr(dir) > 1e-5f) dir = Vector3Normalize(dir);
    wobbleVel_ += 10.0f * k;
    for (auto& j : lattice_) {
        // Points facing the hit get driven inward; the far side bulges out.
        float facing = Vector3DotProduct(Vector3Normalize(j.rest), dir);
        j.vel = Vector3Add(j.vel, Vector3Scale(dir, -facing * 18.0f * k));
        j.vel.y += (float)GetRandomValue(-50,50)/100.0f * 6.0f * k;
    }
}

// --- Deformation sampling ---------------------------------------------------

Vector3 BlobMesh::sampleDeform(Vector3 unitPos) const {
    // Distance-weighted blend of every jiggle point's offset. Close points
    // dominate; far points fade out smoothly. This makes the surface ripple
    // as one connected jelly without a per-vertex spring network.
    Vector3 sum{0,0,0};
    float wsum = 0.0f;
    for (const auto& j : lattice_) {
        float d = Vector3Distance(unitPos, j.rest);
        float w = 1.0f - d / kInfluence;
        if (w <= 0.0f) continue;
        w = w * w;                                 // smooth falloff
        sum = Vector3Add(sum, Vector3Scale(j.offset, w));
        wsum += w;
    }
    if (wsum > 1e-4f) sum = Vector3Scale(sum, 1.0f / wsum);
    return sum;
}

void BlobMesh::deformMesh(float radius, float sx, float sy, float sz) const {
    if (!mesh_.vertices) return;
    int n = mesh_.vertexCount;
    for (int i = 0; i < n; ++i) {
        Vector3 base = baseVerts_[i];
        // Local jiggle displacement, then global squash, then scale to radius.
        Vector3 d = sampleDeform(base);
        Vector3 p {
            (base.x + d.x) * sx,
            (base.y + d.y) * sy,
            (base.z + d.z) * sz,
        };
        p = Vector3Scale(p, radius);
        mesh_.vertices[i*3+0] = p.x;
        mesh_.vertices[i*3+1] = p.y;
        mesh_.vertices[i*3+2] = p.z;

        // Approximate the deformed normal by nudging the base normal toward
        // the displacement gradient. Cheap but reads well under the rim light.
        Vector3 nrm = baseNorms_[i];
        nrm = Vector3Normalize(Vector3Add(nrm, Vector3Scale(d, 1.6f)));
        mesh_.normals[i*3+0] = nrm.x;
        mesh_.normals[i*3+1] = nrm.y;
        mesh_.normals[i*3+2] = nrm.z;
    }
    // Re-upload the changed vertex + normal buffers to the GPU.
    UpdateMeshBuffer(mesh_, 0, mesh_.vertices, sizeof(float)*3*n, 0);
    UpdateMeshBuffer(mesh_, 2, mesh_.normals,  sizeof(float)*3*n, 0);
    uploaded_ = true;
}

// --- Draw -------------------------------------------------------------------

void BlobMesh::draw(Vector3 pos, float radius, Vector3 facing, Color color,
                    Lighting& lighting, bool faceVisible) const {
    // Build on first draw if update() has not run yet (e.g. a static preview
    // blob in the character editor). ensureBuilt only lazily initialises GPU
    // resources, so the const_cast here is conceptually safe.
    const_cast<BlobMesh*>(this)->ensureBuilt();
    if (!built_) return;

    // Global squash factors.
    float s = stretch_ + wobble_;
    float sy = 1.0f + s;
    float sx = 1.0f - 0.5f * s;
    float sz = sx;
    if (sy < 0.3f) sy = 0.3f;
    if (sx < 0.3f) sx = sz = 0.3f;

    // Rewrite the mesh for this frame.
    deformMesh(radius, sx, sy, sz);

    // Orientation: facing on +Z, up on +Y.
    Vector3 fwd = facing;
    if (Vector3LengthSqr(fwd) < 1e-5f) fwd = Vector3{0,0,1};
    fwd = Vector3Normalize(fwd);
    Vector3 up    = Vector3{0,1,0};
    Vector3 right = Vector3Normalize(Vector3CrossProduct(up, fwd));

    lighting.begin();
    rlPushMatrix();
    rlTranslatef(pos.x, pos.y, pos.z);
    // Cosmetic lean tilt.
    rlRotatef(-lean_.z * 360.0f, 1, 0, 0);
    rlRotatef( lean_.x * 360.0f, 0, 0, 1);
    // Yaw to face 'fwd'.
    float yaw = atan2f(fwd.x, fwd.z) * RAD2DEG;
    rlRotatef(yaw, 0, 1, 0);
    // The deformed soft-body mesh can present either winding to the GPU as it
    // squashes. Backface culling would then cull the FRONT faces and leave
    // the blob looking hollow / see-through. The blob is a small closed shape
    // so culling buys nothing — disable it for this draw so every face is
    // solid, then restore it for the rest of the scene.
    rlDisableBackfaceCulling();
    DrawModel(model_, Vector3{0,0,0}, 1.0f, color);
    rlEnableBackfaceCulling();
    rlPopMatrix();
    lighting.end();

    if (!faceVisible) return;

    // --- Face -------------------------------------------------------------
    // Drawn unlit so it stays crisp. worldPoint(rx,uy,fz) takes coordinates
    // as FRACTIONS of the (squashed) radius: the face rides the deformed
    // front of the blob and is nudged by the local jiggle so it wobbles with
    // the body instead of sitting on a rigid sphere underneath.
    Vector3 faceJiggle = sampleDeform(Vector3{0, 0.15f, 0.92f});
    auto worldPoint = [&](float rx, float uy, float fz) {
        Vector3 local{ (rx + faceJiggle.x) * sx,
                       (uy + faceJiggle.y) * sy,
                       (fz + faceJiggle.z) * sz };
        Vector3 p = pos;
        p = Vector3Add(p, Vector3Scale(right, local.x * radius));
        p = Vector3Add(p, Vector3Scale(up,    local.y * radius));
        p = Vector3Add(p, Vector3Scale(fwd,   local.z * radius));
        return p;
    };

    const float er = radius * 0.20f;   // eye radius
    const float eo = 0.34f;            // eye horizontal offset (frac of radius)
    const float eh = 0.26f;            // eye height
    const float ef = 0.80f;            // eye forward push

    bool dead  = (emote_ == Emote::Dead);
    bool scared= (emote_ == Emote::Scared);
    bool happy = (emote_ == Emote::Happy);
    bool dizzy = (emote_ == Emote::Dizzy);
    bool det   = (emote_ == Emote::Determined);

    float open = 1.0f - blinkAmt_;
    float eyeR = er * (scared ? 1.2f : 1.0f);

    for (int e = 0; e < 2; ++e) {
        float side = (e == 0) ? -1.0f : 1.0f;
        Vector3 eyeC = worldPoint(side*eo, eh, ef);
        if (dead) {
            for (int k = 0; k < 2; ++k) {
                Vector3 a = worldPoint(side*eo - eyeR/radius,
                                       eh + (k?eyeR:-eyeR)/radius, ef+0.03f);
                Vector3 b = worldPoint(side*eo + eyeR/radius,
                                       eh + (k?-eyeR:eyeR)/radius, ef+0.03f);
                DrawCapsule(a,b, radius*0.05f, 4,4, Color{30,22,30,255});
            }
            continue;
        }
        // White of the eye, squashed vertically by the blink.
        rlPushMatrix();
        rlTranslatef(eyeC.x, eyeC.y, eyeC.z);
        rlScalef(1.0f, 0.15f + 0.85f*open, 1.0f);
        DrawSphereEx(Vector3{0,0,0}, eyeR, 10,10, Color{250,250,255,255});
        rlPopMatrix();

        // Pupil tracks the look direction.
        Vector3 ld = Vector3Normalize(Vector3{lookDir_.x, lookDir_.y*0.4f,
                                              lookDir_.z});
        float px = Vector3DotProduct(ld, right) * 0.35f * (eyeR/radius);
        float py = Vector3DotProduct(ld, up)    * 0.35f * (eyeR/radius);
        if (dizzy) {
            px = std::cos(wooze_+e) * 0.35f * (eyeR/radius);
            py = std::sin(wooze_+e) * 0.35f * (eyeR/radius);
        }
        Vector3 pup = worldPoint(side*eo + px, eh + py, ef + 0.06f);
        float pr = eyeR * (scared ? 0.4f : 0.55f) * (0.35f + 0.65f*open);
        DrawSphereEx(pup, pr, 8,8, Color{25,20,30,255});
        // Catchlight.
        Vector3 gl = worldPoint(side*eo + px + 0.05f, eh + py + 0.05f, ef+0.1f);
        DrawSphereEx(gl, pr*0.4f, 5,5, Color{255,255,255,220});
        // Determined brow.
        if (det) {
            Vector3 ba = worldPoint(side*eo - eyeR/radius, eh + 0.20f, ef+0.05f);
            Vector3 bb = worldPoint(side*eo + 0.10f,       eh + 0.30f, ef+0.05f);
            DrawCapsule(ba,bb, radius*0.06f, 4,4, Color{40,30,38,255});
        }
    }

    // Mouth.
    Color mouthCol{40,28,36,255};
    const float my = -0.16f, mf = ef * 0.97f;
    if (happy) {
        for (int i=-1;i<=1;++i) {
            float curve = (i==0)?0.0f:0.09f;
            DrawSphereEx(worldPoint(i*0.16f, my+curve, mf),
                         radius*0.08f, 6,6, mouthCol);
        }
    } else if (scared || dead) {
        DrawSphereEx(worldPoint(0, my-0.03f, mf), radius*0.11f, 8,8, mouthCol);
    } else if (det) {
        DrawCapsule(worldPoint(-0.16f,my,mf), worldPoint(0.16f,my,mf),
                    radius*0.05f, 4,4, mouthCol);
    } else {
        DrawCapsule(worldPoint(-0.13f,my,mf), worldPoint(0.13f,my,mf),
                    radius*0.045f, 4,4, mouthCol);
    }
}
