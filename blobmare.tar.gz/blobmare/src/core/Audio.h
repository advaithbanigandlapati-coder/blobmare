#pragma once
// Procedural audio. The game ships with NO sound files: every effect and the
// background music are synthesised into raylib Sounds at startup. This keeps
// the repo asset-free and the build self-contained, exactly matching the
// spec's "procedural audio" intent.
#include "raylib.h"
#include <vector>

enum class Sfx {
    Jump, Land, Dash, Hit, Bounce, Pop, Coin, Whoosh,
    Countdown, Go, Win, Lose, UiMove, UiSelect, UiBack,
    DoorOpen, Spooky, Splash, Tick, Powerup,
    COUNT
};

class Audio {
public:
    void init();
    void shutdown();

    void play(Sfx s, float volume = 1.0f, float pitchJitter = 0.0f);

    // Simple layered music: a looping bed that the game can switch between
    // a calm "hub" mood and a tense "minigame" mood.
    enum class Music { None, Hub, Minigame, Results };
    void setMusic(Music m);
    void updateMusic();          // call once per frame; handles looping
    void setMusicVolume(float v);
    void setSfxVolume(float v);

private:
    bool ready_ = false;
    std::vector<Sound> sfx_;     // indexed by Sfx
    Music music_ = Music::None;
    Music musicWanted_ = Music::None;
    Music musicCurrent_ = Music::None;
    Sound musicBed_{};
    bool  musicBedValid_ = false;
    float musicVol_ = 0.55f;
    float sfxVol_   = 0.85f;

    void buildAllSfx();
    void buildMusic(Music m);
    Sound makeMusicBed(Music m);
};
