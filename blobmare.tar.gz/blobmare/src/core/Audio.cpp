#include "core/Audio.h"
#include "core/Synth.h"
#include "raymath.h"
#include <cmath>

using synth::Buffer;

namespace {

// Musical helpers.
float noteHz(int semitonesFromA4) {
    return 440.0f * std::pow(2.0f, semitonesFromA4 / 12.0f);
}

// --- Individual SFX builders ----------------------------------------------
Buffer buildJump() {
    Buffer b(0.32f);
    synth::tone(b, 0.0f, 0.30f, synth::square,
        [](float t){ return 320.0f + 520.0f * t; },           // rising chirp
        [](float t){ return synth::expDecay(t, 0.10f); }, 0.34f);
    return b;
}
Buffer buildLand() {
    Buffer b(0.26f);
    synth::tone(b, 0.0f, 0.22f, synth::sine,
        [](float t){ return 220.0f - 140.0f * t; },
        [](float t){ return synth::expDecay(t, 0.06f); }, 0.5f);
    synth::tone(b, 0.0f, 0.10f, [](float){ return synth::noise(); },
        [](float){ return 1.0f; },
        [](float t){ return synth::expDecay(t, 0.03f); }, 0.25f);
    return b;
}
Buffer buildDash() {
    Buffer b(0.30f);
    synth::tone(b, 0.0f, 0.28f, [](float){ return synth::noise(); },
        [](float){ return 1.0f; },
        [](float t){ return synth::ad(t, 0.02f, 0.24f); }, 0.3f);
    synth::tone(b, 0.0f, 0.22f, synth::saw,
        [](float t){ return 600.0f + 900.0f * t; },
        [](float t){ return synth::expDecay(t, 0.09f); }, 0.18f);
    return b;
}
Buffer buildHit() {
    Buffer b(0.30f);
    synth::tone(b, 0.0f, 0.26f, synth::square,
        [](float t){ return 180.0f - 90.0f * t; },
        [](float t){ return synth::expDecay(t, 0.07f); }, 0.5f);
    synth::tone(b, 0.0f, 0.08f, [](float){ return synth::noise(); },
        [](float){ return 1.0f; },
        [](float t){ return synth::expDecay(t, 0.025f); }, 0.4f);
    return b;
}
Buffer buildBounce() {
    Buffer b(0.22f);
    synth::tone(b, 0.0f, 0.20f, synth::sine,
        [](float t){ return 420.0f + 300.0f * std::sin(t * 30.0f); },
        [](float t){ return synth::expDecay(t, 0.05f); }, 0.42f);
    return b;
}
Buffer buildPop() {
    Buffer b(0.16f);
    synth::tone(b, 0.0f, 0.14f, synth::sine,
        [](float t){ return 900.0f + 1400.0f * t; },
        [](float t){ return synth::expDecay(t, 0.03f); }, 0.4f);
    return b;
}
Buffer buildCoin() {
    Buffer b(0.34f);
    synth::tone(b, 0.0f,  0.10f, synth::square, [](float){ return noteHz(7); },
        [](float t){ return synth::expDecay(t, 0.08f); }, 0.34f);
    synth::tone(b, 0.08f, 0.24f, synth::square, [](float){ return noteHz(14); },
        [](float t){ return synth::expDecay(t, 0.14f); }, 0.34f);
    return b;
}
Buffer buildWhoosh() {
    Buffer b(0.40f);
    synth::tone(b, 0.0f, 0.38f, [](float){ return synth::noise(); },
        [](float){ return 1.0f; },
        [](float t){ float e = std::sin(t / 0.38f * PI); return e * e; }, 0.3f);
    return b;
}
Buffer buildCountdown() {
    Buffer b(0.30f);
    synth::tone(b, 0.0f, 0.18f, synth::sine, [](float){ return noteHz(0); },
        [](float t){ return synth::ad(t, 0.01f, 0.17f); }, 0.5f);
    return b;
}
Buffer buildGo() {
    Buffer b(0.55f);
    synth::tone(b, 0.0f, 0.5f, synth::square, [](float){ return noteHz(12); },
        [](float t){ return synth::expDecay(t, 0.28f); }, 0.42f);
    synth::tone(b, 0.0f, 0.5f, synth::sine, [](float){ return noteHz(19); },
        [](float t){ return synth::expDecay(t, 0.28f); }, 0.3f);
    return b;
}
Buffer buildWin() {
    Buffer b(1.3f);
    int arp[] = { 0, 4, 7, 12, 16, 19, 24 };
    for (int i = 0; i < 7; ++i) {
        synth::tone(b, i * 0.13f, 0.5f, synth::square,
            [i, &arp](float){ return noteHz(arp[i]); },
            [](float t){ return synth::expDecay(t, 0.30f); }, 0.26f);
    }
    return b;
}
Buffer buildLose() {
    Buffer b(1.0f);
    int arp[] = { 0, -3, -7, -12 };
    for (int i = 0; i < 4; ++i) {
        synth::tone(b, i * 0.18f, 0.6f, synth::tri,
            [i, &arp](float){ return noteHz(arp[i]); },
            [](float t){ return synth::expDecay(t, 0.35f); }, 0.34f);
    }
    return b;
}
Buffer buildUiMove() {
    Buffer b(0.10f);
    synth::tone(b, 0.0f, 0.08f, synth::square, [](float){ return noteHz(12); },
        [](float t){ return synth::expDecay(t, 0.02f); }, 0.22f);
    return b;
}
Buffer buildUiSelect() {
    Buffer b(0.22f);
    synth::tone(b, 0.0f,  0.08f, synth::square, [](float){ return noteHz(12); },
        [](float t){ return synth::expDecay(t, 0.05f); }, 0.3f);
    synth::tone(b, 0.06f, 0.14f, synth::square, [](float){ return noteHz(19); },
        [](float t){ return synth::expDecay(t, 0.08f); }, 0.3f);
    return b;
}
Buffer buildUiBack() {
    Buffer b(0.16f);
    synth::tone(b, 0.0f, 0.14f, synth::square, [](float){ return noteHz(5); },
        [](float t){ return synth::expDecay(t, 0.05f); }, 0.26f);
    return b;
}
Buffer buildDoorOpen() {
    Buffer b(0.7f);
    // Low groan with slow vibrato.
    synth::tone(b, 0.0f, 0.68f, synth::saw,
        [](float t){ return 70.0f + 18.0f * std::sin(t * 9.0f) + 30.0f * t; },
        [](float t){ float e = std::sin(t / 0.68f * PI); return e; }, 0.34f);
    return b;
}
Buffer buildSpooky() {
    Buffer b(1.4f);
    // Detuned chord shimmer — the "mysterious hallway" sting.
    synth::tone(b, 0.0f, 1.4f, synth::sine,
        [](float t){ return 130.0f * (1.0f + 0.01f * std::sin(t * 5.0f)); },
        [](float t){ return synth::ad(t, 0.4f, 1.0f); }, 0.22f);
    synth::tone(b, 0.0f, 1.4f, synth::sine,
        [](float t){ return 196.0f * (1.0f + 0.013f * std::sin(t * 4.3f)); },
        [](float t){ return synth::ad(t, 0.5f, 0.9f); }, 0.18f);
    synth::tone(b, 0.0f, 1.4f, synth::sine,
        [](float t){ return 233.0f * (1.0f + 0.009f * std::sin(t * 6.1f)); },
        [](float t){ return synth::ad(t, 0.6f, 0.8f); }, 0.14f);
    return b;
}
Buffer buildSplash() {
    Buffer b(0.4f);
    synth::tone(b, 0.0f, 0.38f, [](float){ return synth::noise(); },
        [](float){ return 1.0f; },
        [](float t){ return synth::expDecay(t, 0.10f); }, 0.34f);
    synth::tone(b, 0.0f, 0.20f, synth::sine,
        [](float t){ return 500.0f - 300.0f * t; },
        [](float t){ return synth::expDecay(t, 0.06f); }, 0.2f);
    return b;
}
Buffer buildTick() {
    Buffer b(0.06f);
    synth::tone(b, 0.0f, 0.04f, [](float){ return synth::noise(); },
        [](float){ return 1.0f; },
        [](float t){ return synth::expDecay(t, 0.01f); }, 0.3f);
    return b;
}
Buffer buildPowerup() {
    Buffer b(0.5f);
    synth::tone(b, 0.0f, 0.48f, synth::square,
        [](float t){ return 300.0f + 900.0f * t + 120.0f * std::sin(t * 40.0f); },
        [](float t){ return synth::expDecay(t, 0.22f); }, 0.3f);
    return b;
}

} // namespace

void Audio::init() {
    InitAudioDevice();
    if (!IsAudioDeviceReady()) {
        TraceLog(LOG_WARNING, "Audio: device not ready; running silent");
        ready_ = false;
        return;
    }
    ready_ = true;
    buildAllSfx();
    SetMasterVolume(1.0f);
}

void Audio::shutdown() {
    if (!ready_) return;
    for (auto& s : sfx_) UnloadSound(s);
    sfx_.clear();
    if (musicBedValid_) { UnloadSound(musicBed_); musicBedValid_ = false; }
    CloseAudioDevice();
    ready_ = false;
}

void Audio::buildAllSfx() {
    sfx_.resize((size_t)Sfx::COUNT);
    sfx_[(int)Sfx::Jump]      = synth::toSound(buildJump());
    sfx_[(int)Sfx::Land]      = synth::toSound(buildLand());
    sfx_[(int)Sfx::Dash]      = synth::toSound(buildDash());
    sfx_[(int)Sfx::Hit]       = synth::toSound(buildHit());
    sfx_[(int)Sfx::Bounce]    = synth::toSound(buildBounce());
    sfx_[(int)Sfx::Pop]       = synth::toSound(buildPop());
    sfx_[(int)Sfx::Coin]      = synth::toSound(buildCoin());
    sfx_[(int)Sfx::Whoosh]    = synth::toSound(buildWhoosh());
    sfx_[(int)Sfx::Countdown] = synth::toSound(buildCountdown());
    sfx_[(int)Sfx::Go]        = synth::toSound(buildGo());
    sfx_[(int)Sfx::Win]       = synth::toSound(buildWin());
    sfx_[(int)Sfx::Lose]      = synth::toSound(buildLose());
    sfx_[(int)Sfx::UiMove]    = synth::toSound(buildUiMove());
    sfx_[(int)Sfx::UiSelect]  = synth::toSound(buildUiSelect());
    sfx_[(int)Sfx::UiBack]    = synth::toSound(buildUiBack());
    sfx_[(int)Sfx::DoorOpen]  = synth::toSound(buildDoorOpen());
    sfx_[(int)Sfx::Spooky]    = synth::toSound(buildSpooky());
    sfx_[(int)Sfx::Splash]    = synth::toSound(buildSplash());
    sfx_[(int)Sfx::Tick]      = synth::toSound(buildTick());
    sfx_[(int)Sfx::Powerup]   = synth::toSound(buildPowerup());
}

void Audio::play(Sfx s, float volume, float pitchJitter) {
    if (!ready_) return;
    int i = (int)s;
    if (i < 0 || i >= (int)sfx_.size()) return;
    Sound& snd = sfx_[i];
    SetSoundVolume(snd, volume * sfxVol_);
    float pitch = 1.0f;
    if (pitchJitter > 0.0f)
        pitch += ((float)GetRandomValue(-1000, 1000) / 1000.0f) * pitchJitter;
    SetSoundPitch(snd, pitch);
    PlaySound(snd);
}

// --- Music ----------------------------------------------------------------
// The "music bed" is a short synthesised loop. When the desired mood changes
// we rebuild the bed; updateMusic() re-triggers it when it finishes so it
// loops seamlessly enough for a party game.

Sound Audio::makeMusicBed(Music m) {
    if (m == Music::None) return Sound{};
    Buffer b(4.8f);

    if (m == Music::Hub) {
        // Slow, eerie, sparse — the mysterious hallway.
        int notes[] = { 0, 3, 7, 10, 7, 3 };
        for (int i = 0; i < 6; ++i) {
            float start = i * 0.8f;
            synth::tone(b, start, 1.4f, synth::sine,
                [i,&notes](float){ return noteHz(notes[i] - 12); },
                [](float t){ return synth::ad(t, 0.25f, 1.1f) * 0.8f; }, 0.16f);
            synth::tone(b, start, 1.4f, synth::tri,
                [i,&notes](float){ return noteHz(notes[i] + 7); },
                [](float t){ return synth::ad(t, 0.4f, 0.9f) * 0.5f; }, 0.07f);
        }
    } else if (m == Music::Minigame) {
        // Driving, bouncy pulse.
        for (int beat = 0; beat < 16; ++beat) {
            float start = beat * 0.30f;
            int bass[] = { 0, 0, 5, 7 };
            synth::tone(b, start, 0.16f, synth::square,
                [beat,&bass](float){ return noteHz(bass[beat % 4] - 12); },
                [](float t){ return synth::expDecay(t, 0.08f); }, 0.18f);
            if (beat % 2 == 0) {
                int lead[] = { 12, 16, 19, 16 };
                synth::tone(b, start, 0.22f, synth::square,
                    [beat,&lead](float){ return noteHz(lead[(beat/2) % 4]); },
                    [](float t){ return synth::expDecay(t, 0.10f); }, 0.12f);
            }
        }
    } else { // Results
        int chord[] = { 0, 4, 7, 11 };
        for (int i = 0; i < 4; ++i) {
            synth::tone(b, 0.0f, 4.6f, synth::sine,
                [i,&chord](float){ return noteHz(chord[i]); },
                [](float t){ return synth::ad(t, 0.5f, 4.0f) * 0.7f; }, 0.10f);
        }
    }
    return synth::toSound(b);
}

void Audio::setMusic(Music m) {
    musicWanted_ = m;
}

void Audio::buildMusic(Music m) {
    if (!ready_) return;
    if (musicBedValid_) { StopSound(musicBed_); UnloadSound(musicBed_); musicBedValid_ = false; }
    if (m == Music::None) { musicCurrent_ = Music::None; return;}
    musicBed_ = makeMusicBed(m);
    musicBedValid_ = true;
    musicCurrent_ = m;
    SetSoundVolume(musicBed_, musicVol_);
    PlaySound(musicBed_);
}

void Audio::updateMusic() {
    if (!ready_) return;
    if (musicWanted_ != musicCurrent_) {
        buildMusic(musicWanted_);
        return;
    }
    // Loop: when the bed finishes, retrigger it.
    if (musicBedValid_ && !IsSoundPlaying(musicBed_)) {
        SetSoundVolume(musicBed_, musicVol_);
        PlaySound(musicBed_);
    }
}

void Audio::setMusicVolume(float v) {
    musicVol_ = v;
    if (musicBedValid_) SetSoundVolume(musicBed_, musicVol_);
}

void Audio::setSfxVolume(float v) { sfxVol_ = v; }
