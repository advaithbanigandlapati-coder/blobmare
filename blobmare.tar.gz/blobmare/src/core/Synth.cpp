#include "core/Synth.h"
#include <algorithm>

namespace synth {

Sound toSound(const Buffer& b) {
    size_t n = b.size();
    if (n == 0) n = 1;

    std::vector<int16_t> pcm(n, 0);
    for (size_t i = 0; i < b.size(); ++i) {
        float v = b.s[i];
        // Soft clip so accidental overdrive doesn't crackle harshly.
        v = std::tanh(v * 1.2f);
        if (v > 1.0f) v = 1.0f;
        if (v < -1.0f) v = -1.0f;
        pcm[i] = (int16_t)(v * 32000.0f);
    }

    Wave w{};
    w.frameCount = (unsigned int)n;
    w.sampleRate = (unsigned int)kSampleRate;
    w.sampleSize = 16;
    w.channels   = 1;
    w.data       = pcm.data();   // copied by LoadSoundFromWave

    Sound s = LoadSoundFromWave(w);
    return s;
}

} // namespace synth
