#pragma once
// Per-player input abstraction. Gameplay code NEVER touches raylib input
// directly — it reads PlayerInput. Player 1 = keyboard (WASD). Player 2 =
// gamepad if one is connected (hot-plug aware), else keyboard (arrows + numpad).
#include "raylib.h"

struct PlayerInput {
    Vector2 move{0, 0};     // magnitude clamped to <= 1
    bool jump = false,   jumpPressed = false;
    bool action = false, actionPressed = false;
    bool dash = false,   dashPressed = false;
};

class Input {
public:
    void update();   // call once per fixed sim step

    const PlayerInput& player(int i) const { return cur_[i & 1]; }

    // True if player 2 is currently driven by a gamepad.
    bool p2UsesGamepad() const { return p2Gamepad_ >= 0; }

    // --- Menu / global helpers (aggregate of both players + UI keys) -----
    bool confirmPressed() const;
    bool cancelPressed() const;
    bool pausePressed() const;
    int  navX() const;        // edge: -1 / 0 / +1
    int  navY() const;        // edge: -1 / 0 / +1
    bool anyActionPressed() const;

private:
    PlayerInput cur_[2]{}, prev_[2]{};
    int  p2Gamepad_ = -1;
    bool navXLatch_ = false, navYLatch_ = false;
    int  navXEdge_ = 0, navYEdge_ = 0;

    void readPlayer1(PlayerInput& out);
    void readPlayer2(PlayerInput& out);
};
