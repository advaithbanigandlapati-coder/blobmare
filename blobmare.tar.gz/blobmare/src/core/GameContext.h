#pragma once
// GameContext bundles every shared service so scenes and minigames receive a
// single reference instead of a long argument list. It is created once in
// main() and lives for the whole process.
#include "raylib.h"
#include "core/Input.h"
#include "core/Audio.h"
#include "core/Lighting.h"
#include "core/GameCamera.h"
#include "fx/ScreenShake.h"
#include "fx/Particles.h"
#include "game/MatchState.h"
#include "net/NetPlay.h"
#include "blob/BlobLimbs.h"

// Persistent match/run configuration chosen on the menus.
struct MatchConfig {
    int  roundsToWin   = 4;     // first blob to this many wins the match
    int  minigameCount = 5;     // minigames drawn per match
    bool friendlyNames = true;
    // Per-player cosmetic identity.
    Color playerColor[2] = {
        Color{ 255, 122, 138, 255 },   // P1 — coral
        Color{ 122, 196, 255, 255 },   // P2 — sky
    };
    float playerSize[2] = { 0.0f, 0.0f };  // -1..1 personality
    const char* playerName[2] = { "Rosa", "Cyan" };
    // Per-player custom character — the limb loadout built in the editor.
    // Empty by default until edited; blobs fall back to the default critter.
    LimbLoadout playerLimbs[2];
    bool        playerLimbsCustom[2] = { false, false };
};

// Player-facing settings, adjusted from the pause menu / settings screen.
struct Settings {
    float musicVolume = 0.55f;
    float sfxVolume   = 0.85f;
    bool  fullscreen  = false;
    bool  screenShake = true;     // master toggle for shake (accessibility)
};

struct GameContext {
    int screenW = 1280;
    int screenH = 720;

    Input        input;
    Audio        audio;
    Lighting     lighting;
    GameCamera   camera;
    ScreenShake  shake;
    ParticleSystem particles;

    MatchConfig  config;
    MatchState   match;
    NetPlay      net;        // Local by default; offline game is unaffected.
    Settings     settings;

    // Set true while the pause overlay is up; scenes freeze their sim.
    bool  paused = false;

    // Global slow-motion / hit-stop multiplier applied to gameplay dt.
    float timeScale = 1.0f;
    // Set true to request the whole application exit cleanly.
    bool  quitRequested = false;

    float aspect() const { return (float)screenW / (float)screenH; }
};
