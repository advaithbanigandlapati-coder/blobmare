#include "core/Lighting.h"
#include "raymath.h"
#include "rlgl.h"
#include <cmath>

// =============================================================================
//  Shaders
// =============================================================================
namespace {

// --- Main lit shader: diffuse + ambient + specular + rim + shadow sampling --
const char* kVertex = R"(#version 330
in vec3 vertexPosition;
in vec2 vertexTexCoord;
in vec3 vertexNormal;
in vec4 vertexColor;
uniform mat4 mvp;
uniform mat4 matModel;
uniform mat4 matNormal;
uniform mat4 lightVP;          // light-space view-projection
out vec3 fragNormal;
out vec4 fragColor;
out vec3 fragWorld;
out vec4 fragLightSpace;       // position in light clip space (for shadows)
void main() {
    fragColor      = vertexColor;
    fragNormal     = normalize(vec3(matNormal * vec4(vertexNormal, 0.0)));
    fragWorld      = vec3(matModel * vec4(vertexPosition, 1.0));
    fragLightSpace = lightVP * vec4(fragWorld, 1.0);
    gl_Position    = mvp * vec4(vertexPosition, 1.0);
}
)";

const char* kFragment = R"(#version 330
in vec3 fragNormal;
in vec4 fragColor;
in vec3 fragWorld;
in vec4 fragLightSpace;
uniform vec4  colDiffuse;
uniform vec3  lightDir;
uniform vec3  lightColor;
uniform vec3  viewPos;
uniform vec3  ambient;
uniform sampler2D shadowMap;
uniform int   shadowOn;
out vec4 finalColor;

// Percentage-closer filtering: average several depth comparisons around the
// sample point so shadow edges are soft, not jagged.
float shadowFactor(vec3 N, vec3 L) {
    if (shadowOn == 0) return 1.0;
    vec3 proj = fragLightSpace.xyz / fragLightSpace.w;
    proj = proj * 0.5 + 0.5;                       // [-1,1] -> [0,1]
    if (proj.z > 1.0) return 1.0;                  // beyond far plane: lit
    if (proj.x < 0.0 || proj.x > 1.0 ||
        proj.y < 0.0 || proj.y > 1.0) return 1.0;  // outside map: lit
    // Slope-scaled bias kills shadow acne on grazing surfaces.
    float bias = max(0.0025 * (1.0 - dot(N, L)), 0.0008);
    float lit = 0.0;
    vec2 texel = 1.0 / vec2(textureSize(shadowMap, 0));
    // 5x5 PCF for noticeably softer contact shadows.
    for (int x = -2; x <= 2; ++x) {
        for (int y = -2; y <= 2; ++y) {
            float d = texture(shadowMap, proj.xy + vec2(x,y) * texel).r;
            lit += (proj.z - bias > d) ? 0.0 : 1.0;
        }
    }
    return lit / 25.0;
}

void main() {
    vec3 N = normalize(fragNormal);
    vec3 L = normalize(-lightDir);
    vec3 V = normalize(viewPos - fragWorld);
    vec3 H = normalize(L + V);

    // --- Key light. Exaggerated for a bold, stylised read: the lit side is
    //     bright, the shadow side genuinely darkens, so even a small ball
    //     looks unmistakably round and three-dimensional. ------------------
    float ndl  = dot(N, L);
    float key  = ndl * 0.5 + 0.5;                 // 0..1 across the sphere
    key        = smoothstep(0.05, 0.95, key);     // punchy terminator
    key        = key * 0.85 + 0.15;               // keep shadow side alive

    // --- Coloured fill from the opposite/upper side so the dark half reads
    //     as cool shadow, not dead grey. ---------------------------------
    vec3  fillDir = normalize(vec3(-L.x, 0.5, -L.z));
    float fill    = max(dot(N, fillDir), 0.0) * 0.35;

    // --- Glossy specular: a tight bright hotspot — the strongest cue for a
    //     smooth, solid, rounded surface. --------------------------------
    float specP = pow(max(dot(N, H), 0.0), 80.0);
    float spec  = specP * 0.9;
    float sheen = pow(max(dot(N, H), 0.0), 10.0) * 0.22;

    float shadow = shadowFactor(N, L);
    float lit    = key * shadow;

    // --- Fresnel rim — pops the silhouette off the background. -----------
    float fres = pow(1.0 - max(dot(N, V), 0.0), 3.0);
    float rim  = fres * 0.6;

    // --- Vertical ambient gradient: top of every object a touch brighter,
    //     bottom a touch darker — a cheap global-illumination feel that
    //     grounds the form. ---------------------------------------------
    float vgrad = clamp(N.y * 0.5 + 0.5, 0.0, 1.0);
    float ao    = mix(0.7, 1.08, vgrad);

    vec3 base = fragColor.rgb * colDiffuse.rgb;

    // Compose.
    vec3 col  = base * (ambient * ao + lightColor * lit);
    col      += base * lightColor * fill;
    col      += lightColor * spec * shadow;             // hot specular
    col      += base * sheen;
    col      += rim * vec3(1.0, 0.92, 0.8);

    // --- A subtle darkened core toward the lower-front, like a soft-body
    //     occlusion — adds chunky stylised volume. ---------------------
    float core = smoothstep(0.0, 1.0, 1.0 - vgrad) * 0.12;
    col *= (1.0 - core);

    // --- Punchy stylised grade. ----------------------------------------
    float lum = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(vec3(lum), col, 1.25);                  // saturation
    col = (col - 0.5) * 1.12 + 0.5;                   // contrast
    col = clamp(col, 0.0, 1.0);
    col = pow(col, vec3(0.92));

    // Force opaque: world geometry is never see-through.
    finalColor = vec4(col, 1.0);
}
)";

// --- Depth-only shader for the shadow pass ----------------------------------
const char* kDepthVertex = R"(#version 330
in vec3 vertexPosition;
uniform mat4 mvp;
void main() { gl_Position = mvp * vec4(vertexPosition, 1.0); }
)";
const char* kDepthFragment = R"(#version 330
void main() { }   // depth is written automatically; no colour needed
)";

} // namespace

// =============================================================================
//  Lighting
// =============================================================================

void Lighting::init() {
    shader_ = LoadShaderFromMemory(kVertex, kFragment);
    valid_  = IsShaderValid(shader_);
    if (!valid_) {
        TraceLog(LOG_WARNING, "Lighting: main shader failed; unlit fallback");
        return;
    }
    locLightDir_   = GetShaderLocation(shader_, "lightDir");
    locViewPos_    = GetShaderLocation(shader_, "viewPos");
    locAmbient_    = GetShaderLocation(shader_, "ambient");
    locLightColor_ = GetShaderLocation(shader_, "lightColor");
    locLightVP_    = GetShaderLocation(shader_, "lightVP");
    locShadowMap_  = GetShaderLocation(shader_, "shadowMap");
    locShadowOn_   = GetShaderLocation(shader_, "shadowOn");

    setLightDirection(Vector3{ -0.45f, -1.0f, -0.35f });
    setAmbient(Color{ 58, 56, 78, 255 });
    setLightColor(Color{ 255, 244, 224, 255 });

    // --- Shadow resources ---------------------------------------------------
    depthShader_ = LoadShaderFromMemory(kDepthVertex, kDepthFragment);
    if (IsShaderValid(depthShader_)) {
        // A depth render texture: raylib's RenderTexture has a depth buffer
        // we can sample. We use its depth attachment as the shadow map.
        shadowMap_ = LoadRenderTexture(kShadowRes, kShadowRes);
        shadowValid_ = IsRenderTextureValid(shadowMap_);
        if (shadowValid_) {
            SetTextureFilter(shadowMap_.depth, TEXTURE_FILTER_BILINEAR);
            SetTextureWrap(shadowMap_.depth, TEXTURE_WRAP_CLAMP);
        }
    }
    if (!shadowValid_)
        TraceLog(LOG_WARNING, "Lighting: shadow map unavailable; lit-only");

    // Default shadows-off until a shadow pass runs.
    int off = 0;
    SetShaderValue(shader_, locShadowOn_, &off, SHADER_UNIFORM_INT);
}

void Lighting::shutdown() {
    if (valid_)        { UnloadShader(shader_); valid_ = false; }
    if (shadowValid_)  { UnloadRenderTexture(shadowMap_); shadowValid_ = false; }
    if (IsShaderValid(depthShader_)) UnloadShader(depthShader_);
}

void Lighting::setCamera(Vector3 cameraPos) {
    camEye_ = cameraPos;
    if (!valid_) return;
    float v[3] = { cameraPos.x, cameraPos.y, cameraPos.z };
    SetShaderValue(shader_, locViewPos_, v, SHADER_UNIFORM_VEC3);
}

void Lighting::setLightDirection(Vector3 dir) {
    lightDir_ = Vector3Normalize(dir);
    if (!valid_) return;
    float v[3] = { lightDir_.x, lightDir_.y, lightDir_.z };
    SetShaderValue(shader_, locLightDir_, v, SHADER_UNIFORM_VEC3);
}

void Lighting::setAmbient(Color a) {
    if (!valid_) return;
    float v[3] = { a.r / 255.0f, a.g / 255.0f, a.b / 255.0f };
    SetShaderValue(shader_, locAmbient_, v, SHADER_UNIFORM_VEC3);
}

void Lighting::setLightColor(Color c) {
    if (!valid_) return;
    float v[3] = { c.r / 255.0f, c.g / 255.0f, c.b / 255.0f };
    SetShaderValue(shader_, locLightColor_, v, SHADER_UNIFORM_VEC3);
}

void Lighting::setShadowFocus(Vector3 focus, float radius) {
    shadowFocus_ = focus;
    shadowRadius_ = (radius > 1.0f) ? radius : 1.0f;
}

// --- Light camera -----------------------------------------------------------
// An orthographic camera looking along the light direction at the focus
// point, sized to the shadow radius. Orthographic = parallel rays = a
// directional sun.
void Lighting::computeLightCamera() {
    float dist = shadowRadius_ * 2.2f;
    lightCam_.position = Vector3Subtract(shadowFocus_,
                                         Vector3Scale(lightDir_, dist));
    lightCam_.target   = shadowFocus_;
    lightCam_.up       = Vector3{ 0, 1, 0 };
    // Guard against the up vector aligning with the light direction.
    if (fabsf(Vector3DotProduct(Vector3Normalize(
            Vector3Subtract(lightCam_.target, lightCam_.position)),
            lightCam_.up)) > 0.98f)
        lightCam_.up = Vector3{ 0, 0, 1 };
    lightCam_.fovy = shadowRadius_ * 2.0f;        // ortho "height"
    lightCam_.projection = CAMERA_ORTHOGRAPHIC;
}

void Lighting::beginShadowPass() {
    if (!shadowValid_) return;
    computeLightCamera();

    BeginTextureMode(shadowMap_);
    ClearBackground(WHITE);                       // white = far depth
    rlClearScreenBuffers();
    BeginMode3D(lightCam_);

    // Capture the light-space view-projection while the matrices are current.
    Matrix view = rlGetMatrixModelview();
    Matrix proj = rlGetMatrixProjection();
    lightVP_ = MatrixMultiply(view, proj);

    inShadowPass_ = true;
    // Front-face culling during the depth pass reduces "peter-panning".
    rlSetCullFace(RL_CULL_FACE_FRONT);
}

void Lighting::endShadowPass() {
    if (!shadowValid_ || !inShadowPass_) return;
    rlSetCullFace(RL_CULL_FACE_BACK);
    EndMode3D();
    EndTextureMode();
    inShadowPass_ = false;

    // Upload the light matrix + bind the shadow map for the main pass.
    if (valid_) {
        SetShaderValueMatrix(shader_, locLightVP_, lightVP_);
        int on = 1;
        SetShaderValue(shader_, locShadowOn_, &on, SHADER_UNIFORM_INT);
        // The shadow map occupies a high texture slot so it never clashes
        // with raylib's default material textures (slot 0).
        SetShaderValueTexture(shader_, locShadowMap_, shadowMap_.depth);
    }
}

void Lighting::begin() {
    if (inShadowPass_) {
        // During the shadow pass, geometry must be drawn with the depth-only
        // shader. This lets a scene simply call its normal draw3D() twice —
        // once inside the shadow pass, once in the main pass — with no
        // per-minigame changes.
        if (IsShaderValid(depthShader_)) {
            BeginShaderMode(depthShader_);
            inMode_ = true;
        }
        return;
    }
    if (valid_) { BeginShaderMode(shader_); inMode_ = true; }
}

void Lighting::end() {
    if (inMode_) { EndShaderMode(); inMode_ = false; }
}
