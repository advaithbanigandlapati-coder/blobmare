#pragma once
// Small immediate-mode 2D helpers shared by every screen and minigame HUD.
// Keeps drawing code terse and visually consistent.
#include "raylib.h"

namespace ui {

// Palette — the Blobmare look: dim, warm-shadowed, slightly eerie.
// (Used in-match for the spooky-hallway mood.)
inline Color bg()        { return Color{ 18, 16, 26, 255 }; }
inline Color ink()       { return Color{ 240, 236, 246, 255 }; }
inline Color inkDim()    { return Color{ 150, 145, 165, 255 }; }
inline Color accent()    { return Color{ 255, 196, 92, 255 }; }   // warm lamp gold
inline Color accent2()   { return Color{ 132, 206, 255, 255 }; }  // cold spectral blue
inline Color danger()    { return Color{ 255, 96, 104, 255 }; }
inline Color panel()     { return Color{ 28, 25, 40, 235 }; }

// Candy palette — the bright, bouncy front-of-house look for menus and
// shells (Fall-Guys energy: cheerful, saturated, friendly).
namespace candy {
inline Color sky()    { return Color{ 124, 198, 255, 255 }; }   // bright sky blue
inline Color skyTop() { return Color{  92, 168, 245, 255 }; }   // deeper top
inline Color cream()  { return Color{ 255, 250, 238, 255 }; }   // panel cream
inline Color grape()  { return Color{ 138,  96, 222, 255 }; }   // purple pop
inline Color mint()   { return Color{ 104, 224, 178, 255 }; }   // mint green
inline Color coral()  { return Color{ 255, 122, 138, 255 }; }   // warm coral
inline Color sun()    { return Color{ 255, 206,  84, 255 }; }   // sunny yellow
inline Color ink()    { return Color{  46,  40,  66, 255 }; }   // deep ink text
inline Color shade()  { return Color{  34,  30,  54, 110 }; }   // soft shadow
}


void shadowText(const char* text, int x, int y, int size, Color color);
void centerText(const char* text, int cx, int y, int size, Color color);
void centerTextShadow(const char* text, int cx, int y, int size, Color color);

// A soft rounded panel with a faint border.
void panelBox(Rectangle r, Color fill, Color border, float roundness = 0.16f);

// A horizontal progress / timer bar.
void bar(Rectangle r, float t01, Color fill, Color back);

// Pulsing value useful for "press to start" prompts: returns 0..1.
float pulse(float speed = 3.0f);

// Vignette overlay for the whole screen — central to the spooky-hallway mood.
void vignette(int w, int h, float strength);

} // namespace ui
