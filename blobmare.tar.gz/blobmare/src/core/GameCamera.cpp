#include "core/GameCamera.h"
#include "fx/ScreenShake.h"
#include "fx/Easing.h"
#include "raymath.h"
#include <cmath>

void GameCamera::init() {
    cam_.position   = Vector3{ 0.0f, height_, baseDist_ };
    cam_.target     = Vector3{ 0.0f, 1.0f, 0.0f };
    cam_.up         = Vector3{ 0.0f, 1.0f, 0.0f };
    cam_.fovy       = 50.0f;
    cam_.projection = CAMERA_PERSPECTIVE;
    focus_ = cam_.target;
    initialized_ = true;
}

void GameCamera::setTargets(const std::vector<Vector3>& pts) {
    targets_ = pts;
}

void GameCamera::setStaticShot(Vector3 eye, Vector3 target) {
    staticShot_   = true;
    staticEye_    = eye;
    staticTarget_ = target;
}

void GameCamera::snap() {
    if (staticShot_) {
        focus_ = staticTarget_;
        return;
    }
    if (targets_.empty()) return;
    Vector3 mid{0,0,0};
    for (const auto& p : targets_) mid = Vector3Add(mid, p);
    mid = Vector3Scale(mid, 1.0f / targets_.size());
    focus_ = mid;
    spread_ = 0.0f;
    for (const auto& p : targets_) {
        float d = Vector3Distance(p, mid);
        if (d > spread_) spread_ = d;
    }
}

void GameCamera::update(float dt, const ScreenShake& shake) {
    if (!initialized_) init();

    Vector3 desiredFocus;
    float   desiredDist, desiredHeight, desiredPitch;

    if (staticShot_) {
        desiredFocus  = staticTarget_;
        Vector3 off   = Vector3Subtract(staticEye_, staticTarget_);
        desiredDist   = std::sqrt(off.x*off.x + off.z*off.z);
        desiredHeight = off.y;
        desiredPitch  = pitchDeg_;
    } else {
        // Midpoint of all targets.
        Vector3 mid{0,0,0};
        if (!targets_.empty()) {
            for (const auto& p : targets_) mid = Vector3Add(mid, p);
            mid = Vector3Scale(mid, 1.0f / targets_.size());
        }
        // Max spread from the midpoint -> pull back to keep everyone framed.
        float sp = 0.0f;
        for (const auto& p : targets_) {
            float d = Vector3Distance(p, mid);
            if (d > sp) sp = d;
        }
        spread_ = ease::approach(spread_, sp, 5.0f, dt);
        desiredFocus  = mid;
        desiredDist   = baseDist_ + spread_ * 1.05f;
        desiredHeight = height_   + spread_ * 0.55f;
        desiredPitch  = pitchDeg_;
    }

    // Ease the focus point.
    focus_.x = ease::approach(focus_.x, desiredFocus.x, 7.0f, dt);
    focus_.y = ease::approach(focus_.y, desiredFocus.y, 7.0f, dt);
    focus_.z = ease::approach(focus_.z, desiredFocus.z, 7.0f, dt);

    // Compose the base transform: behind (+Z) and above the focus.
    float pitchRad = desiredPitch * DEG2RAD;
    Vector3 baseEye{
        focus_.x,
        focus_.y + std::sin(pitchRad) * desiredDist,
        focus_.z + std::cos(pitchRad) * desiredDist,
    };
    (void)desiredHeight; // height folded into the pitch/distance solve

    // Apply screen shake additively.
    Vector3 shakeOff = shake.positionalOffset();
    cam_.position = Vector3Add(baseEye, shakeOff);
    cam_.target   = Vector3Add(focus_, Vector3Scale(shakeOff, 0.35f));

    // Roll the up vector slightly for shake punch.
    float roll = shake.rollDegrees() * DEG2RAD;
    cam_.up = Vector3{ std::sin(roll), std::cos(roll), 0.0f };
}
