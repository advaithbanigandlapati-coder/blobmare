#pragma once
// Tiny offline synth toolkit: build a buffer of 16-bit mono samples, then
// hand it to raylib as a Wave/Sound. Used only at startup.
#include "raylib.h"
#include <vector>
#include <cstdint>
#include <cmath>

namespace synth {

constexpr int kSampleRate = 44100;

// A mono buffer of normalised float samples in roughly [-1, 1].
struct Buffer {
    std::vector<float> s;
    explicit Buffer(float seconds = 0.0f)
        : s((size_t)(seconds * kSampleRate), 0.0f) {}
    size_t size() const { return s.size(); }
    float  duration() const { return (float)s.size() / kSampleRate; }
    void   ensure(float seconds) {
        size_t n = (size_t)(seconds * kSampleRate);
        if (n > s.size()) s.resize(n, 0.0f);
    }
};

// --- Oscillators (phase in cycles) ----------------------------------------
inline float sine(float ph)  { return std::sin(ph * 2.0f * PI); }
inline float square(float ph){ return (ph - std::floor(ph)) < 0.5f ? 1.0f : -1.0f; }
inline float saw(float ph)   { float f = ph - std::floor(ph); return 2.0f * f - 1.0f; }
inline float tri(float ph)   { float f = ph - std::floor(ph);
                               return 4.0f * std::fabs(f - 0.5f) - 1.0f; }
inline float noise()         { return (float)GetRandomValue(-10000, 10000) / 10000.0f; }

// --- Envelopes -------------------------------------------------------------
// Linear attack/decay; 't' and the times are in seconds.
inline float ad(float t, float attack, float decay) {
    if (t < attack)          return attack > 0 ? t / attack : 1.0f;
    float d = t - attack;
    if (d < decay)           return decay > 0 ? 1.0f - d / decay : 0.0f;
    return 0.0f;
}
// Exponential decay.
inline float expDecay(float t, float halfLife) {
    return std::pow(0.5f, t / (halfLife > 0 ? halfLife : 0.001f));
}

// Mix a tone into the buffer with a per-sample frequency function.
template <typename Osc, typename FreqFn, typename EnvFn>
inline void tone(Buffer& b, float start, float dur,
                  Osc osc, FreqFn freq, EnvFn env, float gain) {
    b.ensure(start + dur);
    float phase = 0.0f;
    int i0 = (int)(start * kSampleRate);
    int n  = (int)(dur * kSampleRate);
    for (int i = 0; i < n; ++i) {
        float t = (float)i / kSampleRate;
        float f = freq(t);
        phase += f / kSampleRate;
        b.s[(size_t)(i0 + i)] += osc(phase) * env(t) * gain;
    }
}

// Convert to a raylib Sound (16-bit PCM mono). Caller owns the Sound.
Sound toSound(const Buffer& b);

} // namespace synth
