#pragma once
// A 3D follow camera that keeps a set of targets (the two blobs) framed.
// It eases toward a midpoint and pulls back as the blobs spread out, so a
// two-player party game never loses anyone off-screen. Screen shake is
// layered on top without disturbing the smoothed base transform.
#include "raylib.h"
#include <vector>

class ScreenShake;

class GameCamera {
public:
    void init();

    // Replace the list of points the camera should keep in frame.
    void setTargets(const std::vector<Vector3>& pts);

    // Optional fixed look-at override (used by menus / cinematic shots).
    void setStaticShot(Vector3 eye, Vector3 target);
    void clearStaticShot() { staticShot_ = false; }

    // Camera framing tuning.
    void setHeight(float h)    { height_ = h; }
    void setDistance(float d)  { baseDist_ = d; }
    void setPitch(float deg)   { pitchDeg_ = deg; }

    void update(float dt, const ScreenShake& shake);

    const Camera3D& cam() const { return cam_; }
    Camera3D&       cam()       { return cam_; }
    Vector3 eye() const         { return cam_.position; }

    // Snap instantly to the current target (no easing) — for scene changes.
    void snap();

private:
    Camera3D cam_{};
    std::vector<Vector3> targets_;
    Vector3 focus_{0, 0, 0};      // smoothed look-at point
    float   spread_ = 0.0f;       // smoothed target spread
    float   height_   = 9.0f;
    float   baseDist_ = 13.0f;
    float   pitchDeg_ = 38.0f;
    bool    staticShot_ = false;
    Vector3 staticEye_{0,0,0}, staticTarget_{0,0,0};
    bool    initialized_ = false;
};
