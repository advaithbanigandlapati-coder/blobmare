#pragma once
// =============================================================================
//  Lighting — real-time shaded renderer with shadow mapping
// =============================================================================
//
//  This is the game's lighting/render layer. It provides:
//    * A directional "sun" with diffuse + ambient + soft specular.
//    * REAL SHADOW MAPPING — geometry is rendered once from the light's point
//      of view into a depth texture, then the main pass samples that depth to
//      decide what is in shadow. This is what grounds the blobs: they cast
//      and receive real soft shadows.
//    * A subtle rim light for a stylised, readable silhouette.
//    * Guaranteed opaque rendering (depth write on, no blend) so geometry is
//      never see-through.
//
//  USAGE (per frame, per scene):
//      lighting.setCamera(camEye);
//      lighting.beginShadowPass();         // 1st: render depth from the light
//          ... draw all shadow-casting 3D geometry ...
//      lighting.endShadowPass();
//      BeginMode3D(cam);
//          lighting.begin();               // 2nd: the lit main pass
//              ... draw the same 3D geometry ...
//          lighting.end();
//      EndMode3D();
//
//  beginShadowPass/endShadowPass are optional — a scene that skips them still
//  renders fully lit, just without cast shadows. Existing begin()/end() calls
//  keep working unchanged.
//
//  Degrades gracefully: if a shader or the shadow FBO fails on the host GL
//  driver, it falls back to plain lit (or unlit) rendering without crashing.
//
#include "raylib.h"

class Lighting {
public:
    void init();
    void shutdown();

    void setCamera(Vector3 cameraPos);
    void setLightDirection(Vector3 dir);
    void setAmbient(Color ambient);
    void setLightColor(Color c);
    void setShadowFocus(Vector3 worldFocus, float radius);

    // --- Shadow depth pass ----------------------------------------------
    void beginShadowPass();
    void endShadowPass();
    bool shadowsActive() const { return shadowValid_; }

    // --- Lit main pass --------------------------------------------------
    void begin();
    void end();

    bool active() const { return valid_; }

private:
    Shader shader_{};
    bool   valid_  = false;
    bool   inMode_ = false;

    Shader depthShader_{};
    RenderTexture2D shadowMap_{};
    bool   shadowValid_ = false;
    bool   inShadowPass_ = false;

    Matrix lightVP_{};
    Camera3D lightCam_{};

    Vector3 lightDir_    = Vector3{ -0.45f, -1.0f, -0.35f };
    Vector3 shadowFocus_ = Vector3{ 0, 0, 0 };
    float   shadowRadius_= 18.0f;
    Vector3 camEye_      = Vector3{ 0, 10, 10 };

    int locLightDir_ = -1, locViewPos_ = -1, locAmbient_ = -1;
    int locLightColor_ = -1, locLightVP_ = -1, locShadowMap_ = -1;
    int locShadowOn_ = -1;

    static constexpr int kShadowRes = 2048;

    void computeLightCamera();
};
