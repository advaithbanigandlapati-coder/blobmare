#include "core/UIText.h"
#include <cmath>

namespace ui {

void shadowText(const char* text, int x, int y, int size, Color color) {
    DrawText(text, x + 2, y + 2, size, Color{0, 0, 0, (unsigned char)(color.a * 0.6f)});
    DrawText(text, x, y, size, color);
}

void centerText(const char* text, int cx, int y, int size, Color color) {
    int w = MeasureText(text, size);
    DrawText(text, cx - w / 2, y, size, color);
}

void centerTextShadow(const char* text, int cx, int y, int size, Color color) {
    int w = MeasureText(text, size);
    shadowText(text, cx - w / 2, y, size, color);
}

void panelBox(Rectangle r, Color fill, Color border, float roundness) {
    DrawRectangleRounded(r, roundness, 8, fill);
    DrawRectangleRoundedLines(r, roundness, 8, border);
}

void bar(Rectangle r, float t01, Color fill, Color back) {
    if (t01 < 0.0f) t01 = 0.0f;
    if (t01 > 1.0f) t01 = 1.0f;
    DrawRectangleRounded(r, 0.5f, 6, back);
    if (t01 > 0.001f) {
        Rectangle f = r;
        f.width = r.width * t01;
        if (f.width < r.height) f.width = r.height; // keep the cap round
        DrawRectangleRounded(f, 0.5f, 6, fill);
    }
}

float pulse(float speed) {
    return 0.5f + 0.5f * std::sin((float)GetTime() * speed);
}

void vignette(int w, int h, float strength) {
    // Cheap radial darkening: concentric translucent rings from the edges in.
    int rings = 48;
    float maxR = (float)((w > h ? w : h));
    for (int i = 0; i < rings; ++i) {
        float t = (float)i / rings;             // 0 center .. 1 edge
        unsigned char a = (unsigned char)(strength * 255.0f * t * t / rings * 6.0f);
        if (a == 0) continue;
        float inset = (1.0f - t) * 0.5f;
        DrawRectangleLinesEx(
            Rectangle{ w * inset, h * inset, w * (1.0f - 2*inset), h * (1.0f - 2*inset) },
            maxR / rings, Color{0, 0, 0, a});
    }
}

} // namespace ui
