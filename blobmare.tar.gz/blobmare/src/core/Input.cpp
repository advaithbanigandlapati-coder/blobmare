#include "core/Input.h"
#include "raymath.h"
#include <cmath>

namespace {
Vector2 clampMove(Vector2 v) {
    float len = std::sqrt(v.x * v.x + v.y * v.y);
    if (len > 1.0f) { v.x /= len; v.y /= len; }
    return v;
}
} // namespace

void Input::readPlayer1(PlayerInput& out) {
    Vector2 m{0, 0};
    if (IsKeyDown(KEY_D)) m.x += 1.0f;
    if (IsKeyDown(KEY_A)) m.x -= 1.0f;
    if (IsKeyDown(KEY_W)) m.y -= 1.0f; // -y = forward (away from camera)
    if (IsKeyDown(KEY_S)) m.y += 1.0f;
    out.move   = clampMove(m);
    out.jump   = IsKeyDown(KEY_SPACE);
    out.action = IsKeyDown(KEY_J) || IsKeyDown(KEY_F);
    out.dash   = IsKeyDown(KEY_LEFT_SHIFT) || IsKeyDown(KEY_K);
}

void Input::readPlayer2(PlayerInput& out) {
    if (p2Gamepad_ >= 0 && IsGamepadAvailable(p2Gamepad_)) {
        Vector2 m{
            GetGamepadAxisMovement(p2Gamepad_, GAMEPAD_AXIS_LEFT_X),
            GetGamepadAxisMovement(p2Gamepad_, GAMEPAD_AXIS_LEFT_Y),
        };
        if (std::fabs(m.x) < 0.2f) m.x = 0.0f; // deadzone
        if (std::fabs(m.y) < 0.2f) m.y = 0.0f;
        // D-pad fallback / supplement.
        if (IsGamepadButtonDown(p2Gamepad_, GAMEPAD_BUTTON_LEFT_FACE_RIGHT)) m.x = 1.0f;
        if (IsGamepadButtonDown(p2Gamepad_, GAMEPAD_BUTTON_LEFT_FACE_LEFT))  m.x = -1.0f;
        if (IsGamepadButtonDown(p2Gamepad_, GAMEPAD_BUTTON_LEFT_FACE_UP))    m.y = -1.0f;
        if (IsGamepadButtonDown(p2Gamepad_, GAMEPAD_BUTTON_LEFT_FACE_DOWN))  m.y = 1.0f;
        out.move   = clampMove(m);
        out.jump   = IsGamepadButtonDown(p2Gamepad_, GAMEPAD_BUTTON_RIGHT_FACE_DOWN);
        out.action = IsGamepadButtonDown(p2Gamepad_, GAMEPAD_BUTTON_RIGHT_FACE_LEFT);
        out.dash   = IsGamepadButtonDown(p2Gamepad_, GAMEPAD_BUTTON_RIGHT_FACE_RIGHT)
                  || GetGamepadAxisMovement(p2Gamepad_, GAMEPAD_AXIS_RIGHT_TRIGGER) > 0.0f;
        return;
    }
    // Keyboard fallback: arrows + numpad. Right-Shift / Right-Ctrl are
    // accepted as alternates for laptops without a numeric keypad.
    Vector2 m{0, 0};
    if (IsKeyDown(KEY_RIGHT)) m.x += 1.0f;
    if (IsKeyDown(KEY_LEFT))  m.x -= 1.0f;
    if (IsKeyDown(KEY_UP))    m.y -= 1.0f;
    if (IsKeyDown(KEY_DOWN))  m.y += 1.0f;
    out.move   = clampMove(m);
    out.jump   = IsKeyDown(KEY_KP_0) || IsKeyDown(KEY_RIGHT_SHIFT);
    out.action = IsKeyDown(KEY_KP_2) || IsKeyDown(KEY_RIGHT_CONTROL);
    out.dash   = IsKeyDown(KEY_KP_1) || IsKeyDown(KEY_RIGHT_ALT);
}

void Input::update() {
    prev_[0] = cur_[0];
    prev_[1] = cur_[1];

    // Hot-plug: claim the first available gamepad for player 2.
    p2Gamepad_ = -1;
    for (int g = 0; g < 4; ++g) {
        if (IsGamepadAvailable(g)) { p2Gamepad_ = g; break; }
    }

    readPlayer1(cur_[0]);
    readPlayer2(cur_[1]);

    // Derive edge-triggered flags.
    for (int i = 0; i < 2; ++i) {
        cur_[i].jumpPressed   = cur_[i].jump   && !prev_[i].jump;
        cur_[i].actionPressed = cur_[i].action && !prev_[i].action;
        cur_[i].dashPressed   = cur_[i].dash   && !prev_[i].dash;
    }

    // Menu navigation edges: aggregate of both players' move sticks.
    float nx = cur_[0].move.x + cur_[1].move.x;
    float ny = cur_[0].move.y + cur_[1].move.y;
    int wantX = (nx > 0.5f) ? 1 : (nx < -0.5f ? -1 : 0);
    int wantY = (ny > 0.5f) ? 1 : (ny < -0.5f ? -1 : 0);
    navXEdge_ = (wantX != 0 && !navXLatch_) ? wantX : 0;
    navYEdge_ = (wantY != 0 && !navYLatch_) ? wantY : 0;
    navXLatch_ = (wantX != 0);
    navYLatch_ = (wantY != 0);
}

bool Input::confirmPressed() const {
    return IsKeyPressed(KEY_SPACE) || IsKeyPressed(KEY_ENTER) ||
           IsKeyPressed(KEY_KP_ENTER) || IsKeyPressed(KEY_J) ||
           (p2Gamepad_ >= 0 && IsGamepadButtonPressed(p2Gamepad_, GAMEPAD_BUTTON_RIGHT_FACE_DOWN));
}

bool Input::cancelPressed() const {
    return IsKeyPressed(KEY_ESCAPE) || IsKeyPressed(KEY_BACKSPACE) ||
           (p2Gamepad_ >= 0 && IsGamepadButtonPressed(p2Gamepad_, GAMEPAD_BUTTON_RIGHT_FACE_RIGHT));
}

bool Input::pausePressed() const {
    return IsKeyPressed(KEY_ESCAPE) || IsKeyPressed(KEY_P) ||
           (p2Gamepad_ >= 0 && IsGamepadButtonPressed(p2Gamepad_, GAMEPAD_BUTTON_MIDDLE_RIGHT));
}

int Input::navX() const { return navXEdge_; }
int Input::navY() const { return navYEdge_; }

bool Input::anyActionPressed() const {
    return cur_[0].actionPressed || cur_[1].actionPressed ||
           cur_[0].jumpPressed   || cur_[1].jumpPressed   || confirmPressed();
}
