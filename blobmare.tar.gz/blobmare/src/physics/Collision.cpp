#include "physics/Collision.h"
#include "raymath.h"
#include <cmath>

namespace phys {

static float clampf(float v, float lo, float hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}

Vector3 closestPointOnAABB(Vector3 p, const AABB& b) {
    return Vector3{
        clampf(p.x, b.min.x, b.max.x),
        clampf(p.y, b.min.y, b.max.y),
        clampf(p.z, b.min.z, b.max.z),
    };
}

bool sphereVsAABB(Vector3 center, float radius, const AABB& box,
                  Vector3& outNormal, float& outDepth) {
    Vector3 cp = closestPointOnAABB(center, box);
    Vector3 delta = Vector3Subtract(center, cp);
    float dist2 = Vector3LengthSqr(delta);

    if (dist2 > radius * radius) return false;

    if (dist2 > 1e-8f) {
        // Sphere center is outside the box: push out along the shortest exit.
        float dist = std::sqrt(dist2);
        outNormal = Vector3Scale(delta, 1.0f / dist);
        outDepth  = radius - dist;
    } else {
        // Sphere center is inside the box: pick the nearest face to exit by.
        float dxMin = center.x - box.min.x, dxMax = box.max.x - center.x;
        float dyMin = center.y - box.min.y, dyMax = box.max.y - center.y;
        float dzMin = center.z - box.min.z, dzMax = box.max.z - center.z;
        float best = dxMin; outNormal = Vector3{ -1, 0, 0 };
        if (dxMax < best) { best = dxMax; outNormal = Vector3{ 1, 0, 0 }; }
        if (dyMin < best) { best = dyMin; outNormal = Vector3{ 0,-1, 0 }; }
        if (dyMax < best) { best = dyMax; outNormal = Vector3{ 0, 1, 0 }; }
        if (dzMin < best) { best = dzMin; outNormal = Vector3{ 0, 0,-1 }; }
        if (dzMax < best) { best = dzMax; outNormal = Vector3{ 0, 0, 1 }; }
        outDepth = best + radius;
    }
    return true;
}

} // namespace phys
