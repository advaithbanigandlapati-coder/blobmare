#pragma once
// Deterministic collision primitives. The blob's physics body is a SPHERE.
//
// Design note: the spec describes an upright capsule body. Because the blob
// is a literal ball, an upright capsule whose height ~= 2*radius degenerates
// to a sphere anyway, and a sphere body is far more robust and trivially
// deterministic against AABBs/planes. We therefore use a sphere body and call
// it out here as a deliberate, reasonable simplification.
#include "raylib.h"

namespace phys {

struct AABB {
    Vector3 min{};
    Vector3 max{};
};

inline AABB makeBox(Vector3 center, Vector3 halfExtents) {
    return AABB{
        { center.x - halfExtents.x, center.y - halfExtents.y, center.z - halfExtents.z },
        { center.x + halfExtents.x, center.y + halfExtents.y, center.z + halfExtents.z },
    };
}
inline Vector3 boxCenter(const AABB& b) {
    return { (b.min.x + b.max.x) * 0.5f, (b.min.y + b.max.y) * 0.5f, (b.min.z + b.max.z) * 0.5f };
}

// Closest point on an AABB to an arbitrary point.
Vector3 closestPointOnAABB(Vector3 p, const AABB& box);

// Resolve a sphere against one AABB. If overlapping, returns true and fills
// 'normal' (unit, pointing out of the box toward the sphere) and 'depth'
// (penetration distance). Does not modify the sphere.
bool sphereVsAABB(Vector3 center, float radius, const AABB& box,
                  Vector3& outNormal, float& outDepth);

} // namespace phys
