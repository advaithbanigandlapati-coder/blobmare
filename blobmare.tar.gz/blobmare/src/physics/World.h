#pragma once
// The physics World holds the static environment (an optional ground plane
// and a set of axis-aligned boxes) and resolves a sphere body against it.
// Blobs integrate themselves and call collide(); minigames may add their own
// custom constraints afterwards (e.g. Sumo Smash's circular platform).
#include "physics/Collision.h"
#include <vector>

class World {
public:
    void clear();

    void setGravity(Vector3 g)   { gravity_ = g; }
    Vector3 gravity() const      { return gravity_; }

    // Ground plane at y = height (infinite). Disabled by default.
    void setGround(float y)      { hasGround_ = true; groundY_ = y; }
    void disableGround()         { hasGround_ = false; }
    bool hasGround() const       { return hasGround_; }
    float groundY() const        { return groundY_; }

    // Below this Y a body is considered fallen into the void.
    void setKillY(float y)       { killY_ = y; }
    float killY() const          { return killY_; }

    void addBox(const phys::AABB& b) { boxes_.push_back(b); }
    std::vector<phys::AABB>&       boxes()       { return boxes_; }
    const std::vector<phys::AABB>& boxes() const { return boxes_; }

    // Resolve a sphere against ground + all boxes. Updates pos/vel in place,
    // zeroes velocity into contact normals, and reports ground contact.
    // 'groundNormal' is the up-most contact normal found (for slope feel).
    void collideSphere(Vector3& pos, Vector3& vel, float radius,
                       bool& grounded, Vector3& groundNormal) const;

private:
    Vector3 gravity_{ 0.0f, -24.0f, 0.0f };
    bool    hasGround_ = false;
    float   groundY_   = 0.0f;
    float   killY_     = -40.0f;
    std::vector<phys::AABB> boxes_;
};
