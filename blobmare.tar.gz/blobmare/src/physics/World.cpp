#include "physics/World.h"
#include "raymath.h"

void World::clear() {
    boxes_.clear();
    hasGround_ = false;
    groundY_   = 0.0f;
    killY_     = -40.0f;
    gravity_   = Vector3{ 0.0f, -24.0f, 0.0f };
}

void World::collideSphere(Vector3& pos, Vector3& vel, float radius,
                          bool& grounded, Vector3& groundNormal) const {
    grounded = false;
    groundNormal = Vector3{ 0, 1, 0 };

    // --- Boxes: resolve a few iterations so stacked contacts settle. ------
    for (int iter = 0; iter < 4; ++iter) {
        bool any = false;
        for (const auto& box : boxes_) {
            Vector3 n; float depth;
            if (!phys::sphereVsAABB(pos, radius, box, n, depth)) continue;
            any = true;
            pos = Vector3Add(pos, Vector3Scale(n, depth));
            // Kill velocity component going into the surface.
            float vn = Vector3DotProduct(vel, n);
            if (vn < 0.0f) vel = Vector3Subtract(vel, Vector3Scale(n, vn));
            if (n.y > 0.5f) { grounded = true; groundNormal = n; }
        }
        if (!any) break;
    }

    // --- Infinite ground plane -------------------------------------------
    if (hasGround_) {
        float floorY = groundY_ + radius;
        if (pos.y < floorY) {
            pos.y = floorY;
            if (vel.y < 0.0f) vel.y = 0.0f;
            grounded = true;
            groundNormal = Vector3{ 0, 1, 0 };
        }
    }
}
