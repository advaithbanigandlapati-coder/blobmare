#include "net/NetPlay.h"
#include "net/NetSession.h"
#include "blob/Blob.h"
#include "raymath.h"
#include <cmath>

using namespace net;

// --- Conversion -------------------------------------------------------------

InputCommand NetPlay::toCommand(const PlayerInput& in, uint32_t tick) {
    InputCommand c;
    c.tick  = tick;
    c.moveX = packAxis(in.move.x);
    c.moveY = packAxis(in.move.y);
    c.buttons = 0;
    if (in.jump)   c.buttons |= InputCommand::Jump;
    if (in.action) c.buttons |= InputCommand::Action;
    if (in.dash)   c.buttons |= InputCommand::Dash;
    return c;
}

PlayerInput NetPlay::toPlayerInput(const InputCommand& cmd) {
    PlayerInput in;
    in.move.x = unpackAxis(cmd.moveX);
    in.move.y = unpackAxis(cmd.moveY);
    in.jump   = cmd.has(InputCommand::Jump);
    in.action = cmd.has(InputCommand::Action);
    in.dash   = cmd.has(InputCommand::Dash);
    // *Pressed edges are derived later in sampleAndSync (needs prev state).
    return in;
}

// --- Lifecycle --------------------------------------------------------------

void NetPlay::beginLocal() {
    mode_ = NetMode::Local;
    session_.reset();
    tick_ = 0;
    prevButtons_[0] = prevButtons_[1] = 0;
}

void NetPlay::beginNetworked(std::shared_ptr<NetSession> session) {
    session_ = std::move(session);
    mode_ = session_->isHost() ? NetMode::Host : NetMode::Client;
    tick_ = 0;
    prevButtons_[0] = prevButtons_[1] = 0;
}

void NetPlay::attachLoopbackPartner(std::shared_ptr<NetSession> partner) {
    loopbackPartner_ = std::move(partner);
}

void NetPlay::end() {
    if (session_) session_->shutdown();
    if (loopbackPartner_) loopbackPartner_->shutdown();
    session_.reset();
    loopbackPartner_.reset();
    mode_ = NetMode::Local;
}

int NetPlay::localBlobIndex() const {
    if (mode_ == NetMode::Local) return 0;
    return session_ ? session_->localPlayer() : 0;
}

// --- Per-tick sampling ------------------------------------------------------

void NetPlay::sampleAndSync(const Input& input, float dtMs) {
    if (mode_ == NetMode::Local) {
        // Passthrough: both blobs use their own device inputs directly.
        resolved_[0] = input.player(0);
        resolved_[1] = input.player(1);
        return;
    }
    if (!session_) return;

    // Pump the network first so we have the freshest remote data.
    session_->update(dtMs);

    // --- Loopback partner ------------------------------------------------
    // In loopback networked mode the "remote" peer is the client session
    // running in this same process. We pump it and feed it player 2's local
    // device input, so it genuinely sends networked input back to the host.
    // (In real UDP play loopbackPartner_ is null and this block is skipped —
    // the remote peer is a separate machine sending its own input.)
    if (loopbackPartner_) {
        loopbackPartner_->update(dtMs);
        PlayerInput p2dev = input.player(1);
        InputCommand p2cmd = toCommand(p2dev, tick_);
        loopbackPartner_->submitLocalInput(p2cmd);
    }

    int local  = session_->localPlayer();
    int remote = session_->remotePlayer();

    // Local player: read the device, submit it to the session.
    PlayerInput localIn = input.player(0);   // device 0 is always "this player"
    InputCommand localCmd = toCommand(localIn, tick_);
    session_->submitLocalInput(localCmd);
    resolved_[local] = localIn;

    // Remote player: pull their input for this tick from the session.
    InputCommand remoteCmd = session_->inputFor(remote, tick_);
    PlayerInput remoteIn = toPlayerInput(remoteCmd);
    // Derive *Pressed edges from the previous tick's button state.
    uint8_t nowB = remoteCmd.buttons, prevB = prevButtons_[remote];
    remoteIn.jumpPressed   = (nowB & InputCommand::Jump)   && !(prevB & InputCommand::Jump);
    remoteIn.actionPressed = (nowB & InputCommand::Action) && !(prevB & InputCommand::Action);
    remoteIn.dashPressed   = (nowB & InputCommand::Dash)   && !(prevB & InputCommand::Dash);
    prevButtons_[remote] = nowB;
    resolved_[remote] = remoteIn;

    // Also track the local player's previous buttons (for consistency if the
    // sim ever needs local edges from the resolved cache).
    prevButtons_[local] = localCmd.buttons;
}

PlayerInput NetPlay::inputForBlob(int blobIndex, const Input& input) const {
    if (mode_ == NetMode::Local) {
        // Defensive: if sampleAndSync wasn't called, fall back to device.
        if (blobIndex >= 0 && blobIndex < kMaxPlayers)
            return resolved_[blobIndex];
        return input.player(blobIndex);
    }
    if (blobIndex < 0 || blobIndex >= kMaxPlayers) return PlayerInput{};
    return resolved_[blobIndex];
}

// --- Snapshot bridge --------------------------------------------------------

void NetPlay::captureAndPublish(const std::vector<Blob*>& blobs,
                                uint8_t sceneId, uint8_t minigameIndex,
                                const int score[2]) {
    if (mode_ != NetMode::Host || !session_) return;

    Snapshot s;
    s.tick = tick_;
    s.sceneId = sceneId;
    s.minigameIndex = minigameIndex;
    for (int i = 0; i < kMaxPlayers && i < (int)blobs.size(); ++i) {
        const Blob* b = blobs[i];
        NetBlobState& ns = s.blob[i];
        Vector3 p = b->position(), v = b->velocity(), f = b->facing();
        ns.px = p.x; ns.py = p.y; ns.pz = p.z;
        ns.vx = v.x; ns.vy = v.y; ns.vz = v.z;
        ns.fx = f.x; ns.fz = f.z;
        ns.flags = 0;
        if (b->alive())     ns.flags |= NetBlobState::Alive;
        if (b->grounded())  ns.flags |= NetBlobState::Grounded;
        if (b->isDashing()) ns.flags |= NetBlobState::Dashing;
        ns.emote = (uint8_t)b->mesh().emote();
    }
    s.score[0] = (int16_t)score[0];
    s.score[1] = (int16_t)score[1];
    session_->publishSnapshot(s);
}

bool NetPlay::applyLatestSnapshot(std::vector<Blob*>& blobs) {
    if (mode_ != NetMode::Client || !session_) return false;
    Snapshot s;
    if (!session_->latestSnapshot(s)) return false;

    int local = session_->localPlayer();
    for (int i = 0; i < kMaxPlayers && i < (int)blobs.size(); ++i) {
        const NetBlobState& ns = s.blob[i];
        Blob* b = blobs[i];

        if (i == local) {
            // The local blob is predicted. Instead of hard-snapping it (which
            // jitters), run reconciliation: compare the authoritative state
            // for s.tick against what we predicted, and re-simulate forward
            // if they diverged. The visible blob then eases to the result.
            if (predictor_.active()) {
                predictor_.reconcile(s.tick, ns,
                                     session_->ackedInputTick(), *b);
            }
            // Alive/emote still come straight from authority.
            if ((ns.flags & NetBlobState::Alive) && !b->alive())  b->revive();
            if (!(ns.flags & NetBlobState::Alive) && b->alive())  b->kill();
            continue;
        }

        // Remote blob: snapshot-driven directly, no prediction needed.
        b->setPosition(Vector3{ ns.px, ns.py, ns.pz });
        b->setVelocity(Vector3{ ns.vx, ns.vy, ns.vz });
        b->faceTowards(Vector3{ ns.fx, 0.0f, ns.fz });
        if ((ns.flags & NetBlobState::Alive) && !b->alive())  b->revive();
        if (!(ns.flags & NetBlobState::Alive) && b->alive())  b->kill();
        b->setEmote((Emote)ns.emote);
    }
    return true;
}

void NetPlay::bindPredictionWorld(World* world, float fixedDt) {
    predictor_.begin(world, fixedDt);
}

void NetPlay::recordPredictionFrame(const std::vector<Blob*>& blobs) {
    if (mode_ != NetMode::Client || !session_ || !predictor_.active()) return;
    int local = session_->localPlayer();
    if (local < 0 || local >= (int)blobs.size()) return;
    // The input the local blob acted on this tick (the one we submitted).
    InputCommand used = toCommand(resolved_[local], tick_);
    predictor_.recordTick(tick_, *blobs[local], used);
    // Ease any pending visual correction toward zero.
    predictor_.decayVisualOffset(1.0f / 120.0f);
}

Vector3 NetPlay::predictionVisualOffset() const {
    if (mode_ != NetMode::Client) return Vector3{0,0,0};
    return predictor_.visualOffset();
}

// --- Proximity voice chat ---------------------------------------------------

void NetPlay::enableVoice(std::unique_ptr<net::MicSource> mic) {
    if (mode_ == NetMode::Local) return;          // voice is networked-only
    voice_.begin(std::move(mic));
}

void NetPlay::disableVoice() {
    voice_.end();
}

bool NetPlay::voiceActive() const {
    return voice_.active();
}

float NetPlay::voiceGain() const {
    return voice_.currentGain();
}

void NetPlay::updateVoice(const std::vector<Blob*>& blobs) {
    if (!voice_.active() || !session_) return;

    // 1) Capture a local mic frame (if one is due) and send it to the peer.
    std::vector<uint8_t> body;
    if (voice_.captureEncoded(body) && !body.empty())
        session_->sendVoiceFrame(body.data(), body.size());

    // 2) Drain any voice frames the peer sent us into the playback queue.
    std::vector<uint8_t> in;
    while (session_->popVoiceFrame(in))
        voice_.onRemoteFrame(in.data(), in.size());

    // 3) Proximity: attenuate remote voice by the in-world blob distance.
    if (blobs.size() >= 2) {
        Vector3 a = blobs[0]->position();
        Vector3 b = blobs[1]->position();
        float dx = a.x-b.x, dy = a.y-b.y, dz = a.z-b.z;
        voice_.setProximity(std::sqrt(dx*dx + dy*dy + dz*dz));
    }

    // 4) Push attenuated remote audio into the playback stream.
    voice_.updatePlayback();
}
