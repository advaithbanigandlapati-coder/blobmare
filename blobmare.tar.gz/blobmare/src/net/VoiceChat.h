#pragma once
// =============================================================================
//  VoiceChat — proximity voice chat over the netcode transport
// =============================================================================
//
//  PIPELINE
//    capture (mic)  ->  encode  ->  VoiceFrame packet  ->  [network]
//    ->  decode  ->  proximity attenuation  ->  mix into playback stream
//
//  "Proximity" means the remote player's voice is attenuated by the in-world
//  distance between the two blobs: full volume when adjacent, fading to
//  silence past a radius. That distance is fed in each frame by the match.
//
//  HONEST STATUS
//  Voice chat is hardware-in-the-loop: it needs a real microphone and a
//  second machine, neither of which exists in the build/test environment.
//  Therefore this module is built so the FULL pipeline runs and is testable
//  WITHOUT a mic:
//    * MicSource is an interface. SyntheticMicSource generates a test tone —
//      it lets the encode -> packet -> decode -> attenuate -> mix path be
//      exercised and verified end to end (see voicetest).
//    * A real RtMicSource (miniaudio-backed) is the drop-in for actual mics;
//      it is documented in docs/NETCODE.md and is the one remaining piece
//      that must be built + verified on real hardware.
//
//  CODEC
//  Frames are 20 ms of 16 kHz mono PCM (320 samples). They are compressed with
//  a simple, dependency-free scheme (see VoiceCodec) so the project builds
//  with no external library. Swapping in Opus is a localised change in
//  VoiceCodec — noted in the netcode doc — and would cut bandwidth further.
//
#include "raylib.h"
#include "net/NetTypes.h"
#include <cstdint>
#include <vector>
#include <memory>

namespace net {

constexpr int   kVoiceSampleRate = 16000;
constexpr int   kVoiceFrameMs    = 20;
constexpr int   kVoiceFrameSamples = kVoiceSampleRate * kVoiceFrameMs / 1000; // 320

// --- Microphone source interface -------------------------------------------
// Pulls raw PCM. The real implementation wraps the OS mic; the synthetic one
// generates a test signal so the rest of the pipeline is verifiable headless.
class MicSource {
public:
    virtual ~MicSource() = default;
    virtual bool start() = 0;
    virtual void stop() = 0;
    // Fill 'out' with exactly kVoiceFrameSamples mono samples in [-1,1].
    // Returns false if no frame is available this call.
    virtual bool readFrame(std::vector<float>& out) = 0;
};

// A synthetic mic: emits a steady test tone. Used to exercise + verify the
// pipeline with no hardware.
class SyntheticMicSource : public MicSource {
public:
    bool start() override { running_ = true; return true; }
    void stop() override  { running_ = false; }
    bool readFrame(std::vector<float>& out) override;
private:
    bool  running_ = false;
    float phase_ = 0.0f;
};

// --- Voice codec ------------------------------------------------------------
// Dependency-free compression: 16-bit PCM is downsampled to 8-bit mu-law-style
// companding. ~50% of raw, lossy but intelligible. (Opus drop-in: see docs.)
namespace VoiceCodec {
    void encode(const std::vector<float>& pcm, std::vector<uint8_t>& out);
    void decode(const std::vector<uint8_t>& in, std::vector<float>& pcm);
}

// --- The VoiceChat service --------------------------------------------------
class VoiceChat {
public:
    // Bind a mic source (ownership taken). Pass a SyntheticMicSource for
    // headless testing or an RtMicSource for real capture.
    void begin(std::unique_ptr<MicSource> mic);
    void end();
    bool active() const { return active_; }

    // Per-frame. Captures a mic frame (if due) and returns it encoded into a
    // VoiceFrame-typed packet body ready to hand to NetSession; empty if no
    // frame is due this call.
    bool captureEncoded(std::vector<uint8_t>& outPacketBody);

    // A VoiceFrame packet arrived from the remote peer — decode + buffer it.
    void onRemoteFrame(const uint8_t* data, size_t len);

    // Set the current in-world distance between the two blobs; drives the
    // proximity attenuation applied to remote voice.
    void setProximity(float distance);

    // Per-frame: push buffered remote audio (attenuated) into playback.
    void updatePlayback();

    // Tuning.
    void setMaxHearingRange(float r) { maxRange_ = r; }
    void setSelfMonitor(bool on)     { selfMonitor_ = on; }

    // Last computed proximity gain (0..1) — for HUD/debug.
    float currentGain() const { return gain_; }

private:
    bool active_ = false;
    std::unique_ptr<MicSource> mic_;

    // Playback via a raylib AudioStream.
    AudioStream stream_{};
    bool        streamValid_ = false;

    // Decoded remote PCM waiting to be played, and capture pacing.
    std::vector<float> remoteQueue_;
    float captureAccumMs_ = 0.0f;

    float distance_  = 0.0f;
    float maxRange_  = 14.0f;
    float gain_      = 0.0f;
    bool  selfMonitor_ = false;

    float proximityGain() const;
};

} // namespace net
