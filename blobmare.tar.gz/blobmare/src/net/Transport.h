#pragma once
// =============================================================================
//  Transport — the network abstraction layer
// =============================================================================
//
//  The game talks to ONE Transport interface. Two implementations exist:
//
//    LoopbackTransport — both peers in one process, packets handed over
//        directly (with optional simulated latency + loss). This is fully
//        testable headlessly and is how the netcode is validated before any
//        real socket exists. It is also genuinely useful as a "hotseat" mode.
//
//    UdpTransport — real UDP sockets (built in the next stage). Implements
//        the exact same interface, so the game code does not change.
//
//  A Transport moves opaque byte packets. It does NOT understand messages —
//  framing/encoding lives in NetTypes + NetSession. This separation is what
//  lets the whole protocol be tested against Loopback.
//
#include <cstdint>
#include <vector>
#include <functional>

namespace net {

struct Packet {
    std::vector<uint8_t> data;
    // Peer id the packet came from / goes to. With kMaxPlayers==2 this is
    // simply the other peer; kept explicit for future >2-player work.
    int peer = 0;
};

// Connection role.
enum class Role { Host, Client };

class Transport {
public:
    virtual ~Transport() = default;

    // Non-blocking. Returns true while the transport is usable.
    virtual bool poll() = 0;

    // Queue a packet to a peer (Host: peer = client index; Client: peer = 0).
    virtual void send(int peer, const uint8_t* data, size_t len) = 0;

    // Pop the next received packet, if any. Returns false when none waiting.
    virtual bool receive(Packet& out) = 0;

    virtual Role role() const = 0;
    virtual bool connected() const = 0;

    // Diagnostics (round-trip ms, 0 if unknown).
    virtual float pingMs() const { return 0.0f; }
};

// --- Loopback ---------------------------------------------------------------
// Creates a linked Host+Client pair sharing in-memory queues. Optional latency
// and packet-loss simulation make it a real netcode test rig, not a no-op.
class LoopbackTransport : public Transport {
public:
    struct Sim {
        float latencyMs = 0.0f;     // one-way delay applied to every packet
        float jitterMs  = 0.0f;     // +/- random delay on top of latency
        float lossRate  = 0.0f;     // 0..1 chance a packet is dropped
    };

    // Build a connected pair. Caller owns both halves.
    static void makePair(LoopbackTransport*& host, LoopbackTransport*& client);
    static void makePair(LoopbackTransport*& host, LoopbackTransport*& client,
                         Sim sim);

    bool poll() override;
    void send(int peer, const uint8_t* data, size_t len) override;
    bool receive(Packet& out) override;
    Role role() const override { return role_; }
    bool connected() const override { return peer_ != nullptr; }
    float pingMs() const override { return sim_.latencyMs * 2.0f; }

    // Advance simulated time so latency/jitter take effect.
    void advance(float dtMs);

    ~LoopbackTransport() override = default;

private:
    struct Pending { std::vector<uint8_t> data; float deliverAt; int peer; };

    Role role_ = Role::Host;
    LoopbackTransport* peer_ = nullptr;   // the other half
    Sim   sim_;
    float clockMs_ = 0.0f;
    std::vector<Pending> inflightToPeer_; // packets we've sent, awaiting delivery
    std::vector<Packet>  inbox_;          // packets delivered to us, ready to read

    // Called by the peer to hand us a packet that has cleared its delay.
    void deliver(const std::vector<uint8_t>& data, int fromPeer);
};

} // namespace net
