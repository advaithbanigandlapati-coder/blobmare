#include "net/NetTypes.h"

namespace net {

void writeInput(ByteWriter& w, const InputCommand& c) {
    w.u32(c.tick);
    w.i8(c.moveX);
    w.i8(c.moveY);
    w.u8(c.buttons);
}

bool readInput(ByteReader& r, InputCommand& c) {
    c.tick    = r.u32();
    c.moveX   = r.i8();
    c.moveY   = r.i8();
    c.buttons = r.u8();
    return r.ok();
}

static void writeBlob(ByteWriter& w, const NetBlobState& b) {
    w.f32(b.px); w.f32(b.py); w.f32(b.pz);
    w.f32(b.vx); w.f32(b.vy); w.f32(b.vz);
    w.f32(b.fx); w.f32(b.fz);
    w.u8(b.flags);
    w.u8(b.emote);
}

static bool readBlob(ByteReader& r, NetBlobState& b) {
    b.px = r.f32(); b.py = r.f32(); b.pz = r.f32();
    b.vx = r.f32(); b.vy = r.f32(); b.vz = r.f32();
    b.fx = r.f32(); b.fz = r.f32();
    b.flags = r.u8();
    b.emote = r.u8();
    return r.ok();
}

void writeSnapshot(ByteWriter& w, const Snapshot& s) {
    w.u32(s.tick);
    for (int i = 0; i < kMaxPlayers; ++i) w.u32(s.lastInputTick[i]);
    for (int i = 0; i < kMaxPlayers; ++i) writeBlob(w, s.blob[i]);
    w.u8(s.sceneId);
    w.u8(s.minigameIndex);
    for (int i = 0; i < kMaxPlayers; ++i) w.i16(s.score[i]);
}

bool readSnapshot(ByteReader& r, Snapshot& s) {
    s.tick = r.u32();
    for (int i = 0; i < kMaxPlayers; ++i) s.lastInputTick[i] = r.u32();
    for (int i = 0; i < kMaxPlayers; ++i) readBlob(r, s.blob[i]);
    s.sceneId       = r.u8();
    s.minigameIndex = r.u8();
    for (int i = 0; i < kMaxPlayers; ++i) s.score[i] = r.i16();
    return r.ok();
}

} // namespace net
