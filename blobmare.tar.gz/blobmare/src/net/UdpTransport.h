#pragma once
// =============================================================================
//  UdpTransport — real UDP socket implementation of Transport
// =============================================================================
//
//  Implements the SAME Transport interface as LoopbackTransport, so every
//  layer above (NetSession, NetPlay, the scenes) is unchanged. Swapping
//  loopback for real sockets is purely a construction-site decision.
//
//  Model: connectionless UDP, one host + one client.
//    HOST   binds a known port, waits for the first datagram, and locks onto
//           that sender's address as "the client".
//    CLIENT sends to a host ip:port; its OS picks an ephemeral local port.
//
//  Sockets are non-blocking; poll() drains the OS receive buffer into an
//  inbox each call. RTT is measured from Ping/Pong timestamps.
//
//  CROSS-PLATFORM: uses BSD sockets on POSIX and Winsock on Windows, behind a
//  thin #ifdef. No external dependency.
//
//  TESTING STATUS: the socket code is localhost-verified (two UDP sockets on
//  127.0.0.1 in one process exchanging real datagrams). Cross-machine play —
//  NAT, real latency/loss/reordering — must be verified on two machines; see
//  docs/NETCODE.md.
//
#include "net/Transport.h"
#include <cstdint>
#include <string>
#include <vector>
#include <deque>

namespace net {

class UdpTransport : public Transport {
public:
    UdpTransport();
    ~UdpTransport() override;

    // Start as a host: bind 'port' on all interfaces. Returns false on error
    // (port in use, no permission). Inspect lastError() for detail.
    bool startHost(uint16_t port);

    // Start as a client: remember the host address to send to. The actual
    // handshake datagram is sent by NetSession; this just opens the socket.
    bool startClient(const std::string& hostIp, uint16_t hostPort);

    const std::string& lastError() const { return lastError_; }

    // --- Transport interface --------------------------------------------
    bool poll() override;
    void send(int peer, const uint8_t* data, size_t len) override;
    bool receive(Packet& out) override;
    Role role() const override { return role_; }
    bool connected() const override;
    float pingMs() const override { return rttMs_; }

    // Feed RTT samples. NetSession can call this when it matches a Pong to a
    // Ping; for now poll() also auto-measures via the protocol's ping echoes.
    void recordRtt(float ms);

private:
    // Platform socket handle.
#if defined(_WIN32)
    uintptr_t sock_ = ~(uintptr_t)0;
#else
    int sock_ = -1;
#endif
    Role role_ = Role::Host;
    bool open_ = false;

    // For a host: the client's address, learned from its first datagram.
    // For a client: the host's address, set at startClient.
    bool   peerKnown_ = false;
    uint8_t peerAddr_[16] = {};   // sockaddr_in storage (we only use v4)
    int     peerAddrLen_ = 0;

    std::deque<Packet> inbox_;
    std::string lastError_;
    float rttMs_ = 0.0f;

    static bool platformInit();
    void closeSocket();
    bool setNonBlocking();
};

} // namespace net
