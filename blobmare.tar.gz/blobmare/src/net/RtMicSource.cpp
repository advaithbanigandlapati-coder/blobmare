#include "net/RtMicSource.h"

// miniaudio: implementation goes in exactly ONE translation unit.
//
// IMPORTANT: raylib ALREADY embeds its own copy of miniaudio internally (for
// raudio). Compiling a second public copy here produces duplicate-symbol link
// errors. The fix: define MA_API to 'static' so OUR miniaudio's symbols are
// file-local to this translation unit — invisible to the linker, no clash
// with raylib's copy. Each copy serves its own owner; they never interact.
#define MA_API static
#define MINIAUDIO_IMPLEMENTATION
#define MA_NO_ENCODING
#define MA_NO_DECODING
#define MA_NO_GENERATION
#include "miniaudio.h"

#include <cstring>
#include <cmath>
#include <algorithm>

namespace net {

namespace {
// The capture thread callback. miniaudio hands us 'frameCount' frames of
// input audio; we forward them to the RtMicSource that owns this device.
void captureCallback(ma_device* dev, void* /*out*/, const void* in,
                     ma_uint32 frameCount) {
    auto* self = static_cast<RtMicSource*>(dev->pUserData);
    if (!self || !in) return;
    self->pushCaptured(static_cast<const float*>(in), frameCount,
                       dev->capture.internalSampleRate,
                       dev->capture.channels);
}
} // namespace

RtMicSource::RtMicSource() {
    // ~0.5 s of 16 kHz mono headroom — far more than the 20 ms frame cadence
    // needs, so a scheduling hiccup never drops audio.
    ringCapacity_ = (size_t)kVoiceSampleRate / 2;
    ring_.assign(ringCapacity_, 0.0f);
}

RtMicSource::~RtMicSource() {
    stop();
    if (device_) {
        ma_device_uninit(static_cast<ma_device*>(device_));
        delete static_cast<ma_device*>(device_);
        device_ = nullptr;
    }
}

bool RtMicSource::start() {
    if (running_) return true;

    if (!device_) {
        auto* dev = new ma_device();
        ma_device_config cfg = ma_device_config_init(ma_device_type_capture);
        cfg.capture.format   = ma_format_f32;   // float samples, [-1,1]
        cfg.capture.channels = 0;               // 0 = use device native
        cfg.sampleRate       = 0;               // 0 = use device native
        cfg.dataCallback     = captureCallback;
        cfg.pUserData        = this;

        if (ma_device_init(nullptr, &cfg, dev) != MA_SUCCESS) {
            lastError_ = "no microphone, or microphone permission denied";
            delete dev;
            deviceReady_ = false;
            return false;
        }
        device_ = dev;
        deviceReady_ = true;
    }

    if (ma_device_start(static_cast<ma_device*>(device_)) != MA_SUCCESS) {
        lastError_ = "microphone device failed to start";
        return false;
    }
    running_ = true;
    return true;
}

void RtMicSource::stop() {
    if (running_ && device_)
        ma_device_stop(static_cast<ma_device*>(device_));
    running_ = false;
}

// --- Ring buffer ------------------------------------------------------------

size_t RtMicSource::ringAvailable() const {
    size_t w = writePos_.load(std::memory_order_acquire);
    size_t r = readPos_.load(std::memory_order_acquire);
    return (w >= r) ? (w - r) : (ringCapacity_ - r + w);
}

void RtMicSource::ringPush(float s) {
    size_t w = writePos_.load(std::memory_order_relaxed);
    size_t next = (w + 1) % ringCapacity_;
    // If the buffer is full (consumer fell behind), drop the oldest sample by
    // advancing the read cursor — realtime audio favours fresh over complete.
    if (next == readPos_.load(std::memory_order_acquire)) {
        readPos_.store((readPos_.load(std::memory_order_relaxed) + 1)
                       % ringCapacity_, std::memory_order_release);
    }
    ring_[w] = s;
    writePos_.store(next, std::memory_order_release);
}

// --- Capture thread side ----------------------------------------------------

void RtMicSource::pushCaptured(const float* samples, unsigned int count,
                               unsigned int deviceRate, unsigned int channels) {
    if (!samples || count == 0 || channels == 0) return;
    if (deviceRate == 0) deviceRate = kVoiceSampleRate;

    std::lock_guard<std::mutex> lock(ringMutex_);

    // Downmix to mono and resample device rate -> 16 kHz with a simple
    // fractional-step linear resampler. step > 1 decimates, < 1 interpolates.
    const double step = (double)deviceRate / (double)kVoiceSampleRate;
    while (resamplePhase_ < (double)count) {
        size_t idx = (size_t)resamplePhase_;
        if (idx >= count) break;
        // Average channels for a mono sample.
        float mono = 0.0f;
        const float* frame = samples + idx * channels;
        for (unsigned int c = 0; c < channels; ++c) mono += frame[c];
        mono /= (float)channels;
        ringPush(mono);
        resamplePhase_ += step;
    }
    // Carry the fractional remainder into the next callback.
    resamplePhase_ -= (double)count;
    if (resamplePhase_ < 0.0) resamplePhase_ = 0.0;
}

// --- Game thread side -------------------------------------------------------

bool RtMicSource::readFrame(std::vector<float>& out) {
    if (!running_) return false;

    std::lock_guard<std::mutex> lock(ringMutex_);
    // Only deliver a frame once a full 20 ms is buffered.
    if (ringAvailable() < (size_t)kVoiceFrameSamples) return false;

    out.resize(kVoiceFrameSamples);
    size_t r = readPos_.load(std::memory_order_relaxed);
    for (int i = 0; i < kVoiceFrameSamples; ++i) {
        out[i] = ring_[r];
        r = (r + 1) % ringCapacity_;
    }
    readPos_.store(r, std::memory_order_release);
    return true;
}

} // namespace net
