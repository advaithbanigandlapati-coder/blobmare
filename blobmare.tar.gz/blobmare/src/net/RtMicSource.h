#pragma once
// =============================================================================
//  RtMicSource — real microphone capture, backed by miniaudio
// =============================================================================
//
//  The production MicSource: opens the system default microphone and feeds
//  captured audio to the VoiceChat pipeline. miniaudio (third_party/) handles
//  the platform audio API on every OS — no per-platform code here.
//
//  THREADING
//  miniaudio delivers captured audio on its own high-priority audio thread,
//  via a callback. The game pulls frames from the main thread via readFrame().
//  A lock-free-enough ring buffer (single producer, single consumer, guarded
//  by a small mutex on the index updates) bridges the two. Frames are also
//  resampled from the device's native rate to the 16 kHz the codec expects.
//
//  TESTING STATUS
//  This is the one piece that genuinely needs a microphone to verify — it is
//  written and compiles, but capture quality / device selection / echo can
//  only be judged on real hardware. The synthetic source remains available
//  for headless runs.
//
#include "net/VoiceChat.h"
#include <vector>
#include <mutex>
#include <atomic>

namespace net {

class RtMicSource : public MicSource {
public:
    RtMicSource();
    ~RtMicSource() override;

    bool start() override;          // open + start the capture device
    void stop() override;
    bool readFrame(std::vector<float>& out) override;

    // True if a device opened successfully. If start() fails (no mic, no
    // permission) this stays false and readFrame() returns nothing — the
    // game then simply transmits silence, which is a safe degradation.
    bool deviceReady() const { return deviceReady_; }
    const char* lastError() const { return lastError_; }

    // --- Called by the miniaudio capture thread. Public only so the C
    //     callback can reach it; not part of the MicSource contract. ------
    void pushCaptured(const float* samples, unsigned int count,
                      unsigned int deviceRate, unsigned int channels);

private:
    bool deviceReady_ = false;
    bool running_ = false;
    const char* lastError_ = "";

    // Opaque miniaudio device — heap-allocated so this header needs no
    // miniaudio include (it is heavy). Defined in the .cpp.
    void* device_ = nullptr;

    // Producer/consumer ring buffer of mono 16 kHz samples.
    std::vector<float> ring_;
    std::atomic<size_t> writePos_{0};
    std::atomic<size_t> readPos_{0};
    std::mutex ringMutex_;

    // Fractional resampler state (device rate -> 16 kHz).
    double resamplePhase_ = 0.0;

    size_t ringCapacity_ = 0;
    void ringPush(float s);
    size_t ringAvailable() const;
};

} // namespace net
