#include "net/NetSession.h"

namespace net {

// --- Lifecycle --------------------------------------------------------------

void NetSession::begin(std::unique_ptr<Transport> transport,
                       const SessionConfig& cfg) {
    transport_ = std::move(transport);
    config_    = cfg;
    role_      = transport_->role();
    // Slot assignment: host is always player 0, client player 1. The client's
    // real slot is confirmed by Welcome, but defaulting this way keeps a
    // host-only session immediately usable.
    localPlayer_ = (role_ == Role::Host) ? 0 : 1;

    for (auto& t : latestInputTick_)  t = 0;
    for (auto& t : lastConsumedInput_) t = 0;
    ackedInputTick_ = 0;
    snapshots_.clear();
    haveLatest_ = false;
    timeSinceRecvMs_ = 0.0f;
    timeSincePingMs_ = 0.0f;

    if (role_ == Role::Host) {
        // Host is ready to play immediately; it waits for a client to join
        // but the session is "Connected" from its own perspective once a
        // Hello arrives. Until then it is Handshaking.
        state_ = SessionState::Handshaking;
    } else {
        state_ = SessionState::Handshaking;
        sendHello();
    }
}

void NetSession::shutdown() {
    if (transport_ && state_ != SessionState::Disconnected) {
        ByteWriter w;
        w.u32(kMagic);
        w.u8((uint8_t)MsgType::Bye);
        sendBytes(0, w);
        transport_->poll();
    }
    transport_.reset();
    state_ = SessionState::Disconnected;
}

// --- Sending helpers --------------------------------------------------------

void NetSession::sendBytes(int peer, const ByteWriter& w) {
    if (transport_) transport_->send(peer, w.data().data(), w.size());
}

void NetSession::sendHello() {
    ByteWriter w;
    w.u32(kMagic);
    w.u8((uint8_t)MsgType::Hello);
    w.u32(kProtocolVersion);
    sendBytes(0, w);
}

void NetSession::sendWelcome(int toPeer) {
    ByteWriter w;
    w.u32(kMagic);
    w.u8((uint8_t)MsgType::Welcome);
    w.u32(kProtocolVersion);
    w.u8((uint8_t)1);                 // client is assigned player slot 1
    w.u32(config_.matchSeed);
    w.u8(config_.minigameCount);
    w.u8(config_.roundsToWin);
    sendBytes(toPeer, w);
}

// --- Input ------------------------------------------------------------------

void NetSession::recordInput(int player, const InputCommand& cmd) {
    if (player < 0 || player >= kMaxPlayers) return;
    inputHist_[player][cmd.tick % kInputHistory] = cmd;
    if (cmd.tick >= latestInputTick_[player] || latestInputTick_[player] == 0)
        latestInputTick_[player] = cmd.tick;
}

void NetSession::submitLocalInput(const InputCommand& cmd) {
    recordInput(localPlayer_, cmd);
    if (role_ == Role::Client) {
        // Send this input (and, for loss tolerance, the few before it).
        ByteWriter w;
        w.u32(kMagic);
        w.u8((uint8_t)MsgType::Input);
        // Redundancy: include up to 3 recent commands so a single lost packet
        // doesn't stall the host. The host de-duplicates by tick.
        uint32_t from = (cmd.tick >= 2) ? cmd.tick - 2 : 0;
        uint8_t count = (uint8_t)(cmd.tick - from + 1);
        w.u8(count);
        for (uint32_t t = from; t <= cmd.tick; ++t) {
            writeInput(w, inputHist_[localPlayer_][t % kInputHistory]);
        }
        sendBytes(0, w);
    }
}

InputCommand NetSession::inputFor(int player, uint32_t tick) const {
    if (player < 0 || player >= kMaxPlayers) return InputCommand{};
    const InputCommand& slot = inputHist_[player][tick % kInputHistory];
    if (slot.tick == tick) return slot;
    // Miss: fall back to the most recent known command (input extrapolation).
    // This masks brief packet loss — the blob keeps doing what it last did.
    InputCommand last = inputHist_[player][latestInputTick_[player]
                                           % kInputHistory];
    last.tick = tick;
    return last;
}

// --- Snapshots --------------------------------------------------------------

void NetSession::publishSnapshot(const Snapshot& snap) {
    if (role_ != Role::Host) return;
    Snapshot s = snap;
    // Stamp which client input we've consumed so the client can reconcile.
    for (int i = 0; i < kMaxPlayers; ++i)
        s.lastInputTick[i] = lastConsumedInput_[i];
    ByteWriter w;
    w.u32(kMagic);
    w.u8((uint8_t)MsgType::SnapshotMsg);
    writeSnapshot(w, s);
    sendBytes(0, w);
    // The host is also a player: keep its own latest copy for any local use.
    latest_ = s;
    haveLatest_ = true;
}

bool NetSession::latestSnapshot(Snapshot& out) const {
    if (!haveLatest_) return false;
    out = latest_;
    return true;
}

bool NetSession::popSnapshot(Snapshot& out) {
    if (snapshots_.empty()) return false;
    out = snapshots_.front();
    snapshots_.pop_front();
    return true;
}

void NetSession::sendVoiceFrame(const uint8_t* data, size_t len) {
    if (state_ != SessionState::Connected) return;
    ByteWriter w;
    w.u32(kMagic);
    w.u8((uint8_t)MsgType::VoiceFrame);
    w.bytes(data, len);
    sendBytes(0, w);
}

bool NetSession::popVoiceFrame(std::vector<uint8_t>& out) {
    if (voiceInbox_.empty()) return false;
    out = std::move(voiceInbox_.front());
    voiceInbox_.pop_front();
    return true;
}

// --- Packet handling --------------------------------------------------------

void NetSession::handlePacket(const Packet& pkt) {
    ByteReader r(pkt.data.data(), pkt.data.size());
    uint32_t magic = r.u32();
    if (!r.ok() || magic != kMagic) return;          // not ours / corrupt
    MsgType type = (MsgType)r.u8();
    if (!r.ok()) return;

    timeSinceRecvMs_ = 0.0f;                          // any valid packet = alive

    switch (type) {
        case MsgType::Hello: {
            uint32_t ver = r.u32();
            if (!r.ok() || ver != kProtocolVersion) return;
            if (role_ == Role::Host) {
                sendWelcome(pkt.peer);
                state_ = SessionState::Connected;
            }
        } break;

        case MsgType::Welcome: {
            uint32_t ver = r.u32();
            if (!r.ok() || ver != kProtocolVersion) return;
            uint8_t slot = r.u8();
            config_.matchSeed     = r.u32();
            config_.minigameCount = r.u8();
            config_.roundsToWin   = r.u8();
            if (!r.ok()) return;
            localPlayer_ = slot;
            state_ = SessionState::Connected;
        } break;

        case MsgType::Input: {
            if (role_ != Role::Host) return;
            uint8_t count = r.u8();
            for (int i = 0; i < count; ++i) {
                InputCommand c;
                if (!readInput(r, c)) break;
                recordInput(remotePlayer(), c);
                if (c.tick > lastConsumedInput_[remotePlayer()])
                    lastConsumedInput_[remotePlayer()] = c.tick;
            }
        } break;

        case MsgType::SnapshotMsg: {
            if (role_ != Role::Client) return;
            Snapshot s;
            if (!readSnapshot(r, s)) return;
            // Drop stale/out-of-order snapshots.
            if (haveLatest_ && s.tick <= latest_.tick) return;
            latest_ = s;
            haveLatest_ = true;
            ackedInputTick_ = s.lastInputTick[localPlayer_];
            snapshots_.push_back(s);
            // Bound the buffer — we only need a couple for interpolation.
            while (snapshots_.size() > 8) snapshots_.pop_front();
        } break;

        case MsgType::Ping: {
            ByteWriter w;
            w.u32(kMagic);
            w.u8((uint8_t)MsgType::Pong);
            sendBytes(pkt.peer, w);
        } break;

        case MsgType::Pong:
            break;   // RTT bookkeeping handled by the transport layer

        case MsgType::Bye:
            state_ = SessionState::Disconnected;
            break;

        case MsgType::VoiceFrame: {
            // Decoded + played by the game's VoiceChat module. Buffer the
            // body (everything after the magic + type) for it to drain.
            size_t rem = r.remaining();
            if (rem > 0) {
                std::vector<uint8_t> body(rem);
                r.bytes(body.data(), rem);
                if (r.ok()) {
                    voiceInbox_.push_back(std::move(body));
                    // Bound it — voice is realtime, stale frames are useless.
                    while (voiceInbox_.size() > 16) voiceInbox_.pop_front();
                }
            }
        } break;
    }
}

// --- Update -----------------------------------------------------------------

void NetSession::update(float dtMs) {
    if (!transport_ || state_ == SessionState::Disconnected) return;

    // Advance a LoopbackTransport's simulated clock if that's what we have.
    if (auto* lb = dynamic_cast<LoopbackTransport*>(transport_.get()))
        lb->advance(dtMs);

    transport_->poll();

    Packet pkt;
    while (transport_->receive(pkt))
        handlePacket(pkt);

    // Liveness.
    timeSinceRecvMs_ += dtMs;
    timeSincePingMs_ += dtMs;

    // Handshake retransmit: a client's first Hello can be lost (e.g. it
    // started before the host was listening). Resend Hello periodically
    // until a Welcome arrives and we transition to Connected.
    if (role_ == Role::Client && state_ == SessionState::Handshaking) {
        helloRetryMs_ += dtMs;
        if (helloRetryMs_ >= kHelloRetryMs) {
            helloRetryMs_ = 0.0f;
            sendHello();
        }
    }

    if (state_ == SessionState::Connected &&
        timeSinceRecvMs_ > kTimeoutMs) {
        state_ = SessionState::Disconnected;
    }
    if (timeSincePingMs_ > kPingEveryMs && state_ == SessionState::Connected) {
        timeSincePingMs_ = 0.0f;
        ByteWriter w;
        w.u32(kMagic);
        w.u8((uint8_t)MsgType::Ping);
        sendBytes(0, w);
    }
}

} // namespace net
