#pragma once
// =============================================================================
//  Blobmare netcode — shared wire types
// =============================================================================
//
//  DESIGN (staged build — see docs/NETCODE.md for the full plan):
//
//  Blobmare uses a client-server model with a deterministic fixed-step
//  simulation. One peer is the HOST (authoritative); the other is a CLIENT.
//
//    * Every tick, each peer samples local input into an InputCommand.
//    * Clients send their InputCommand to the host.
//    * The host steps the authoritative sim and broadcasts a Snapshot.
//    * Clients render the latest snapshot, interpolated, and locally predict
//      their own blob from their unacknowledged inputs.
//
//  This file defines ONLY the plain-old-data wire structs and (de)serialisation.
//  It has no dependency on sockets — the Transport interface is separate — so
//  it can be unit-tested and fuzzed in isolation.
//
//  Wire format: fixed-layout little-endian. All multi-byte fields are written
//  through explicit byte packing (no struct memcpy) so the protocol is stable
//  across compilers/architectures.
//
#include <cstdint>
#include <cstring>
#include <vector>

namespace net {

// Bump whenever the wire format changes; peers refuse mismatched versions.
constexpr uint32_t kProtocolVersion = 1;
constexpr uint32_t kMagic = 0x424C4F42;   // 'BLOB'

constexpr int kMaxPlayers = 2;

// --- A single tick of one player's input ----------------------------------
// This is the ENTIRE input surface the simulation consumes. Keeping it tiny
// and fixed-size is what makes prediction + rollback cheap.
struct InputCommand {
    uint32_t tick = 0;        // sim tick this input applies to
    int8_t   moveX = 0;       // -127..127  -> -1..1
    int8_t   moveY = 0;       // -127..127  -> -1..1
    uint8_t  buttons = 0;     // bitfield, see Button below

    enum Button : uint8_t {
        Jump   = 1 << 0,
        Action = 1 << 1,
        Dash   = 1 << 2,
    };

    bool has(Button b) const { return (buttons & b) != 0; }
};

// --- One blob's state in a snapshot ----------------------------------------
struct NetBlobState {
    float px = 0, py = 0, pz = 0;       // position
    float vx = 0, vy = 0, vz = 0;       // velocity
    float fx = 0, fz = 1;               // facing (horizontal unit)
    uint8_t flags = 0;                  // bit0 alive, bit1 grounded, bit2 dashing
    uint8_t emote = 0;                  // Emote enum value

    enum Flag : uint8_t { Alive = 1<<0, Grounded = 1<<1, Dashing = 1<<2 };
};

// --- A full authoritative snapshot of the simulation -----------------------
struct Snapshot {
    uint32_t tick = 0;                       // sim tick this snapshot is for
    uint32_t lastInputTick[kMaxPlayers] = {};// last input the host consumed,
                                             // per player (for client recon.)
    NetBlobState blob[kMaxPlayers];
    // Lightweight match/minigame context so a late-joining or catching-up
    // client can display the right thing without a separate channel.
    uint8_t  sceneId = 0;
    uint8_t  minigameIndex = 0;
    int16_t  score[kMaxPlayers] = {};
};

// --- Message envelope ------------------------------------------------------
enum class MsgType : uint8_t {
    Hello      = 1,   // client -> host: join request
    Welcome    = 2,   // host -> client: assigned player slot + config
    Input      = 3,   // client -> host: an InputCommand (may batch several)
    SnapshotMsg= 4,   // host -> client: a Snapshot
    Ping       = 5,
    Pong       = 6,
    Bye        = 7,   // either way: graceful disconnect
    VoiceFrame = 8,   // proximity VC audio packet (added in the VC stage)
};

// --- Serialisation buffer --------------------------------------------------
// A tiny append/read byte buffer with explicit LE packing. No exceptions:
// readers bounds-check and set an error flag the caller inspects.
class ByteWriter {
public:
    void u8 (uint8_t  v) { buf_.push_back(v); }
    void u16(uint16_t v) { u8(v & 0xFF); u8((v>>8) & 0xFF); }
    void u32(uint32_t v) { u16(v & 0xFFFF); u16((v>>16) & 0xFFFF); }
    void i8 (int8_t   v) { u8((uint8_t)v); }
    void i16(int16_t  v) { u16((uint16_t)v); }
    void f32(float    v) { uint32_t t; std::memcpy(&t,&v,4); u32(t); }
    void bytes(const void* p, size_t n) {
        const uint8_t* b = (const uint8_t*)p;
        buf_.insert(buf_.end(), b, b + n);
    }
    const std::vector<uint8_t>& data() const { return buf_; }
    size_t size() const { return buf_.size(); }
    void clear() { buf_.clear(); }
private:
    std::vector<uint8_t> buf_;
};

class ByteReader {
public:
    ByteReader(const uint8_t* p, size_t n) : p_(p), n_(n) {}
    bool ok() const { return ok_; }
    size_t remaining() const { return n_ - pos_; }

    uint8_t  u8()  { if (pos_+1 > n_) { ok_=false; return 0; } return p_[pos_++]; }
    uint16_t u16() { uint16_t a=u8(), b=u8(); return (uint16_t)(a | (b<<8)); }
    uint32_t u32() { uint32_t a=u16(), b=u16(); return a | (b<<16); }
    int8_t   i8()  { return (int8_t)u8(); }
    int16_t  i16() { return (int16_t)u16(); }
    float    f32() { uint32_t t=u32(); float v; std::memcpy(&v,&t,4); return v; }
    void bytes(void* out, size_t n) {
        if (pos_+n > n_) { ok_=false; return; }
        std::memcpy(out, p_+pos_, n); pos_ += n;
    }
private:
    const uint8_t* p_;
    size_t n_, pos_ = 0;
    bool ok_ = true;
};

// --- Encode / decode helpers ----------------------------------------------
void writeInput(ByteWriter& w, const InputCommand& c);
bool readInput (ByteReader& r, InputCommand& c);
void writeSnapshot(ByteWriter& w, const Snapshot& s);
bool readSnapshot (ByteReader& r, Snapshot& s);

// Float<->int8 helpers for the move axes.
inline int8_t  packAxis(float v)  {
    if (v >  1.0f) v =  1.0f;
    if (v < -1.0f) v = -1.0f;
    return (int8_t)(v * 127.0f);
}
inline float   unpackAxis(int8_t v) { return (float)v / 127.0f; }

} // namespace net
