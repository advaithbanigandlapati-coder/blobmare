#include "net/Transport.h"
#include "raylib.h"   // GetRandomValue
#include <algorithm>

namespace net {

void LoopbackTransport::makePair(LoopbackTransport*& host,
                                 LoopbackTransport*& client) {
    makePair(host, client, Sim{});
}

void LoopbackTransport::makePair(LoopbackTransport*& host,
                                 LoopbackTransport*& client, Sim sim) {
    host   = new LoopbackTransport();
    client = new LoopbackTransport();
    host->role_   = Role::Host;
    client->role_ = Role::Client;
    host->peer_   = client;
    client->peer_ = host;
    host->sim_    = sim;
    client->sim_  = sim;
}

void LoopbackTransport::advance(float dtMs) {
    clockMs_ += dtMs;
    // Deliver any in-flight packets whose delay has elapsed.
    auto it = inflightToPeer_.begin();
    while (it != inflightToPeer_.end()) {
        if (clockMs_ >= it->deliverAt) {
            if (peer_) peer_->deliver(it->data, it->peer);
            it = inflightToPeer_.erase(it);
        } else {
            ++it;
        }
    }
}

bool LoopbackTransport::poll() {
    return peer_ != nullptr;
}

void LoopbackTransport::send(int peer, const uint8_t* data, size_t len) {
    if (!peer_) return;
    // Simulated packet loss.
    if (sim_.lossRate > 0.0f) {
        float roll = (float)GetRandomValue(0, 10000) / 10000.0f;
        if (roll < sim_.lossRate) return;   // dropped
    }
    // Compute delivery time = now + latency +/- jitter.
    float jitter = 0.0f;
    if (sim_.jitterMs > 0.0f) {
        jitter = ((float)GetRandomValue(-10000,10000)/10000.0f) * sim_.jitterMs;
    }
    float delay = sim_.latencyMs + jitter;
    if (delay < 0.0f) delay = 0.0f;

    Pending p;
    p.data.assign(data, data + len);
    p.deliverAt = clockMs_ + delay;
    p.peer = (role_ == Role::Host) ? peer : 0;  // who it's *from* on arrival
    inflightToPeer_.push_back(std::move(p));

    // Zero-latency fast path: deliver immediately so a no-sim loopback behaves
    // synchronously (useful for deterministic unit tests).
    if (sim_.latencyMs == 0.0f && sim_.jitterMs == 0.0f) {
        advance(0.0f);
    }
}

void LoopbackTransport::deliver(const std::vector<uint8_t>& data, int fromPeer) {
    Packet pkt;
    pkt.data = data;
    pkt.peer = fromPeer;
    inbox_.push_back(std::move(pkt));
}

bool LoopbackTransport::receive(Packet& out) {
    if (inbox_.empty()) return false;
    out = std::move(inbox_.front());
    inbox_.erase(inbox_.begin());
    return true;
}

} // namespace net
