#include "net/UdpTransport.h"
#include <cstring>

#if defined(_WIN32)
  #include <winsock2.h>
  #include <ws2tcpip.h>
  #pragma comment(lib, "ws2_32.lib")
  using socklen_t = int;
  #define CLOSESOCK closesocket
  #define SOCK_ERRNO WSAGetLastError()
  #define WOULDBLOCK WSAEWOULDBLOCK
#else
  #include <sys/socket.h>
  #include <netinet/in.h>
  #include <arpa/inet.h>
  #include <unistd.h>
  #include <fcntl.h>
  #include <errno.h>
  #define CLOSESOCK ::close
  #define SOCK_ERRNO errno
  #define WOULDBLOCK EWOULDBLOCK
  #define INVALID_SOCKET (-1)
#endif

namespace net {

namespace {
constexpr int kMaxDatagram = 1400;   // safely under typical MTU
}

bool UdpTransport::platformInit() {
#if defined(_WIN32)
    static bool done = false;
    if (done) return true;
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2,2), &wsa) != 0) return false;
    done = true;
#endif
    return true;
}

UdpTransport::UdpTransport() {
    platformInit();
}

UdpTransport::~UdpTransport() {
    closeSocket();
}

void UdpTransport::closeSocket() {
#if defined(_WIN32)
    if (sock_ != ~(uintptr_t)0) { CLOSESOCK((SOCKET)sock_); sock_ = ~(uintptr_t)0; }
#else
    if (sock_ >= 0) { CLOSESOCK(sock_); sock_ = -1; }
#endif
    open_ = false;
}

bool UdpTransport::setNonBlocking() {
#if defined(_WIN32)
    u_long mode = 1;
    return ioctlsocket((SOCKET)sock_, FIONBIO, &mode) == 0;
#else
    int flags = fcntl(sock_, F_GETFL, 0);
    if (flags < 0) return false;
    return fcntl(sock_, F_SETFL, flags | O_NONBLOCK) == 0;
#endif
}

bool UdpTransport::startHost(uint16_t port) {
    role_ = Role::Host;
    sock_ = socket(AF_INET, SOCK_DGRAM, 0);
#if defined(_WIN32)
    if ((SOCKET)sock_ == INVALID_SOCKET) { lastError_ = "socket() failed"; return false; }
#else
    if (sock_ < 0) { lastError_ = "socket() failed"; return false; }
#endif
    // Allow quick rebind after a restart.
    int yes = 1;
    setsockopt((int)sock_, SOL_SOCKET, SO_REUSEADDR,
               (const char*)&yes, sizeof(yes));

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(port);
    if (bind((int)sock_, (sockaddr*)&addr, sizeof(addr)) < 0) {
        lastError_ = "bind() failed — port " + std::to_string(port) +
                     " may be in use";
        closeSocket();
        return false;
    }
    if (!setNonBlocking()) {
        lastError_ = "could not set non-blocking";
        closeSocket();
        return false;
    }
    open_ = true;
    peerKnown_ = false;            // learned from the client's first datagram
    lastError_.clear();
    return true;
}

bool UdpTransport::startClient(const std::string& hostIp, uint16_t hostPort) {
    role_ = Role::Client;
    sock_ = socket(AF_INET, SOCK_DGRAM, 0);
#if defined(_WIN32)
    if ((SOCKET)sock_ == INVALID_SOCKET) { lastError_ = "socket() failed"; return false; }
#else
    if (sock_ < 0) { lastError_ = "socket() failed"; return false; }
#endif
    // OS assigns an ephemeral local port automatically on first send.
    if (!setNonBlocking()) {
        lastError_ = "could not set non-blocking";
        closeSocket();
        return false;
    }
    // Resolve + store the host address as our peer.
    sockaddr_in dst{};
    dst.sin_family = AF_INET;
    dst.sin_port = htons(hostPort);
    if (inet_pton(AF_INET, hostIp.c_str(), &dst.sin_addr) != 1) {
        lastError_ = "invalid host IP: " + hostIp;
        closeSocket();
        return false;
    }
    std::memcpy(peerAddr_, &dst, sizeof(dst));
    peerAddrLen_ = sizeof(dst);
    peerKnown_ = true;
    open_ = true;
    lastError_.clear();
    return true;
}

bool UdpTransport::connected() const {
    // Host: connected once it has heard from a client. Client: once the
    // socket is open (the session-level handshake confirms the rest).
    return open_ && (role_ == Role::Client || peerKnown_);
}

void UdpTransport::recordRtt(float ms) {
    // Exponential smoothing so a single spike doesn't dominate.
    rttMs_ = (rttMs_ <= 0.0f) ? ms : rttMs_ * 0.8f + ms * 0.2f;
}

bool UdpTransport::poll() {
    if (!open_) return false;
    // Drain everything currently in the OS receive buffer.
    uint8_t buf[kMaxDatagram];
    for (int guard = 0; guard < 256; ++guard) {   // bounded per call
        sockaddr_in from{};
        socklen_t fromLen = sizeof(from);
        int n = (int)recvfrom((int)sock_, (char*)buf, sizeof(buf), 0,
                              (sockaddr*)&from, &fromLen);
        if (n <= 0) {
            // No more data (WOULDBLOCK) or an error — stop draining.
            break;
        }
        // A host learns its peer from the first datagram it receives.
        if (role_ == Role::Host && !peerKnown_) {
            std::memcpy(peerAddr_, &from, sizeof(from));
            peerAddrLen_ = sizeof(from);
            peerKnown_ = true;
        }
        Packet pkt;
        pkt.data.assign(buf, buf + n);
        pkt.peer = 0;
        inbox_.push_back(std::move(pkt));
    }
    return true;
}

void UdpTransport::send(int peer, const uint8_t* data, size_t len) {
    (void)peer;
    if (!open_ || !peerKnown_) return;            // nobody to send to yet
    if (len > kMaxDatagram) return;               // oversized — drop
    sockaddr_in dst{};
    std::memcpy(&dst, peerAddr_, sizeof(dst));
    sendto((int)sock_, (const char*)data, (int)len, 0,
           (sockaddr*)&dst, peerAddrLen_);
    // UDP send is fire-and-forget; a failure here just means a lost packet,
    // which the protocol's redundancy + extrapolation already tolerate.
}

bool UdpTransport::receive(Packet& out) {
    if (inbox_.empty()) return false;
    out = std::move(inbox_.front());
    inbox_.pop_front();
    return true;
}

} // namespace net
