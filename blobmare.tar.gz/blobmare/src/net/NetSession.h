#pragma once
// =============================================================================
//  NetSession — protocol state machine over a Transport
// =============================================================================
//
//  NetSession turns the raw packet Transport into a game-level service:
//
//    HOST:   collects remote client input, exposes both players' inputs for
//            the authoritative sim, and broadcasts Snapshots each tick.
//    CLIENT: sends local input to the host, receives Snapshots, and exposes
//            them (plus its own predicted input) to the renderer.
//
//  The session is deliberately sim-agnostic: it does not know what a Blob is.
//  It traffics InputCommands and Snapshots. The MATCH code (next stage) owns
//  applying a Snapshot to the world and reading inputs back out — that keeps
//  this layer unit-testable without the whole game.
//
//  STATE MACHINE
//    Disconnected -> Handshaking -> Connected -> (Disconnected on Bye/timeout)
//
//  This stage is fully exercised by LoopbackTransport in nettest2. The UDP
//  transport (next stage) plugs in underneath with zero changes here.
//
#include "net/NetTypes.h"
#include "net/Transport.h"
#include <memory>
#include <vector>
#include <deque>

namespace net {

enum class SessionState { Disconnected, Handshaking, Connected };

// Minimal match parameters exchanged at handshake so both peers agree.
struct SessionConfig {
    uint32_t matchSeed     = 0;   // shared RNG seed -> identical minigame slate
    uint8_t  minigameCount = 5;
    uint8_t  roundsToWin   = 4;
};

class NetSession {
public:
    // Takes ownership of the transport.
    void begin(std::unique_ptr<Transport> transport, const SessionConfig& cfg);
    void shutdown();

    // Pump the network: process incoming packets, time out dead peers.
    // 'dtMs' advances internal timers (and LoopbackTransport's sim clock).
    void update(float dtMs);

    SessionState state() const { return state_; }
    bool isHost() const   { return role_ == Role::Host; }
    bool isClient() const { return role_ == Role::Client; }
    int  localPlayer() const  { return localPlayer_; }
    int  remotePlayer() const { return 1 - localPlayer_; }
    const SessionConfig& config() const { return config_; }
    float pingMs() const { return transport_ ? transport_->pingMs() : 0.0f; }

    // --- Input flow ------------------------------------------------------
    // The game submits the local player's input for a tick. The session
    // sends it (client) or just records it (host).
    void submitLocalInput(const InputCommand& cmd);

    // Best-known input for a given player at a given tick. The host uses this
    // to drive the authoritative sim; missing remote input falls back to the
    // last received command (input extrapolation), which masks brief loss.
    InputCommand inputFor(int player, uint32_t tick) const;

    // --- Snapshot flow ---------------------------------------------------
    // HOST: publish the authoritative snapshot for this tick (broadcasts it).
    void publishSnapshot(const Snapshot& snap);

    // CLIENT: the most recent snapshot received (for rendering/applying).
    bool latestSnapshot(Snapshot& out) const;
    // CLIENT: how many snapshots are buffered (for interpolation decisions).
    int  snapshotBacklog() const { return (int)snapshots_.size(); }
    // CLIENT: pop the oldest buffered snapshot (for ordered consumption).
    bool popSnapshot(Snapshot& out);

    // The last input tick the host acknowledges having from us (client-side
    // reconciliation uses this to discard confirmed predicted inputs).
    uint32_t ackedInputTick() const { return ackedInputTick_; }

    // --- Voice frames (proximity VC) -------------------------------------
    // Send an already-encoded voice frame body to the peer.
    void sendVoiceFrame(const uint8_t* data, size_t len);
    // Pop the next received voice frame body, if any. Returns false when none.
    bool popVoiceFrame(std::vector<uint8_t>& out);

private:
    std::unique_ptr<Transport> transport_;
    SessionState state_ = SessionState::Disconnected;
    Role role_ = Role::Host;
    SessionConfig config_;
    int  localPlayer_ = 0;

    // Input history per player: a ring of recent commands keyed by tick.
    static constexpr int kInputHistory = 128;
    InputCommand inputHist_[kMaxPlayers][kInputHistory];
    uint32_t     latestInputTick_[kMaxPlayers] = {};

    // Host: last input tick consumed from each client (echoed in snapshots).
    uint32_t lastConsumedInput_[kMaxPlayers] = {};
    // Client: last input tick the host said it has from us.
    uint32_t ackedInputTick_ = 0;

    // Received voice-frame bodies, drained by the game's VoiceChat module.
    std::deque<std::vector<uint8_t>> voiceInbox_;

    // Client: received snapshot buffer (ordered, bounded).
    std::deque<Snapshot> snapshots_;
    Snapshot latest_{};
    bool     haveLatest_ = false;

    // Timers.
    float timeSinceRecvMs_ = 0.0f;
    float timeSincePingMs_ = 0.0f;
    float helloRetryMs_ = 0.0f;     // client handshake retransmit timer
    static constexpr float kTimeoutMs   = 5000.0f;
    static constexpr float kPingEveryMs = 1000.0f;
    static constexpr float kHelloRetryMs = 250.0f;  // resend Hello 4x/sec

    void recordInput(int player, const InputCommand& cmd);
    void handlePacket(const Packet& pkt);
    void sendHello();
    void sendWelcome(int toPeer);
    void sendBytes(int peer, const ByteWriter& w);
};

} // namespace net
