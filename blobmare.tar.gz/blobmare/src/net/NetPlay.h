#pragma once
// =============================================================================
//  NetPlay — bridges the game's input/sim to a NetSession
// =============================================================================
//
//  This is the integration layer: it converts between the game's PlayerInput
//  / Blob types and the network's InputCommand / Snapshot types, and decides,
//  per tick, what input each blob should act on.
//
//  THREE MODES (NetMode):
//    Local   — no networking. Both blobs read local devices. Identical to the
//              original game; netcode is entirely bypassed.
//    Host    — this peer is authoritative. Blob[local] reads local devices;
//              blob[remote] reads the client's networked input. After each
//              sim tick the host captures a Snapshot and publishes it.
//    Client  — this peer is non-authoritative. It sends its local input and
//              applies the host's Snapshots to the blobs. It also locally
//              PREDICTS its own blob so its controls feel instant.
//
//  Why a bridge instead of editing the scenes directly: the scenes call
//  netInputFor()/captureSnapshot()/applySnapshot() and never touch sockets.
//  In Local mode those calls are trivial passthroughs, so the offline game is
//  provably unchanged. In network mode the same calls route through the
//  session. One seam, three behaviours.
//
#include "core/Input.h"
#include "net/NetTypes.h"
#include "net/ClientPredictor.h"
#include "net/VoiceChat.h"
#include <memory>
#include <vector>

namespace net { class NetSession; }
class Blob;
class World;

enum class NetMode { Local, Host, Client };

class NetPlay {
public:
    // Local mode: no session. The default; offline game uses this.
    void beginLocal();
    // Network mode: takes a connected session (Host or Client role).
    void beginNetworked(std::shared_ptr<net::NetSession> session);
    // Loopback-only: attach the partner (client) session so NetPlay can pump
    // it and feed it player 2's local device input. In real UDP play this is
    // never set — the partner is a separate process.
    void attachLoopbackPartner(std::shared_ptr<net::NetSession> partner);
    void end();

    NetMode mode() const { return mode_; }
    bool isNetworked() const { return mode_ != NetMode::Local; }
    net::NetSession* session() { return session_.get(); }

    // The simulation tick counter. Advanced once per fixed sim step by the
    // scene via advanceTick(). Network input is keyed on this.
    uint32_t tick() const { return tick_; }
    void advanceTick() { ++tick_; }
    void resetTick(uint32_t t = 0) { tick_ = t; }

    // --- Per-tick input -------------------------------------------------
    // Called by the sim each step, BEFORE blobs read input. It samples local
    // devices, submits them to the session (if networked), and pumps the net.
    void sampleAndSync(const Input& input, float dtMs);

    // The PlayerInput a given blob should act on THIS tick. In Local mode this
    // is just the device input. In network mode it resolves local vs remote.
    PlayerInput inputForBlob(int blobIndex, const Input& input) const;

    // --- Snapshot bridge (network only) ---------------------------------
    // HOST: after stepping the sim, snapshot the blobs and publish.
    void captureAndPublish(const std::vector<Blob*>& blobs,
                           uint8_t sceneId, uint8_t minigameIndex,
                           const int score[2]);
    // CLIENT: apply the latest authoritative snapshot to the blobs. Returns
    // true if a snapshot was applied this call.
    bool applyLatestSnapshot(std::vector<Blob*>& blobs);

    // CLIENT: which blob index is locally controlled (for prediction).
    int  localBlobIndex() const;

    // CLIENT: record the local blob's post-integration state for this tick,
    // so reconciliation can replay from it. Call once per sim step AFTER the
    // blobs have integrated. No-op outside Client mode.
    void recordPredictionFrame(const std::vector<Blob*>& blobs);

    // --- Client-side prediction -----------------------------------------
    // CLIENT: bind the active minigame's World so the predictor can
    // re-simulate. Call from the minigame's setup; clears prior history.
    void bindPredictionWorld(World* world, float fixedDt);
    // CLIENT: the smoothed visual offset to add to the local blob's render
    // position so a reconciliation correction eases in. Zero in other modes.
    Vector3 predictionVisualOffset() const;

    // --- Proximity voice chat -------------------------------------------
    // Enable voice for a networked match. 'mic' is the capture source —
    // pass a real RtMicSource in the game, a SyntheticMicSource for tests.
    // No-op (and voice stays off) in Local mode.
    void enableVoice(std::unique_ptr<net::MicSource> mic);
    void disableVoice();
    bool voiceActive() const;

    // Per sim step: capture+send a voice frame if due, drain incoming frames
    // into playback, and update proximity from the blob distance.
    void updateVoice(const std::vector<Blob*>& blobs);

    // Proximity gain currently applied to remote voice (0..1) — for HUD.
    float voiceGain() const;

    // Conversion helpers (public for testing).
    static net::InputCommand toCommand(const PlayerInput& in, uint32_t tick);
    static PlayerInput        toPlayerInput(const net::InputCommand& cmd);

private:
    NetMode mode_ = NetMode::Local;
    std::shared_ptr<net::NetSession> session_;
    // Loopback partner (client side) — only set in loopback networked mode.
    std::shared_ptr<net::NetSession> loopbackPartner_;
    uint32_t tick_ = 0;

    // Client-side prediction for the local blob (Client mode only).
    ClientPredictor predictor_;
    // Proximity voice chat (networked modes only).
    net::VoiceChat voice_;

    // Cache of this tick's resolved inputs, filled by sampleAndSync.
    PlayerInput resolved_[net::kMaxPlayers];
    // Edge-detection state for converting held buttons into *Pressed flags
    // after they arrive over the network.
    mutable uint8_t prevButtons_[net::kMaxPlayers] = {0,0};
};
