#include "net/ClientPredictor.h"
#include "net/NetPlay.h"
#include "blob/Blob.h"
#include "physics/World.h"
#include "raymath.h"
#include <cmath>

using namespace net;

void ClientPredictor::begin(World* world, float fixedDt) {
    world_ = world;
    fixedDt_ = fixedDt;
    reset();
}

void ClientPredictor::reset() {
    for (auto& f : history_) f.valid = false;
    visualOffset_ = Vector3{0,0,0};
    lastReplayCount_ = 0;
    lastCorrection_ = 0.0f;
}

ClientPredictor::Frame* ClientPredictor::find(uint32_t tick) {
    Frame& f = history_[tick % kHistory];
    return (f.valid && f.tick == tick) ? &f : nullptr;
}

void ClientPredictor::recordTick(uint32_t tick, const Blob& localBlob,
                                 const InputCommand& inputUsed) {
    Frame& f = history_[tick % kHistory];
    f.tick   = tick;
    f.valid  = true;
    f.pos    = localBlob.position();
    f.vel    = localBlob.velocity();
    f.facing = localBlob.facing();
    f.input  = inputUsed;
}

float ClientPredictor::reconcile(uint32_t snapTick,
                                 const NetBlobState& authoritative,
                                 uint32_t ackedInput, Blob& localBlob) {
    lastReplayCount_ = 0;
    lastCorrection_  = 0.0f;
    if (!world_) return 0.0f;

    // Find what we predicted for the snapshot's tick.
    Frame* predicted = find(snapTick);
    if (!predicted) {
        // No record that far back (snapshot very old, or buffer wrapped).
        // Nothing safe to reconcile against — leave the blob alone.
        return 0.0f;
    }

    Vector3 authPos{ authoritative.px, authoritative.py, authoritative.pz };
    float divergence = Vector3Distance(authPos, predicted->pos);

    // Prediction was accurate enough — no correction needed.
    if (divergence <= kCorrectThreshold)
        return 0.0f;

    // --- Re-simulation -----------------------------------------------------
    // The blob's CURRENT visible position, before we correct it. We ease the
    // visual offset from here so the player sees a slide, not a jump.
    Vector3 beforePos = localBlob.position();

    // Snap an internal cursor blob to the authoritative state...
    localBlob.setPosition(authPos);
    localBlob.setVelocity(Vector3{ authoritative.vx, authoritative.vy,
                                   authoritative.vz });
    localBlob.faceTowards(Vector3{ authoritative.fx, 0.0f, authoritative.fz });

    // ...then replay every tick AFTER the snapshot, using the inputs we still
    // have buffered. Those are the inputs the host had not yet applied when it
    // built this snapshot — i.e. ticks > snapTick up to our latest record.
    // (ackedInput is informational: it confirms the host has our input up to
    // that tick; we replay from snapTick+1 regardless, which is a superset.)
    (void)ackedInput;

    uint32_t t = snapTick + 1;
    int replayed = 0;
    // Replay until we run out of recorded frames (i.e. reach "now").
    while (replayed < kHistory) {
        Frame* fr = find(t);
        if (!fr) break;                       // caught up to the present
        PlayerInput in = NetPlay::toPlayerInput(fr->input);
        // Re-derive *Pressed edges from the previous frame's buttons so a
        // replayed jump/dash fires exactly as it did the first time.
        Frame* prev = find(t - 1);
        uint8_t prevB = prev ? prev->input.buttons : 0;
        uint8_t nowB  = fr->input.buttons;
        in.jumpPressed   = (nowB & InputCommand::Jump)   && !(prevB & InputCommand::Jump);
        in.actionPressed = (nowB & InputCommand::Action) && !(prevB & InputCommand::Action);
        in.dashPressed   = (nowB & InputCommand::Dash)   && !(prevB & InputCommand::Dash);

        localBlob.control(in, fixedDt_, true, true);
        localBlob.integrate(*world_, fixedDt_);

        // Overwrite the stored prediction with the corrected state, so future
        // reconciliations compare against this now-authoritative-rooted path.
        fr->pos    = localBlob.position();
        fr->vel    = localBlob.velocity();
        fr->facing = localBlob.facing();

        ++replayed;
        ++t;
    }
    lastReplayCount_ = replayed;

    // The corrected "now" position.
    Vector3 afterPos = localBlob.position();
    lastCorrection_ = Vector3Distance(beforePos, afterPos);

    // Roll the visible offset so rendering stays where the eye expects, then
    // decayVisualOffset() eases it to zero — the slide.
    visualOffset_ = Vector3Add(visualOffset_,
                               Vector3Subtract(beforePos, afterPos));

    // Clamp the visual offset: a correction so large that easing it would look
    // worse than a snap should just snap (e.g. a teleport / respawn).
    float offLen = Vector3Length(visualOffset_);
    const float kMaxVisual = 2.5f;
    if (offLen > kMaxVisual)
        visualOffset_ = Vector3Scale(visualOffset_, kMaxVisual / offLen);

    return lastCorrection_;
}

void ClientPredictor::decayVisualOffset(float dt) {
    // Exponential ease toward zero.
    float k = std::exp(-kVisualEaseRate * dt);
    visualOffset_ = Vector3Scale(visualOffset_, k);
    if (Vector3Length(visualOffset_) < 0.001f)
        visualOffset_ = Vector3{0,0,0};
}
