#include "net/VoiceChat.h"
#include <cmath>
#include <algorithm>

namespace net {

// --- SyntheticMicSource -----------------------------------------------------
// A 440 Hz tone amplitude-modulated at 3 Hz — distinct enough that the decoded
// signal can be checked for fidelity in tests.
bool SyntheticMicSource::readFrame(std::vector<float>& out) {
    if (!running_) return false;
    out.resize(kVoiceFrameSamples);
    for (int i = 0; i < kVoiceFrameSamples; ++i) {
        float t = phase_ + (float)i / kVoiceSampleRate;
        float env = 0.6f + 0.4f * std::sin(2.0f * PI * 3.0f * t);
        out[i] = env * 0.7f * std::sin(2.0f * PI * 440.0f * t);
    }
    phase_ += (float)kVoiceFrameSamples / kVoiceSampleRate;
    return true;
}

// --- VoiceCodec -------------------------------------------------------------
// mu-law-style companding: float [-1,1] -> 8-bit. Halves the data vs 16-bit
// PCM and concentrates resolution where the ear needs it. Dependency-free.
namespace VoiceCodec {

static uint8_t encodeSample(float x) {
    if (x >  1.0f) x =  1.0f;
    if (x < -1.0f) x = -1.0f;
    const float mu = 255.0f;
    float sign = (x < 0.0f) ? -1.0f : 1.0f;
    float mag = std::log1p(mu * std::fabs(x)) / std::log1p(mu);  // 0..1
    int q = (int)(mag * 127.0f + 0.5f);
    if (q > 127) q = 127;
    return (uint8_t)((sign < 0 ? 0x80 : 0x00) | q);
}

static float decodeSample(uint8_t b) {
    float sign = (b & 0x80) ? -1.0f : 1.0f;
    float mag = (float)(b & 0x7F) / 127.0f;
    const float mu = 255.0f;
    float x = (std::expm1(mag * std::log1p(mu))) / mu;            // inverse
    return sign * x;
}

void encode(const std::vector<float>& pcm, std::vector<uint8_t>& out) {
    out.resize(pcm.size());
    for (size_t i = 0; i < pcm.size(); ++i)
        out[i] = encodeSample(pcm[i]);
}

void decode(const std::vector<uint8_t>& in, std::vector<float>& pcm) {
    pcm.resize(in.size());
    for (size_t i = 0; i < in.size(); ++i)
        pcm[i] = decodeSample(in[i]);
}

} // namespace VoiceCodec

// --- VoiceChat --------------------------------------------------------------

void VoiceChat::begin(std::unique_ptr<MicSource> mic) {
    mic_ = std::move(mic);
    if (mic_) mic_->start();

    // Playback stream: 16 kHz mono, 16-bit. Guarded — audio may be unavailable
    // (headless), in which case playback is simply skipped.
    if (IsAudioDeviceReady()) {
        stream_ = LoadAudioStream(kVoiceSampleRate, 16, 1);
        streamValid_ = IsAudioStreamValid(stream_);
        if (streamValid_) PlayAudioStream(stream_);
    }
    captureAccumMs_ = 0.0f;
    remoteQueue_.clear();
    active_ = true;
}

void VoiceChat::end() {
    if (mic_) { mic_->stop(); mic_.reset(); }
    if (streamValid_) { UnloadAudioStream(stream_); streamValid_ = false; }
    remoteQueue_.clear();
    active_ = false;
}

bool VoiceChat::captureEncoded(std::vector<uint8_t>& outPacketBody) {
    if (!active_ || !mic_) return false;
    std::vector<float> frame;
    if (!mic_->readFrame(frame)) return false;
    if (frame.size() != (size_t)kVoiceFrameSamples) return false;

    // Encode the frame body. The MsgType::VoiceFrame envelope is added by the
    // caller (the match), consistent with how other messages are framed.
    VoiceCodec::encode(frame, outPacketBody);

    // Optional self-monitor: hear your own voice locally (debugging aid).
    if (selfMonitor_)
        remoteQueue_.insert(remoteQueue_.end(), frame.begin(), frame.end());
    return true;
}

void VoiceChat::onRemoteFrame(const uint8_t* data, size_t len) {
    if (!active_) return;
    std::vector<uint8_t> enc(data, data + len);
    std::vector<float> pcm;
    VoiceCodec::decode(enc, pcm);
    // Queue for playback; updatePlayback() applies proximity gain + streams it.
    remoteQueue_.insert(remoteQueue_.end(), pcm.begin(), pcm.end());
    // Bound the queue so a stall can't grow it without limit (~1 s max).
    const size_t cap = (size_t)kVoiceSampleRate;
    if (remoteQueue_.size() > cap)
        remoteQueue_.erase(remoteQueue_.begin(),
                           remoteQueue_.begin() + (remoteQueue_.size() - cap));
}

void VoiceChat::setProximity(float distance) {
    distance_ = distance;
}

float VoiceChat::proximityGain() const {
    // Full volume within ~1/4 range, smooth falloff to silence at maxRange_.
    float near = maxRange_ * 0.25f;
    if (distance_ <= near) return 1.0f;
    if (distance_ >= maxRange_) return 0.0f;
    float t = (distance_ - near) / (maxRange_ - near);   // 0..1
    // Smooth (cosine) falloff.
    return 0.5f + 0.5f * std::cos(t * PI);
}

void VoiceChat::updatePlayback() {
    if (!active_) return;
    gain_ = proximityGain();
    if (!streamValid_) { remoteQueue_.clear(); return; }
    if (!IsAudioStreamProcessed(stream_)) return;       // buffer not ready
    if (remoteQueue_.empty()) return;

    // Pull one frame's worth, apply proximity gain, convert to 16-bit, stream.
    int n = std::min((int)remoteQueue_.size(), kVoiceFrameSamples);
    std::vector<int16_t> pcm16(kVoiceFrameSamples, 0);
    for (int i = 0; i < n; ++i) {
        float v = remoteQueue_[i] * gain_;
        if (v >  1.0f) v =  1.0f;
        if (v < -1.0f) v = -1.0f;
        pcm16[i] = (int16_t)(v * 32000.0f);
    }
    remoteQueue_.erase(remoteQueue_.begin(), remoteQueue_.begin() + n);
    UpdateAudioStream(stream_, pcm16.data(), kVoiceFrameSamples);
}

} // namespace net
