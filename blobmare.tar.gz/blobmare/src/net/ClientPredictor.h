#pragma once
// =============================================================================
//  ClientPredictor — client-side prediction & reconciliation for the local blob
// =============================================================================
//
//  THE PROBLEM
//  On a client, the local player's blob is simulated locally every tick so the
//  controls feel instant — we cannot wait for a round-trip to the host before
//  the blob moves. But the HOST is authoritative. Sooner or later the host's
//  snapshot for some past tick T will disagree with what the client predicted
//  for T (a collision resolved differently, an input that arrived late, etc.).
//
//  THE FIX (standard client-side prediction + reconciliation)
//    1. Every tick the client records its predicted local-blob state, keyed by
//       tick, in a ring buffer — along with the input it used.
//    2. When a snapshot for tick T arrives, compare the authoritative local
//       state against the recorded prediction for T.
//    3. If they diverge beyond a threshold: snap an internal "authoritative
//       cursor" to the snapshot state, then RE-SIMULATE ticks T+1 .. now using
//       the recorded inputs (which are still buffered — the host told us which
//       it has via ackedInputTick, the rest are unconfirmed and must be
//       replayed). The result is a corrected "true" position for now.
//    4. Ease the VISIBLE blob position toward that corrected position over
//       ~100 ms instead of snapping, so a correction looks like a small slide,
//       not a teleport.
//
//  WHY THIS IS TESTABLE HERE
//  It is fully deterministic: given the same authoritative state + the same
//  replay inputs, re-simulation produces the same result every time. No real
//  network needed to verify the math — nettest5 does exactly that.
//
//  This module owns ONLY the local blob's prediction. The remote blob is
//  snapshot-driven directly (in NetPlay) and needs no prediction.
//
#include "raylib.h"
#include "net/NetTypes.h"
#include <vector>

class Blob;
class World;

class ClientPredictor {
public:
    // Bind the world the local blob lives in (used for re-simulation).
    void begin(World* world, float fixedDt);
    void reset();
    bool active() const { return world_ != nullptr; }

    // Record the local blob's state + the input used, AFTER a normal tick.
    // 'tick' is the sim tick that was just simulated.
    void recordTick(uint32_t tick, const Blob& localBlob,
                    const net::InputCommand& inputUsed);

    // A snapshot arrived. Compare + reconcile. 'authoritative' is the local
    // blob's state from the snapshot; 'snapTick' the tick it is for;
    // 'ackedInput' the last input tick the host had when it built the snapshot.
    // 'localBlob' is corrected in place if needed. Returns the correction
    // distance applied (0 if prediction was already accurate).
    float reconcile(uint32_t snapTick, const net::NetBlobState& authoritative,
                    uint32_t ackedInput, Blob& localBlob);

    // The smoothed visual offset to add to the blob's render position so a
    // correction eases in rather than snaps. Decays to zero over ~100 ms.
    Vector3 visualOffset() const { return visualOffset_; }
    void    decayVisualOffset(float dt);

    // Stats for the HUD / debugging.
    int   lastReplayCount() const { return lastReplayCount_; }
    float lastCorrection() const  { return lastCorrection_; }

private:
    struct Frame {
        uint32_t tick = 0;
        bool     valid = false;
        Vector3  pos{}, vel{}, facing{0,0,1};
        net::InputCommand input;
    };

    static constexpr int kHistory = 256;   // ~2s at 120Hz
    Frame   history_[kHistory];
    World*  world_ = nullptr;
    float   fixedDt_ = 1.0f / 120.0f;

    Vector3 visualOffset_{0,0,0};
    int     lastReplayCount_ = 0;
    float   lastCorrection_  = 0.0f;

    // Divergence beyond this (world units) triggers a re-simulation.
    static constexpr float kCorrectThreshold = 0.04f;
    // Visual offset eases out at this rate (higher = snappier).
    static constexpr float kVisualEaseRate = 12.0f;

    Frame* find(uint32_t tick);
};
