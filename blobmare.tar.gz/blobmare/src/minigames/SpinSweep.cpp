// =============================================================================
//  Minigame: Spin Sweep
//  A rotating beam sweeps around a central pillar like a clock hand. Jump it
//  or get swept off the disc into the void. The beam speeds up over time.
//  Last blob standing wins.
// =============================================================================
#include "game/MinigameBase.h"
#include "game/MinigameRegistry.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "render/Prims.h"
#include "raymath.h"
#include "rlgl.h"
#include <cmath>
#include <vector>

namespace {

class SpinSweep : public MinigameBase {
protected:
    void onSetup(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)ctx;
        angle_ = 0.0f;
        world().setGravity(Vector3{ 0, -30, 0 });
        world().setKillY(-14.0f);
        // Central pillar collider so blobs can't stand in the safe eye.
        world().addBox(phys::makeBox(Vector3{0, 1.5f, 0},
                                     Vector3{ 0.7f, 1.5f, 0.7f }));
        for (size_t i = 0; i < blobs.size(); ++i) {
            float a = (i==0)?PI:0.0f;
            blobs[i]->respawn(Vector3{ std::cos(a)*3.4f, 1.2f,
                                       std::sin(a)*3.4f });
        }
    }

    void onUpdate(GameContext& ctx, std::vector<Blob*>& blobs,
                  float dt) override {
        // Beam spins, accelerating.
        float speed = kBaseSpeed + elapsed() * 0.12f;
        angle_ += speed * dt;

        for (Blob* b : blobs) {
            b->integrate(world(), dt);
            if (!b->alive()) continue;
            Vector3 p = b->position();
            float horiz = std::sqrt(p.x*p.x + p.z*p.z);

            // Rest on the disc.
            if (horiz < kDiscR && p.y - b->radius() < 1.0f
                    && b->velocity().y <= 0.1f) {
                p.y = 1.0f + b->radius();
                b->setPosition(p);
                Vector3 v = b->velocity();
                if (v.y < 0) v.y = 0;
                b->setVelocity(v);
            }

            // Beam contact: it's a thin rotating arm. A blob is hit if it is
            // close to the beam line AND low enough not to have jumped it.
            float beamAng = std::atan2(p.z, p.x);
            float diff = std::fabs(std::remainder(beamAng - angle_, 2.0f*PI));
            bool nearBeam = diff < (0.34f / std::max(horiz, 0.6f));
            bool lowEnough = (p.y - b->radius()) < kBeamHeight;
            if (nearBeam && lowEnough && horiz > 1.0f && horiz < kDiscR) {
                // Sweep them outward hard.
                Vector3 outward = Vector3Normalize(Vector3{p.x, 0.2f, p.z});
                Vector3 tangent{ -std::sin(angle_), 0, std::cos(angle_) };
                Vector3 launch = Vector3Add(Vector3Scale(outward, 9.0f),
                                            Vector3Scale(tangent, 6.0f));
                launch.y = 5.0f;
                b->addImpulse(launch);
                b->setEmote(Emote::Dizzy);
                ctx.audio.play(Sfx::Whoosh, 0.7f);
                ctx.shake.add(0.25f);
            }
        }

        blobBump(ctx, blobs, 0.7f);
        resolveLastStanding(blobs);
    }

    void onDraw3D(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        ctx.lighting.begin();
        prims::disc(Vector3{0,1.0f,0}, kDiscR, 1.0f,
                    Color{52,56,80,255}, Color{110,120,170,255});
        prims::pillar(Vector3{0,1.0f,0}, 0.7f, 2.4f, Color{80,70,100,255});
        ctx.lighting.end();

        // The sweeping beam — a long thin box rotating around the pillar.
        rlPushMatrix();
        rlTranslatef(0, 1.0f + kBeamHeight*0.5f, 0);
        rlRotatef(-angle_ * RAD2DEG, 0, 1, 0);
        DrawCube(Vector3{ kDiscR*0.5f, 0, 0 }, kDiscR, kBeamHeight, 0.4f,
                 Color{230,90,90,255});
        DrawCubeWires(Vector3{ kDiscR*0.5f, 0, 0 }, kDiscR, kBeamHeight, 0.4f,
                      Color{255,150,140,255});
        rlPopMatrix();

        for (int i = 1; i <= 3; ++i)
            DrawCylinderWires(Vector3{0,-i*3.0f,0}, kDiscR*0.6f, kDiscR*0.6f,
                              0.02f, 24, Color{60,40,60,90});
    }

    void onDrawHUD(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        ui::centerText("JUMP THE SWEEPING BEAM", ctx.screenW/2, 84, 22,
                       Color{255,150,90,255});
    }

public:
    MinigameInfo info() const override {
        return MinigameInfo{
            "Spin Sweep",
            "the beam never stops",
            "time your jumps over the beam",
            WinKind::LastStanding,
        };
    }

private:
    static constexpr float kDiscR      = 5.5f;
    static constexpr float kBeamHeight = 1.0f;
    static constexpr float kBaseSpeed  = 1.5f;
    float angle_ = 0.0f;
};

} // namespace

REGISTER_MINIGAME(SpinSweep);
