// =============================================================================
//  Minigame: Floor Is Lava
//  The ground is rising lava. Scattered platforms are the only safety, and
//  they sink one by one. Touch the lava and you're out. Last blob standing.
// =============================================================================
#include "game/MinigameBase.h"
#include "game/MinigameRegistry.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "render/Prims.h"
#include "raymath.h"
#include <cmath>
#include <vector>

namespace {

class FloorIsLava : public MinigameBase {
protected:
    struct Plat { Vector3 pos; float sx, sz; float sinkAt; bool sunk = false; };

    void onSetup(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)ctx;
        lava_ = -2.0f;
        world().setGravity(Vector3{ 0, -28, 0 });
        world().setKillY(-12.0f);
        plats_.clear();

        // A grid of platforms at varied heights, each with a sink time.
        const float spots[][3] = {
            {-4,1.4f,-4},{0,1.0f,-4},{4,1.6f,-4},
            {-4,1.8f, 0},{0,2.4f, 0},{4,1.2f, 0},
            {-4,1.0f, 4},{0,1.6f, 4},{4,2.0f, 4},
        };
        for (int i = 0; i < 9; ++i) {
            Plat p;
            p.pos = Vector3{ spots[i][0], spots[i][1], spots[i][2] };
            p.sx = 2.4f; p.sz = 2.4f;
            p.sinkAt = 6.0f + i * 1.6f + (float)GetRandomValue(0, 20) / 10.0f;
            plats_.push_back(p);
        }
        rebuildColliders();

        for (size_t i = 0; i < blobs.size(); ++i)
            blobs[i]->respawn(Vector3{ (i==0?-4.0f:4.0f), 4.0f, 0.0f });
    }

    void rebuildColliders() {
        world().boxes().clear();
        for (auto& p : plats_) {
            if (p.sunk) continue;
            world().addBox(phys::makeBox(
                Vector3{ p.pos.x, p.pos.y - 0.4f, p.pos.z },
                Vector3{ p.sx*0.5f, 0.4f, p.sz*0.5f }));
        }
    }

    void onUpdate(GameContext& ctx, std::vector<Blob*>& blobs,
                  float dt) override {
        // Rising lava.
        lava_ += kLavaRise * dt;

        // Sink platforms on schedule.
        bool changed = false;
        for (auto& p : plats_) {
            if (!p.sunk && elapsed() > p.sinkAt) {
                p.sunk = true;
                changed = true;
                ctx.particles.smokePuff(p.pos, 14, Color{120,90,80,255});
                ctx.audio.play(Sfx::Whoosh, 0.5f);
            }
        }
        if (changed) rebuildColliders();

        for (Blob* b : blobs) {
            b->integrate(world(), dt);
            if (!b->alive()) continue;
            // Lava contact.
            if (b->position().y - b->radius() < lava_ + 0.3f) {
                b->kill();
                ctx.particles.burst(b->position(), 30, Color{255,120,40,255}, 9);
                ctx.particles.splat(Vector3{b->position().x, lava_+0.1f,
                                             b->position().z},
                                    Color{255,90,30,255}, 1.2f);
                ctx.audio.play(Sfx::Splash);
                ctx.shake.add(0.4f);
            }
        }

        blobBump(ctx, blobs, 0.7f);
        resolveLastStanding(blobs);
    }

    void onDraw3D(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        // Lava surface — a big glowing slab that pulses.
        float glow = 0.7f + 0.3f * std::sin((float)GetTime() * 3.0f);
        DrawCube(Vector3{0, lava_, 0}, 40, 0.5f, 40,
                 Color{(unsigned char)(220*glow), (unsigned char)(70*glow),
                       30, 255});
        prims::groundGrid(Vector3{0, lava_+0.26f, 0}, 20, 2.0f,
                          Color{255,160,60,90});

        ctx.lighting.begin();
        for (auto& p : plats_) {
            if (p.sunk) continue;
            prims::platform(p.pos, p.sx, p.sz, 0.8f,
                            Color{70,120,90,255}, Color{120,200,150,255});
        }
        ctx.lighting.end();
    }

    void onDrawHUD(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        ui::centerText("STAY ABOVE THE LAVA", ctx.screenW/2, 84, 22,
                       Color{255,150,90,255});
    }

public:
    MinigameInfo info() const override {
        return MinigameInfo{
            "Floor Is Lava",
            "the platforms are sinking",
            "jump between platforms  -  don't touch the lava",
            WinKind::LastStanding,
        };
    }

private:
    static constexpr float kLavaRise = 0.085f;
    float lava_ = -2.0f;
    std::vector<Plat> plats_;
};

} // namespace

REGISTER_MINIGAME(FloorIsLava);
