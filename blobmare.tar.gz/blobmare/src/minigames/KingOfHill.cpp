// =============================================================================
//  Minigame: King of the Hill
//  A glowing zone sits at the centre of the arena. Hold it to bank score.
//  If both blobs are inside, nobody scores — so you must shove them out.
//  Most score when the clock ends wins.
// =============================================================================
#include "game/MinigameBase.h"
#include "game/MinigameRegistry.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "render/Prims.h"
#include "raymath.h"
#include <cmath>
#include <vector>

namespace {

class KingOfHill : public MinigameBase {
protected:
    void onSetup(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)ctx;
        score_[0] = score_[1] = 0.0f;
        world().setGravity(Vector3{ 0, -28, 0 });
        world().setKillY(-12.0f);
        // A raised circular hill: an AABB stack approximating a plateau plus a
        // surrounding ring floor.
        world().addBox(phys::makeBox(Vector3{0,-0.4f,0},
                                     Vector3{ 9.0f, 0.4f, 9.0f }));   // floor
        world().addBox(phys::makeBox(Vector3{0, 0.5f,0},
                                     Vector3{ 3.2f, 0.5f, 3.2f }));   // hill
        for (int s = -1; s <= 1; s += 2) {
            world().addBox(phys::makeBox(Vector3{ s*9.0f, 2.0f, 0 },
                                         Vector3{ 0.5f, 2.0f, 9.0f }));
            world().addBox(phys::makeBox(Vector3{ 0, 2.0f, s*9.0f },
                                         Vector3{ 9.0f, 2.0f, 0.5f }));
        }
        for (size_t i = 0; i < blobs.size(); ++i)
            blobs[i]->respawn(Vector3{ (i==0?-6.0f:6.0f), 1.4f, 0.0f });
    }

    bool onHill(Blob* b) const {
        Vector3 p = b->position();
        float horiz = std::sqrt(p.x*p.x + p.z*p.z);
        return horiz < kHillRadius && p.y < 2.2f && p.y > 0.6f;
    }

    void onUpdate(GameContext& ctx, std::vector<Blob*>& blobs,
                  float dt) override {
        for (Blob* b : blobs) b->integrate(world(), dt);
        blobBump(ctx, blobs, 0.95f);     // bouncy: contesting the hill matters

        bool on0 = blobs.size() > 0 && onHill(blobs[0]);
        bool on1 = blobs.size() > 1 && onHill(blobs[1]);
        kingId_ = -1;
        if (on0 && !on1) { score_[0] += dt; kingId_ = 0; }
        if (on1 && !on0) { score_[1] += dt; kingId_ = 1; }

        for (Blob* b : blobs)
            b->setEmote(onHill(b) ? Emote::Determined : Emote::Neutral);

        // Sparkle while a blob is king.
        sparkTimer_ -= dt;
        if (kingId_ >= 0 && sparkTimer_ <= 0.0f) {
            sparkTimer_ = 0.12f;
            Vector3 p = blobs[kingId_]->position();
            ctx.particles.ring(Vector3{p.x,0.6f,p.z}, kHillRadius, 10,
                               ctx.config.playerColor[kingId_], 1.0f);
        }

        if (elapsed() >= kTime)
            resolveByScore((int)score_[0], (int)score_[1]);
    }

    void onDraw3D(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        ctx.lighting.begin();
        prims::platform(Vector3{0,0,0}, 18, 18, 0.8f,
                        Color{44,48,66,255}, Color{90,100,140,255});
        // The hill plateau, tinted by who holds it.
        Color hillTop = Color{70,66,86,255};
        if (kingId_ >= 0) {
            Color pc = ctx.config.playerColor[kingId_];
            hillTop = Color{ (unsigned char)(70 + pc.r/4),
                             (unsigned char)(66 + pc.g/4),
                             (unsigned char)(86 + pc.b/4), 255 };
        }
        prims::platform(Vector3{0,1.0f,0}, 6.4f, 6.4f, 1.0f,
                        hillTop, Color{160,150,190,255});
        for (int s = -1; s <= 1; s += 2) {
            prims::wall(Vector3{s*9.0f,0,-9}, Vector3{s*9.0f,0,9},
                        4.0f, 0.5f, Color{40,44,60,255});
            prims::wall(Vector3{-9,0,s*9.0f}, Vector3{9,0,s*9.0f},
                        4.0f, 0.5f, Color{40,44,60,255});
        }
        ctx.lighting.end();
        // Glowing zone marker.
        float glow = 0.6f + 0.4f*std::sin((float)GetTime()*3.0f);
        DrawCylinderWires(Vector3{0,1.05f,0}, kHillRadius, kHillRadius,
                          0.02f, 32, Color{255,210,120,(unsigned char)(255*glow)});
    }

    void onDrawHUD(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        int cx = ctx.screenW/2;
        for (int i = 0; i < 2; ++i) {
            int x = (i==0) ? cx-200 : cx+120;
            DrawText(TextFormat("%d", (int)score_[i]), x, 96, 52,
                     ctx.config.playerColor[i]);
        }
        ui::centerText("HOLD THE HILL", cx, 110, 22, ui::inkDim());
    }

public:
    float timeLimit() const override { return kTime; }
    MinigameInfo info() const override {
        return MinigameInfo{
            "King of the Hill",
            "own the glowing zone",
            "stand in the zone alone to score",
            WinKind::HighScore,
        };
    }

private:
    static constexpr float kTime = 28.0f;
    static constexpr float kHillRadius = 3.0f;
    float score_[2] = { 0.0f, 0.0f };
    int   kingId_ = -1;
    float sparkTimer_ = 0.0f;
};

} // namespace

REGISTER_MINIGAME(KingOfHill);
