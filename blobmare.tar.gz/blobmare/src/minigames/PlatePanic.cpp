// =============================================================================
//  Minigame: Plate Panic
//  Floor tiles light up at random. Stand on a lit tile to claim it for a
//  point, and it goes dark. Whoever has banked the most when time runs out
//  wins. A frantic scramble for territory.
// =============================================================================
#include "game/MinigameBase.h"
#include "game/MinigameRegistry.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "render/Prims.h"
#include "raymath.h"
#include <cmath>
#include <vector>

namespace {

constexpr int kGrid = 5;          // 5x5 tile floor
constexpr float kTile = 2.4f;

class PlatePanic : public MinigameBase {
protected:
    struct Tile { bool lit = false; float litTimer = 0.0f; int claimedBy = -1; };

    void onSetup(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)ctx;
        score_[0] = score_[1] = 0;
        world().setGravity(Vector3{ 0, -28, 0 });
        world().setGround(0.0f);
        world().setKillY(-12.0f);
        float half = kGrid * kTile * 0.5f;
        for (int s = -1; s <= 1; s += 2) {
            world().addBox(phys::makeBox(Vector3{ s*half, 2.0f, 0 },
                                         Vector3{ 0.5f, 2.0f, half }));
            world().addBox(phys::makeBox(Vector3{ 0, 2.0f, s*half },
                                         Vector3{ half, 2.0f, 0.5f }));
        }
        for (auto& t : tiles_) t = Tile{};
        litCount_ = 0;
        spawnTimer_ = 0.5f;
        for (size_t i = 0; i < blobs.size(); ++i)
            blobs[i]->respawn(Vector3{ (i==0?-3.0f:3.0f), 1.2f, 0.0f });
    }

    Vector3 tileCenter(int ix, int iz) const {
        float half = kGrid * kTile * 0.5f;
        return Vector3{ (ix + 0.5f)*kTile - half, 0.0f,
                        (iz + 0.5f)*kTile - half };
    }

    void onUpdate(GameContext& ctx, std::vector<Blob*>& blobs,
                  float dt) override {
        for (Blob* b : blobs) b->integrate(world(), dt);
        blobBump(ctx, blobs, 0.6f);

        // Light up new tiles over time, keeping a handful lit.
        spawnTimer_ -= dt;
        if (spawnTimer_ <= 0.0f && litCount_ < 6) {
            spawnTimer_ = 0.55f;
            for (int tries = 0; tries < 12; ++tries) {
                int i = GetRandomValue(0, kGrid*kGrid - 1);
                if (!tiles_[i].lit) {
                    tiles_[i].lit = true;
                    tiles_[i].litTimer = 4.0f;
                    tiles_[i].claimedBy = -1;
                    ++litCount_;
                    break;
                }
            }
        }

        // Lit tiles expire if unclaimed.
        for (int i = 0; i < kGrid*kGrid; ++i) {
            if (!tiles_[i].lit) continue;
            tiles_[i].litTimer -= dt;
            if (tiles_[i].litTimer <= 0.0f) {
                tiles_[i].lit = false;
                --litCount_;
            }
        }

        // Claim by standing on a lit tile.
        for (Blob* b : blobs) {
            if (!b->grounded()) continue;
            Vector3 p = b->position();
            float half = kGrid * kTile * 0.5f;
            int ix = (int)((p.x + half) / kTile);
            int iz = (int)((p.z + half) / kTile);
            if (ix < 0 || ix >= kGrid || iz < 0 || iz >= kGrid) continue;
            Tile& t = tiles_[iz*kGrid + ix];
            if (t.lit) {
                t.lit = false;
                --litCount_;
                score_[b->id()]++;
                ctx.particles.burst(tileCenter(ix, iz), 18,
                                    ctx.config.playerColor[b->id()], 6);
                ctx.audio.play(Sfx::Coin, 0.8f, 0.1f);
            }
        }

        if (elapsed() >= kTime)
            resolveByScore(score_[0], score_[1]);
    }

    void onDraw3D(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        ctx.lighting.begin();
        for (int iz = 0; iz < kGrid; ++iz) {
            for (int ix = 0; ix < kGrid; ++ix) {
                const Tile& t = tiles_[iz*kGrid + ix];
                Vector3 c = tileCenter(ix, iz);
                Color col = ((ix+iz)&1) ? Color{44,48,66,255}
                                        : Color{38,42,58,255};
                if (t.lit) {
                    float pulse = 0.6f + 0.4f*std::sin((float)GetTime()*6.0f);
                    float urgency = 1.0f - t.litTimer/4.0f;
                    col = Color{ (unsigned char)(120 + 120*pulse),
                                 (unsigned char)(170 - 80*urgency),
                                 (unsigned char)(90*pulse), 255 };
                }
                prims::platform(Vector3{c.x, 0.0f, c.z},
                                kTile*0.96f, kTile*0.96f, 0.5f, col,
                                Color{90,100,140,255});
            }
        }
        float half = kGrid*kTile*0.5f;
        for (int s = -1; s <= 1; s += 2) {
            prims::wall(Vector3{s*half,0,-half}, Vector3{s*half,0,half},
                        3.5f, 0.5f, Color{40,44,60,255});
            prims::wall(Vector3{-half,0,s*half}, Vector3{half,0,s*half},
                        3.5f, 0.5f, Color{40,44,60,255});
        }
        ctx.lighting.end();
    }

    void onDrawHUD(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        int cx = ctx.screenW/2;
        for (int i = 0; i < 2; ++i) {
            int x = (i==0) ? cx-200 : cx+120;
            DrawText(TextFormat("%d", score_[i]), x, 96, 52,
                     ctx.config.playerColor[i]);
        }
        ui::centerText("CLAIM LIT TILES", cx, 110, 22, ui::inkDim());
    }

public:
    float timeLimit() const override { return kTime; }
    MinigameInfo info() const override {
        return MinigameInfo{
            "Plate Panic",
            "claim the glowing tiles",
            "stand on a lit tile before it fades",
            WinKind::HighScore,
        };
    }

private:
    static constexpr float kTime = 30.0f;
    Tile tiles_[kGrid*kGrid];
    int  litCount_ = 0;
    int  score_[2] = { 0, 0 };
    float spawnTimer_ = 0.5f;
};

} // namespace

REGISTER_MINIGAME(PlatePanic);
