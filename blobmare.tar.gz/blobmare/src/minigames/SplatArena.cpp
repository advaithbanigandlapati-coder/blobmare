// =============================================================================
//  Minigame: Splat Arena — "Paint the Floor"
// =============================================================================
//
//  A flat arena of grid tiles. Each blob continuously paints the tile it is
//  over in its own colour; dashing paints a wider 3x3 splat. Tiles can be
//  overpainted by the opponent, so it is a constant territory tug-of-war.
//  A central paint-bomb pickup splatters a big radius in the grabber's colour.
//  Most floor area in your colour when the timer ends wins.
//
//  This is the only minigame with PERSISTENT STATE that accumulates over the
//  whole round — every other game is instantaneous. That makes it feel
//  genuinely different: positioning and coverage, not reflexes or knockback.
//
#include "game/MinigameBase.h"
#include "game/MinigameRegistry.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "render/Prims.h"
#include "raymath.h"
#include <cmath>
#include <vector>

namespace {

constexpr int   kGrid = 14;          // 14x14 painted tiles
constexpr float kTile = 1.15f;
constexpr float kTime = 32.0f;

class SplatArena : public MinigameBase {
protected:
    void onSetup(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)ctx;
        world().setGravity(Vector3{ 0, -28, 0 });
        world().setGround(0.0f);
        world().setKillY(-12.0f);

        float half = kGrid * kTile * 0.5f;
        for (int s = -1; s <= 1; s += 2) {
            world().addBox(phys::makeBox(Vector3{ s*half, 2.0f, 0 },
                                         Vector3{ 0.5f, 2.0f, half }));
            world().addBox(phys::makeBox(Vector3{ 0, 2.0f, s*half },
                                         Vector3{ half, 2.0f, 0.5f }));
        }
        // 0 = unpainted, 1 = player 0, 2 = player 1.
        for (auto& t : tiles_) t = 0;

        blobs[0]->respawn(Vector3{-half*0.6f, 1.2f, 0});
        blobs[1]->respawn(Vector3{ half*0.6f, 1.2f, 0});

        bombActive_ = true;
        bombTimer_ = 6.0f;
        bombPos_ = Vector3{0, 0.8f, 0};
    }

    void paintTile(int ix, int iz, int owner) {
        if (ix < 0 || ix >= kGrid || iz < 0 || iz >= kGrid) return;
        tiles_[iz*kGrid + ix] = (uint8_t)owner;
    }

    Vector3 tileCenter(int ix, int iz) const {
        float half = kGrid * kTile * 0.5f;
        return Vector3{ (ix+0.5f)*kTile - half, 0.0f, (iz+0.5f)*kTile - half };
    }

    void onUpdate(GameContext& ctx, std::vector<Blob*>& blobs,
                  float dt) override {
        for (Blob* b : blobs) b->integrate(world(), dt);
        blobBump(ctx, blobs, 0.55f);

        float half = kGrid * kTile * 0.5f;

        // --- Painting -----------------------------------------------------
        for (Blob* b : blobs) {
            int owner = b->id() + 1;
            Vector3 p = b->position();
            int cx = (int)((p.x + half) / kTile);
            int cz = (int)((p.z + half) / kTile);
            bool dashing = b->isDashing();
            int r = dashing ? 1 : 0;     // dash = 3x3, walk = single tile
            for (int dz = -r; dz <= r; ++dz)
                for (int dx = -r; dx <= r; ++dx)
                    paintTile(cx+dx, cz+dz, owner);
            // A little paint spray under a dashing blob for juice.
            if (dashing && std::fmod(elapsed(), 0.08f) < dt) {
                ctx.particles.splat(Vector3{p.x, 0.12f, p.z},
                                    ctx.config.playerColor[b->id()], 0.6f);
            }
        }

        // --- Paint bomb ---------------------------------------------------
        if (bombActive_) {
            for (Blob* b : blobs) {
                if (Vector3Distance(b->position(), bombPos_)
                        < b->radius() + 0.6f) {
                    // Splatter a radius in the grabber's colour.
                    int owner = b->id() + 1;
                    int bcx, bcz;
                    bcx = (int)((bombPos_.x + half) / kTile);
                    bcz = (int)((bombPos_.z + half) / kTile);
                    const int R = 3;
                    for (int dz = -R; dz <= R; ++dz)
                        for (int dx = -R; dx <= R; ++dx)
                            if (dx*dx + dz*dz <= R*R)
                                paintTile(bcx+dx, bcz+dz, owner);
                    ctx.particles.burst(bombPos_, 50,
                        ctx.config.playerColor[b->id()], 9, 1.4f);
                    ctx.audio.play(Sfx::Powerup, 0.9f);
                    ctx.shake.add(0.4f);
                    bombActive_ = false;
                    bombTimer_ = 7.0f;     // respawns later
                    break;
                }
            }
        } else {
            bombTimer_ -= dt;
            if (bombTimer_ <= 0.0f) {
                bombActive_ = true;
                // Respawn at a random spot.
                bombPos_ = Vector3{
                    (float)GetRandomValue(-50,50)/10.0f, 0.8f,
                    (float)GetRandomValue(-50,50)/10.0f };
            }
        }

        // --- Resolution ---------------------------------------------------
        if (elapsed() >= kTime) {
            int c0 = 0, c1 = 0;
            for (auto t : tiles_) {
                if (t == 1) ++c0;
                else if (t == 2) ++c1;
            }
            resolveByScore(c0, c1);
        }
    }

    void onDraw3D(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        ctx.lighting.begin();
        for (int iz = 0; iz < kGrid; ++iz) {
            for (int ix = 0; ix < kGrid; ++ix) {
                uint8_t t = tiles_[iz*kGrid + ix];
                Color c;
                if (t == 1)      c = ctx.config.playerColor[0];
                else if (t == 2) c = ctx.config.playerColor[1];
                else c = ((ix+iz)&1) ? Color{40,42,56,255}
                                     : Color{34,36,48,255};
                if (t != 0) {
                    // Slightly darken painted tiles so blobs read on top.
                    c.r = (unsigned char)(c.r*0.8f);
                    c.g = (unsigned char)(c.g*0.8f);
                    c.b = (unsigned char)(c.b*0.8f);
                }
                Vector3 ctr = tileCenter(ix, iz);
                prims::platform(Vector3{ctr.x, 0.0f, ctr.z},
                                kTile*0.98f, kTile*0.98f, 0.4f, c,
                                Color{70,74,96,255});
            }
        }
        float half = kGrid*kTile*0.5f;
        for (int s = -1; s <= 1; s += 2) {
            prims::wall(Vector3{s*half,0,-half}, Vector3{s*half,0,half},
                        3.5f, 0.5f, Color{40,44,60,255});
            prims::wall(Vector3{-half,0,s*half}, Vector3{half,0,s*half},
                        3.5f, 0.5f, Color{40,44,60,255});
        }
        ctx.lighting.end();

        if (bombActive_)
            prims::collectible(bombPos_, 0.5f, Color{255,255,255,255},
                               (float)GetTime());
    }

    void onDrawHUD(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        int cx = ctx.screenW/2;
        // Live coverage percentages.
        int c0 = 0, c1 = 0, total = kGrid*kGrid;
        for (auto t : tiles_) { if (t==1) ++c0; else if (t==2) ++c1; }
        float p0 = (float)c0/total, p1 = (float)c1/total;

        // A split coverage bar.
        Rectangle bar{ cx-200.0f, 96.0f, 400.0f, 26.0f };
        DrawRectangleRounded(bar, 0.4f, 6, Color{0,0,0,150});
        Rectangle l = bar; l.width = bar.width * p0;
        DrawRectangleRounded(l, 0.4f, 6, ctx.config.playerColor[0]);
        Rectangle r = bar;
        r.width = bar.width * p1;
        r.x = bar.x + bar.width - r.width;
        DrawRectangleRounded(r, 0.4f, 6, ctx.config.playerColor[1]);

        DrawText(TextFormat("%d%%", (int)(p0*100)), (int)bar.x, 126, 22,
                 ctx.config.playerColor[0]);
        const char* rp = TextFormat("%d%%", (int)(p1*100));
        DrawText(rp, (int)(bar.x+bar.width) - MeasureText(rp,22), 126, 22,
                 ctx.config.playerColor[1]);
        ui::centerText("PAINT THE FLOOR", cx, 126, 20, ui::inkDim());
    }

public:
    float timeLimit() const override { return kTime; }
    MinigameInfo info() const override {
        return MinigameInfo{
            "Splat Arena",
            "paint more floor than your rival",
            "move to paint  -  dash for a wide splat  -  grab the bomb",
            WinKind::HighScore,
        };
    }

private:
    uint8_t tiles_[kGrid*kGrid] = {0};
    bool    bombActive_ = true;
    float   bombTimer_ = 6.0f;
    Vector3 bombPos_{0,0.8f,0};
};

} // namespace

REGISTER_MINIGAME(SplatArena);
