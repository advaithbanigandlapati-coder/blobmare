// =============================================================================
//  Minigame: Sumo Smash
//  A circular platform over the void. Bump your opponent off the edge. The
//  platform slowly shrinks so stalling is punished. Last blob standing wins.
// =============================================================================
#include "game/MinigameBase.h"
#include "game/MinigameRegistry.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "render/Prims.h"
#include "raymath.h"
#include <cmath>

namespace {

class SumoSmash : public MinigameBase {
protected:
    void onSetup(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)ctx;
        radius_ = kStartRadius;
        world().setGravity(Vector3{ 0, -30, 0 });
        world().setKillY(-14.0f);
        // No world boxes — the platform is a custom circular constraint so the
        // edge is perfectly round.
        for (size_t i = 0; i < blobs.size(); ++i) {
            float a = (i == 0) ? PI : 0.0f;
            blobs[i]->respawn(Vector3{ std::cos(a) * 2.4f, 1.2f,
                                       std::sin(a) * 2.4f });
        }
    }

    void onUpdate(GameContext& ctx, std::vector<Blob*>& blobs,
                  float dt) override {
        // Shrink the ring while in play.
        if (elapsed() > 3.0f) {
            radius_ -= kShrinkRate * dt;
            if (radius_ < kMinRadius) radius_ = kMinRadius;
        }

        for (Blob* b : blobs) {
            b->integrate(world(), dt);
            if (!b->alive()) continue;

            Vector3 p = b->position();
            float platTop = 1.0f;
            // Keep the blob resting on the disc surface (no world ground).
            float foot = p.y - b->radius();
            float horiz = std::sqrt(p.x*p.x + p.z*p.z);
            if (horiz < radius_ && foot < platTop && b->velocity().y <= 0.1f) {
                p.y = platTop + b->radius();
                b->setPosition(p);
                Vector3 v = b->velocity();
                if (v.y < 0.0f) v.y = 0.0f;
                b->setVelocity(v);
            }
            // Fell past the platform plane outside the ring -> doomed; gravity
            // already pulls them down. Mark a scared face near the edge.
            if (horiz > radius_ - 0.6f && b->alive())
                b->setEmote(Emote::Scared);
            else if (b->alive())
                b->setEmote(Emote::Determined);

            if (p.y < world().killY() + 8.0f && p.y > world().killY() &&
                !splashed_[b->id()]) {
                splashed_[b->id()] = true;
                ctx.audio.play(Sfx::Whoosh, 0.7f);
            }
        }

        blobBump(ctx, blobs, 0.95f);   // bouncy sumo shoves
        resolveLastStanding(blobs);
    }

    void onDraw3D(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        ctx.lighting.begin();
        prims::disc(Vector3{0, 1.0f, 0}, radius_, 1.0f,
                    Color{120, 90, 70, 255}, Color{200, 150, 90, 255});
        ctx.lighting.end();
        // Edge warning ring.
        DrawCylinderWires(Vector3{0, 1.02f, 0}, radius_ - 0.5f, radius_ - 0.5f,
                          0.02f, 40, Color{255, 120, 80, 160});
        // Void hint: a few faint rings below.
        for (int i = 1; i <= 3; ++i)
            DrawCylinderWires(Vector3{0, -i*3.0f, 0}, radius_*0.6f, radius_*0.6f,
                              0.02f, 24, Color{60,40,60,90});
    }

    void onDrawHUD(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        ui::centerText("SHOVE THEM OFF", ctx.screenW/2, 84, 22, ui::inkDim());
    }

public:
    float timeLimit() const override { return 0.0f; }
    MinigameInfo info() const override {
        return MinigameInfo{
            "Sumo Smash",
            "the ring is shrinking",
            "move to shove  -  dash for a big hit",
            WinKind::LastStanding,
        };
    }

private:
    static constexpr float kStartRadius = 5.0f;
    static constexpr float kMinRadius   = 2.0f;
    static constexpr float kShrinkRate  = 0.22f;
    float radius_ = kStartRadius;
    bool  splashed_[2] = { false, false };
};

} // namespace

REGISTER_MINIGAME(SumoSmash);
