// =============================================================================
//  Minigame: Hot Potato
//  A lit bomb is stuck to one blob. Touch your opponent to pass it. When the
//  fuse burns out, whoever holds the bomb is eliminated. Best of survival.
// =============================================================================
#include "game/MinigameBase.h"
#include "game/MinigameRegistry.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "render/Prims.h"
#include "raymath.h"
#include <cmath>
#include <vector>

namespace {

class HotPotato : public MinigameBase {
protected:
    void onSetup(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)ctx;
        world().setGravity(Vector3{ 0, -28, 0 });
        world().setGround(0.0f);
        world().setKillY(-12.0f);
        for (int s = -1; s <= 1; s += 2) {
            world().addBox(phys::makeBox(Vector3{ s*8.0f, 2.0f, 0 },
                                         Vector3{ 0.5f, 2.0f, 8.0f }));
            world().addBox(phys::makeBox(Vector3{ 0, 2.0f, s*8.0f },
                                         Vector3{ 8.0f, 2.0f, 0.5f }));
        }
        for (size_t i = 0; i < blobs.size(); ++i)
            blobs[i]->respawn(Vector3{ (i==0?-4.0f:4.0f), 1.2f, 0.0f });
        holder_ = GetRandomValue(0, 1);
        fuse_   = kFuse;
        passCooldown_ = 0.0f;
    }

    void onUpdate(GameContext& ctx, std::vector<Blob*>& blobs,
                  float dt) override {
        for (Blob* b : blobs) b->integrate(world(), dt);
        blobBump(ctx, blobs, 0.8f);

        if (finished()) return;

        fuse_ -= dt;
        if (passCooldown_ > 0.0f) passCooldown_ -= dt;

        // The holder glows scared as the fuse shortens.
        for (Blob* b : blobs)
            b->setEmote(b->id() == holder_ ? Emote::Scared : Emote::Determined);

        // Contact passes the bomb (after a short grace so it doesn't ping-pong).
        if (passCooldown_ <= 0.0f && blobs.size() == 2) {
            float d = Vector3Distance(blobs[0]->position(),
                                      blobs[1]->position());
            if (d < blobs[0]->radius() + blobs[1]->radius() + 0.25f) {
                holder_ = 1 - holder_;
                passCooldown_ = 0.6f;
                ctx.audio.play(Sfx::Pop, 0.8f, 0.15f);
                ctx.shake.add(0.15f);
            }
        }

        // Tick faster as it gets close.
        float tickRate = (fuse_ < 3.0f) ? 0.25f : 0.5f;
        tickAccum_ += dt;
        if (tickAccum_ >= tickRate) {
            tickAccum_ = 0.0f;
            if (fuse_ > 0.0f) ctx.audio.play(Sfx::Tick, 0.6f);
        }

        if (fuse_ <= 0.0f) {
            // Boom.
            Blob* loser = blobs[holder_];
            loser->kill();
            ctx.particles.burst(loser->position(), 50,
                                Color{255,140,40,255}, 12, 1.4f);
            ctx.audio.play(Sfx::Hit, 1.0f);
            ctx.shake.add(0.7f);
            win(1 - holder_);
        }
    }

    void onDraw3D(GameContext& ctx, std::vector<Blob*>& blobs) override {
        ctx.lighting.begin();
        prims::platform(Vector3{0,0,0}, 16, 16, 0.6f,
                        Color{54,46,64,255}, Color{110,90,130,255});
        for (int s = -1; s <= 1; s += 2) {
            prims::wall(Vector3{s*8.0f,0,-8}, Vector3{s*8.0f,0,8},
                        4.0f, 0.5f, Color{44,38,54,255});
            prims::wall(Vector3{-8,0,s*8.0f}, Vector3{8,0,s*8.0f},
                        4.0f, 0.5f, Color{44,38,54,255});
        }
        ctx.lighting.end();

        // The bomb floats above the current holder.
        if (!finished() && holder_ < (int)blobs.size()) {
            Vector3 p = blobs[holder_]->position();
            p.y += blobs[holder_]->radius() + 0.9f
                 + std::sin((float)GetTime()*8.0f)*0.1f;
            float danger = 1.0f - (fuse_ / kFuse);
            Color bomb{ (unsigned char)(40 + 200*danger), 40, 40, 255 };
            prims::hazardSphere(p, 0.4f, bomb);
            // Fuse spark.
            DrawSphereEx(Vector3{p.x, p.y+0.5f, p.z}, 0.12f,
                         5, 5, Color{255,230,120,255});
        }
    }

    void onDrawHUD(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        int cx = ctx.screenW/2;
        Color fc = fuse_ < 3.0f ? ui::danger() : ui::accent();
        ui::centerTextShadow(TextFormat("%.1f", fuse_ > 0 ? fuse_ : 0.0f),
                             cx, 92, 44, fc);
        ui::centerText("PASS THE BOMB", cx, 138, 20, ui::inkDim());
    }

public:
    MinigameInfo info() const override {
        return MinigameInfo{
            "Hot Potato",
            "don't be holding the bomb",
            "bump your rival to pass the bomb",
            WinKind::LastStanding,
        };
    }

private:
    static constexpr float kFuse = 14.0f;
    int   holder_ = 0;
    float fuse_ = kFuse;
    float passCooldown_ = 0.0f;
    float tickAccum_ = 0.0f;
};

} // namespace

REGISTER_MINIGAME(HotPotato);
