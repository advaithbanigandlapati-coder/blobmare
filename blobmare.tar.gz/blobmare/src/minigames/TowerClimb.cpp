// =============================================================================
//  Minigame: Tower Climb
//  A vertical scramble. Platforms spiral upward; first blob to touch the bell
//  at the top wins. Blobs get a double jump here. Fall and you respawn on the
//  last platform you stood on.
// =============================================================================
#include "game/MinigameBase.h"
#include "game/MinigameRegistry.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "render/Prims.h"
#include "raymath.h"
#include <cmath>
#include <vector>

namespace {

class TowerClimb : public MinigameBase {
protected:
    struct Ledge { Vector3 pos; float sx, sz; };

    void onSetup(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)ctx;
        world().setGravity(Vector3{ 0, -26, 0 });
        world().setKillY(-8.0f);
        ledges_.clear();

        // Base.
        ledges_.push_back(Ledge{ Vector3{0,0,0}, 6.0f, 6.0f });
        // Spiral of ledges climbing in Y.
        int rungs = 11;
        for (int i = 1; i <= rungs; ++i) {
            float ang = i * 2.2f;
            float r   = 3.2f;
            Ledge l;
            l.pos = Vector3{ std::cos(ang)*r, i * 1.85f, std::sin(ang)*r };
            l.sx = 2.6f; l.sz = 2.6f;
            ledges_.push_back(l);
        }
        topY_ = ledges_.back().pos.y + 1.6f;
        bellPos_ = Vector3{ ledges_.back().pos.x, topY_,
                            ledges_.back().pos.z };

        for (auto& l : ledges_) {
            world().addBox(phys::makeBox(
                Vector3{ l.pos.x, l.pos.y - 0.35f, l.pos.z },
                Vector3{ l.sx*0.5f, 0.35f, l.sz*0.5f }));
        }

        for (size_t i = 0; i < blobs.size(); ++i) {
            spawn_[i] = Vector3{ (i==0?-1.5f:1.5f), 1.2f, 0.0f };
            blobs[i]->respawn(spawn_[i]);
            blobs[i]->tuning().maxJumps = 2;       // double jump for climbing
        }
    }

    void onUpdate(GameContext& ctx, std::vector<Blob*>& blobs,
                  float dt) override {
        for (Blob* b : blobs) {
            b->integrate(world(), dt);
            int id = b->id();
            // Update respawn to the ledge under the blob's feet.
            if (b->grounded()) {
                spawn_[id] = Vector3{ b->position().x,
                                      b->position().y + 0.2f,
                                      b->position().z };
            }
            if (!b->alive()) {
                b->revive();
                b->respawn(spawn_[id]);
                ctx.audio.play(Sfx::Whoosh, 0.6f);
            }
            // Reached the bell?
            if (Vector3Distance(b->position(), bellPos_) < 1.2f
                    && !finished()) {
                ctx.particles.confetti(bellPos_, 80);
                ctx.audio.play(Sfx::Powerup);
                win(id);
            }
        }
        blobBump(ctx, blobs, 0.7f);

        // Safety: if neither blob rings the bell in time, the highest climber
        // wins so a match can never stall.
        if (!finished() && elapsed() >= kTime) {
            float y0 = blobs[0]->position().y;
            float y1 = blobs[1]->position().y;
            if (std::fabs(y0 - y1) < 0.5f) declareDraw();
            else                          win(y0 > y1 ? 0 : 1);
        }
    }

    void onDraw3D(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        ctx.lighting.begin();
        for (size_t i = 0; i < ledges_.size(); ++i) {
            float t = (float)i / ledges_.size();
            Color top{ (unsigned char)(50 + 60*t),
                       (unsigned char)(48 + 30*t),
                       (unsigned char)(74 + 50*t), 255 };
            prims::platform(ledges_[i].pos, ledges_[i].sx, ledges_[i].sz,
                            0.7f, top, Color{150,140,200,255});
        }
        ctx.lighting.end();
        // The goal bell.
        prims::collectible(bellPos_, 0.6f, Color{255,210,90,255}, 0.0f);
        DrawCylinderWires(bellPos_, 1.0f, 1.0f, 0.02f, 20,
                          Color{255,220,120,160});
    }

    void onDrawHUD(GameContext& ctx, std::vector<Blob*>& blobs) override {
        int cx = ctx.screenW/2;
        ui::centerText("CLIMB TO THE BELL", cx, 84, 22, ui::inkDim());
        for (size_t i = 0; i < blobs.size(); ++i) {
            float prog = blobs[i]->position().y / topY_;
            Rectangle r{ (i==0)?40.0f:ctx.screenW-240.0f, 110.0f, 200.0f, 14.0f };
            ui::bar(r, prog, ctx.config.playerColor[i], Color{0,0,0,140});
        }
    }

public:
    float timeLimit() const override { return kTime; }
    MinigameInfo info() const override {
        return MinigameInfo{
            "Tower Climb",
            "race to the top",
            "double-jump up the spiral  -  ring the bell",
            WinKind::FirstToGoal,
        };
    }

private:
    static constexpr float kTime = 45.0f;
    std::vector<Ledge> ledges_;
    Vector3 spawn_[2]{};
    Vector3 bellPos_{};
    float   topY_ = 20.0f;
};

} // namespace

REGISTER_MINIGAME(TowerClimb);
