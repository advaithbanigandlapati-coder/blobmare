// =============================================================================
//  Minigame: Meteor Dodge
//  Meteors rain down on a flat arena, telegraphed by shadows. Get hit and
//  you're out. Last blob standing wins. The longer it runs, the heavier the
//  storm — so it always resolves.
// =============================================================================
#include "game/MinigameBase.h"
#include "game/MinigameRegistry.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "render/Prims.h"
#include "raymath.h"
#include <cmath>
#include <vector>
#include <algorithm>

namespace {

class MeteorDodge : public MinigameBase {
protected:
    struct Meteor {
        Vector3 target;     // ground impact point
        float   y;          // current height
        float   warn;       // seconds of warning shadow remaining before drop
        bool    dropping = false;
        bool    done = false;
    };

    void onSetup(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)ctx;
        world().setGravity(Vector3{ 0, -28, 0 });
        world().setGround(0.0f);
        world().setKillY(-12.0f);
        for (int s = -1; s <= 1; s += 2) {
            world().addBox(phys::makeBox(Vector3{ s*8.0f, 2.0f, 0 },
                                         Vector3{ 0.5f, 2.0f, 8.0f }));
            world().addBox(phys::makeBox(Vector3{ 0, 2.0f, s*8.0f },
                                         Vector3{ 8.0f, 2.0f, 0.5f }));
        }
        meteors_.clear();
        spawnTimer_ = 1.0f;
        for (size_t i = 0; i < blobs.size(); ++i)
            blobs[i]->respawn(Vector3{ (i==0?-3.0f:3.0f), 1.2f, 0.0f });
    }

    void spawnMeteor() {
        Meteor m;
        m.target = Vector3{ (float)GetRandomValue(-70,70)/10.0f, 0.0f,
                            (float)GetRandomValue(-70,70)/10.0f };
        m.y = 16.0f;
        m.warn = 1.1f;
        meteors_.push_back(m);
    }

    void onUpdate(GameContext& ctx, std::vector<Blob*>& blobs,
                  float dt) override {
        for (Blob* b : blobs) b->integrate(world(), dt);
        blobBump(ctx, blobs, 0.6f);

        // Storm intensifies over time.
        float interval = std::max(0.28f, 1.05f - elapsed() * 0.045f);
        spawnTimer_ -= dt;
        if (spawnTimer_ <= 0.0f) {
            spawnTimer_ = interval;
            spawnMeteor();
            if (elapsed() > 14.0f) spawnMeteor();  // double up late
        }

        for (auto& m : meteors_) {
            if (m.done) continue;
            if (!m.dropping) {
                m.warn -= dt;
                if (m.warn <= 0.0f) m.dropping = true;
            } else {
                m.y -= kFallSpeed * dt;
                if (m.y <= 0.6f) {
                    m.done = true;
                    ctx.particles.burst(Vector3{m.target.x,0.4f,m.target.z},
                                        30, Color{255,140,60,255}, 9, 1.3f);
                    ctx.audio.play(Sfx::Hit, 0.8f, 0.15f);
                    ctx.shake.add(0.35f);
                    // Splash damage radius.
                    for (Blob* b : blobs) {
                        if (!b->alive()) continue;
                        if (Vector3Distance(
                                Vector3{b->position().x,0,b->position().z},
                                Vector3{m.target.x,0,m.target.z})
                            < kBlastRadius + b->radius()) {
                            b->kill();
                            ctx.particles.burst(b->position(), 36,
                                Color{255,90,70,255}, 11);
                        }
                    }
                }
            }
        }
        // Clean finished meteors occasionally.
        if (meteors_.size() > 60) {
            meteors_.erase(
                std::remove_if(meteors_.begin(), meteors_.end(),
                               [](const Meteor& m){ return m.done; }),
                meteors_.end());
        }

        resolveLastStanding(blobs);
    }

    void onDraw3D(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        ctx.lighting.begin();
        prims::platform(Vector3{0,0,0}, 16, 16, 0.6f,
                        Color{50,44,58,255}, Color{110,90,120,255});
        for (int s = -1; s <= 1; s += 2) {
            prims::wall(Vector3{s*8.0f,0,-8}, Vector3{s*8.0f,0,8},
                        3.5f, 0.5f, Color{42,38,52,255});
            prims::wall(Vector3{-8,0,s*8.0f}, Vector3{8,0,s*8.0f},
                        3.5f, 0.5f, Color{42,38,52,255});
        }
        ctx.lighting.end();

        for (auto& m : meteors_) {
            if (m.done) continue;
            // Warning shadow on the ground.
            float warnT = m.dropping ? 1.0f : (1.0f - m.warn/1.1f);
            unsigned char a = (unsigned char)(80 + 120*warnT);
            DrawCylinder(Vector3{m.target.x, 0.05f, m.target.z},
                         kBlastRadius, kBlastRadius, 0.03f, 24,
                         Color{255,80,60,a});
            DrawCylinderWires(Vector3{m.target.x, 0.06f, m.target.z},
                              kBlastRadius, kBlastRadius, 0.03f, 24,
                              Color{255,140,90,200});
            if (m.dropping) {
                prims::hazardSphere(Vector3{m.target.x, m.y, m.target.z},
                                    0.6f, Color{255,120,50,255});
            }
        }
    }

    void onDrawHUD(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        ui::centerText("DODGE THE METEORS", ctx.screenW/2, 84, 22,
                       Color{255,150,90,255});
    }

public:
    MinigameInfo info() const override {
        return MinigameInfo{
            "Meteor Dodge",
            "the sky is falling",
            "watch the red shadows  -  keep moving",
            WinKind::LastStanding,
        };
    }

private:
    static constexpr float kFallSpeed   = 22.0f;
    static constexpr float kBlastRadius = 1.5f;
    std::vector<Meteor> meteors_;
    float spawnTimer_ = 1.0f;
};

} // namespace

REGISTER_MINIGAME(MeteorDodge);
