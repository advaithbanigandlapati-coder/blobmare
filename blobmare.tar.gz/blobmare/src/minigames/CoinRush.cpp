// =============================================================================
//  Minigame: Coin Rush
//  An open arena strewn with glowing coins. Grab more than your opponent
//  before the clock runs out. Coins respawn elsewhere when taken.
// =============================================================================
#include "game/MinigameBase.h"
#include "game/MinigameRegistry.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "render/Prims.h"
#include "raymath.h"
#include <cmath>
#include <vector>

namespace {

class CoinRush : public MinigameBase {
protected:
    struct Coin { Vector3 pos; bool active; float phase; bool gold; };

    void onSetup(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)ctx;
        score_[0] = score_[1] = 0;
        world().setGravity(Vector3{ 0, -28, 0 });
        world().setGround(0.0f);
        world().setKillY(-12.0f);
        // Arena walls.
        for (int s = -1; s <= 1; s += 2) {
            world().addBox(phys::makeBox(Vector3{ s*9.0f, 2.0f, 0 },
                                         Vector3{ 0.5f, 2.0f, 9.0f }));
            world().addBox(phys::makeBox(Vector3{ 0, 2.0f, s*9.0f },
                                         Vector3{ 9.0f, 2.0f, 0.5f }));
        }
        coins_.clear();
        for (int i = 0; i < 10; ++i) coins_.push_back(makeCoin(i));

        for (size_t i = 0; i < blobs.size(); ++i)
            blobs[i]->respawn(Vector3{ (i==0?-3.0f:3.0f), 1.2f, 0.0f });
    }

    Coin makeCoin(int i) {
        Coin c;
        c.pos = Vector3{ (float)GetRandomValue(-75,75)/10.0f, 1.0f,
                         (float)GetRandomValue(-75,75)/10.0f };
        c.active = true;
        c.phase  = i * 0.7f;
        c.gold   = (GetRandomValue(0, 5) == 0);   // ~1/6 worth 3
        return c;
    }

    void onUpdate(GameContext& ctx, std::vector<Blob*>& blobs,
                  float dt) override {
        for (Blob* b : blobs) b->integrate(world(), dt);
        blobBump(ctx, blobs, 0.5f);

        for (auto& c : coins_) {
            if (!c.active) continue;
            for (Blob* b : blobs) {
                if (Vector3Distance(b->position(), c.pos)
                        < b->radius() + 0.6f) {
                    int v = c.gold ? 3 : 1;
                    score_[b->id()] += v;
                    c.active = false;
                    ctx.particles.burst(c.pos, c.gold ? 26 : 14,
                        c.gold ? Color{255,210,90,255} : Color{255,235,150,255},
                        7);
                    ctx.audio.play(c.gold ? Sfx::Powerup : Sfx::Coin,
                                   0.8f, 0.1f);
                    // Respawn it somewhere fresh after a beat.
                    c = makeCoin(0);
                    c.pos.y = 1.0f;
                    break;
                }
            }
        }

        if (elapsed() >= kTime)
            resolveByScore(score_[0], score_[1]);
    }

    void onDraw3D(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        ctx.lighting.begin();
        prims::platform(Vector3{0,0,0}, 18, 18, 0.6f,
                        Color{46,52,74,255}, Color{90,110,150,255});
        for (int s = -1; s <= 1; s += 2) {
            prims::wall(Vector3{s*9.0f,0,-9}, Vector3{s*9.0f,0,9},
                        4.0f, 0.5f, Color{40,44,64,255});
            prims::wall(Vector3{-9,0,s*9.0f}, Vector3{9,0,s*9.0f},
                        4.0f, 0.5f, Color{40,44,64,255});
        }
        ctx.lighting.end();
        for (auto& c : coins_) {
            if (!c.active) continue;
            prims::collectible(c.pos, c.gold ? 0.42f : 0.3f,
                c.gold ? Color{255,205,80,255} : Color{255,232,140,255},
                c.phase);
        }
    }

    void onDrawHUD(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        int cx = ctx.screenW / 2;
        for (int i = 0; i < 2; ++i) {
            int x = (i==0) ? cx - 200 : cx + 120;
            DrawText(TextFormat("%d", score_[i]), x, 96, 56,
                     ctx.config.playerColor[i]);
        }
        ui::centerText("COINS", cx, 110, 22, ui::inkDim());
    }

public:
    float timeLimit() const override { return kTime; }
    MinigameInfo info() const override {
        return MinigameInfo{
            "Coin Rush",
            "grab every coin you can",
            "run over coins  -  gold coins are worth 3",
            WinKind::HighScore,
        };
    }

private:
    static constexpr float kTime = 30.0f;
    int score_[2] = { 0, 0 };
    std::vector<Coin> coins_;
};

} // namespace

REGISTER_MINIGAME(CoinRush);
