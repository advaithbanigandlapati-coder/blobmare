// =============================================================================
//  Minigame: The Hunt — "Death by AI"
// =============================================================================
//
//  A menacing AI Hunter blob roams a maze arena. The two players must survive
//  as long as possible; being caught eliminates you. Last blob alive wins; if
//  both survive the time limit it's a draw (shared survival).
//
//  THE HUNTER AI — a four-state FSM driven by sight and sound:
//
//    PATROL     wander between waypoints. Default state.
//    INVESTIGATE heard something (a player dashed/landed nearby, = loud) —
//               move to the noise's location and look around.
//    CHASE      has line-of-sight to a player — A* straight at them.
//    LUNGE      close enough — a committed burst of speed; the catch window.
//
//  Sight: a forward vision cone + line-of-sight through the NavGrid walls.
//  Sound: players emit "noise" scaled by speed; dashing/landing is loud.
//  The hunter loses a target it can't see/hear for a few seconds -> back to
//  INVESTIGATE at the last known spot, then PATROL.
//
//  Tuned to be tense but fair: the hunter is slightly slower than a sprinting
//  blob in CHASE, so a player who keeps moving and breaks line-of-sight can
//  escape — but LUNGE briefly outpaces them, so corners are dangerous.
//
#include "game/MinigameBase.h"
#include "game/MinigameRegistry.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "render/Prims.h"
#include "ai/NavGrid.h"
#include "raymath.h"
#include <cmath>
#include <vector>

namespace {

class TheHunt : public MinigameBase {
protected:
    // --- Maze layout ------------------------------------------------------
    // A hand-designed maze: 1 = wall, 0 = open. 13x13 cells, 1.5u each.
    static constexpr int kCols = 13, kRows = 13;
    static constexpr float kCell = 1.6f;

    void onSetup(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)ctx;
        world().setGravity(Vector3{ 0, -28, 0 });
        world().setGround(0.0f);
        world().setKillY(-12.0f);

        // The maze pattern. Border is solid; interior has rooms + corridors.
        static const char* maze[kRows] = {
            "1111111111111",
            "1000000000001",
            "1011101110101",
            "1010000010101",
            "1010111010101",
            "1000100000001",
            "1110101111101",
            "1000100000001",
            "1011101110101",
            "1010001010001",
            "1010111010111",
            "1000000010001",
            "1111111111111",
        };
        nav_.build(kCols, kRows, kCell);
        for (int y = 0; y < kRows; ++y)
            for (int x = 0; x < kCols; ++x)
                nav_.setBlocked(x, y, maze[y][x] == '1');

        // Build physics colliders for every wall cell.
        for (int y = 0; y < kRows; ++y) {
            for (int x = 0; x < kCols; ++x) {
                if (maze[y][x] != '1') continue;
                Vector3 c = nav_.cellToWorld(x, y);
                world().addBox(phys::makeBox(
                    Vector3{ c.x, 1.5f, c.z },
                    Vector3{ kCell*0.5f, 1.5f, kCell*0.5f }));
            }
        }

        // Spawn players in opposite open corners.
        blobs[0]->respawn(nav_.cellToWorld(1, 1)  + Vector3{0,1.2f,0});
        blobs[1]->respawn(nav_.cellToWorld(11,11) + Vector3{0,1.2f,0});

        // Hunter starts in the centre.
        hunterPos_ = nav_.cellToWorld(6, 6) + Vector3{0, 0.9f, 0};
        hunterVel_ = Vector3{0,0,0};
        hunterFacing_ = Vector3{0,0,1};
        state_ = State::Patrol;
        stateTime_ = 0.0f;
        path_.clear();
        pathIndex_ = 0;
        repathTimer_ = 0.0f;
        target_ = -1;
        lastKnown_ = hunterPos_;
        pickPatrolGoal();
        for (auto& d : caughtFx_) d = false;
    }

    // --- Patrol goal selection -------------------------------------------
    void pickPatrolGoal() {
        for (int tries = 0; tries < 30; ++tries) {
            int cx = GetRandomValue(1, kCols-2);
            int cy = GetRandomValue(1, kRows-2);
            if (!nav_.blocked(cx, cy)) {
                patrolGoal_ = nav_.cellToWorld(cx, cy) + Vector3{0,0.9f,0};
                return;
            }
        }
        patrolGoal_ = hunterPos_;
    }

    // --- Sensing ----------------------------------------------------------
    // Can the hunter SEE a blob? Within range, within the vision cone, and
    // with clear line-of-sight through the maze.
    bool canSee(Blob* b) const {
        Vector3 toB = Vector3Subtract(b->position(), hunterPos_);
        toB.y = 0;
        float dist = Vector3Length(toB);
        if (dist > kSightRange) return false;
        if (dist > 0.01f) {
            Vector3 dir = Vector3Scale(toB, 1.0f/dist);
            float dot = Vector3DotProduct(dir, hunterFacing_);
            // cos(70deg) ~ 0.34 — a 140-degree cone.
            if (dot < 0.34f && dist > 1.5f) return false;
        }
        return nav_.lineOfSight(hunterPos_, b->position());
    }

    // How much noise a blob is making (0..1). Sprinting/dashing is loud.
    float noiseOf(Blob* b) const {
        float speed = Vector3Length(Vector3{b->velocity().x,0,b->velocity().z});
        float n = speed / 9.0f;
        if (b->isDashing()) n += 0.6f;
        return n > 1.0f ? 1.0f : n;
    }

    void onUpdate(GameContext& ctx, std::vector<Blob*>& blobs,
                  float dt) override {
        for (Blob* b : blobs) b->integrate(world(), dt);
        blobBump(ctx, blobs, 0.5f);

        if (finished()) return;
        stateTime_ += dt;
        repathTimer_ -= dt;

        // --- Sensing pass ------------------------------------------------
        int seen = -1;
        float bestDist = 1e30f;
        for (Blob* b : blobs) {
            if (!b->alive()) continue;
            if (canSee(b)) {
                float d = Vector3Distance(hunterPos_, b->position());
                if (d < bestDist) { bestDist = d; seen = b->id(); }
            }
        }
        // Hearing: a loud nearby blob draws the hunter even without sight.
        int heard = -1;
        float loudest = 0.35f;   // hearing threshold
        for (Blob* b : blobs) {
            if (!b->alive()) continue;
            float d = Vector3Distance(hunterPos_, b->position());
            if (d > kHearRange) continue;
            float n = noiseOf(b) * (1.0f - d / kHearRange);
            if (n > loudest) { loudest = n; heard = b->id(); }
        }

        // --- FSM transitions ---------------------------------------------
        State prev = state_;
        switch (state_) {
            case State::Patrol:
                if (seen >= 0)       { state_ = State::Chase; target_ = seen; }
                else if (heard >= 0) { state_ = State::Investigate;
                                       lastKnown_ = blobs[heard]->position(); }
                else if (Vector3Distance(hunterPos_, patrolGoal_) < 1.0f)
                    pickPatrolGoal();
                break;
            case State::Investigate:
                if (seen >= 0) { state_ = State::Chase; target_ = seen; }
                else if (heard >= 0)
                    lastKnown_ = blobs[heard]->position();
                else if (Vector3Distance(hunterPos_, lastKnown_) < 1.2f
                         || stateTime_ > 4.0f)
                    state_ = State::Patrol;
                break;
            case State::Chase:
                if (seen >= 0) {
                    target_ = seen;
                    lastKnown_ = blobs[seen]->position();
                    if (bestDist < kLungeRange)
                        state_ = State::Lunge;
                } else if (stateTime_ > kChaseMemory) {
                    // Lost them — investigate the last known spot.
                    state_ = State::Investigate;
                }
                break;
            case State::Lunge:
                if (stateTime_ > kLungeTime)
                    state_ = (seen >= 0) ? State::Chase : State::Investigate;
                break;
        }
        if (state_ != prev) {
            stateTime_ = 0.0f;
            if (state_ == State::Chase && prev != State::Lunge)
                ctx.audio.play(Sfx::Spooky, 0.6f);
            if (state_ == State::Lunge)
                ctx.audio.play(Sfx::Dash, 0.9f);
        }

        // --- Movement ----------------------------------------------------
        Vector3 goal = patrolGoal_;
        float speed = kPatrolSpeed;
        if (state_ == State::Investigate) { goal = lastKnown_; speed = kPatrolSpeed*1.15f; }
        if (state_ == State::Chase && target_ >= 0) {
            goal = blobs[target_]->position();
            speed = kChaseSpeed;
        }
        if (state_ == State::Lunge && target_ >= 0) {
            goal = blobs[target_]->position();
            speed = kLungeSpeed;
        }

        // Re-path periodically (or when the path is exhausted).
        if (repathTimer_ <= 0.0f || pathIndex_ >= (int)path_.size()) {
            repathTimer_ = (state_ == State::Chase) ? 0.25f : 0.6f;
            std::vector<Vector3> newPath;
            if (nav_.findPath(hunterPos_, goal, newPath) && newPath.size() > 1) {
                path_ = newPath;
                pathIndex_ = 1;   // [0] is the current cell
            }
        }

        // Steer toward the next waypoint.
        Vector3 steerTarget = goal;
        if (pathIndex_ < (int)path_.size()) {
            steerTarget = path_[pathIndex_];
            steerTarget.y = hunterPos_.y;
            if (Vector3Distance(Vector3{hunterPos_.x,0,hunterPos_.z},
                                Vector3{steerTarget.x,0,steerTarget.z}) < 0.5f)
                ++pathIndex_;
        }
        Vector3 dir = Vector3Subtract(steerTarget, hunterPos_);
        dir.y = 0;
        if (Vector3LengthSqr(dir) > 1e-4f) {
            dir = Vector3Normalize(dir);
            // Accelerate toward the desired velocity.
            Vector3 desired = Vector3Scale(dir, speed);
            hunterVel_.x = ease_approach(hunterVel_.x, desired.x, 8.0f, dt);
            hunterVel_.z = ease_approach(hunterVel_.z, desired.z, 8.0f, dt);
            // Face movement direction (smoothed).
            hunterFacing_ = Vector3Normalize(Vector3Lerp(
                hunterFacing_, dir, 1.0f - std::exp(-10.0f*dt)));
        }
        hunterPos_.x += hunterVel_.x * dt;
        hunterPos_.z += hunterVel_.z * dt;

        // --- Catch check -------------------------------------------------
        for (Blob* b : blobs) {
            if (!b->alive()) continue;
            float d = Vector3Distance(
                Vector3{hunterPos_.x,0,hunterPos_.z},
                Vector3{b->position().x,0,b->position().z});
            if (d < kCatchRange + b->radius()) {
                b->kill();
                if (!caughtFx_[b->id()]) {
                    caughtFx_[b->id()] = true;
                    ctx.particles.burst(b->position(), 44,
                                        Color{220,40,60,255}, 11, 1.3f);
                    ctx.audio.play(Sfx::Hit, 1.0f);
                    ctx.shake.add(0.7f);
                }
            }
        }

        // --- Resolution --------------------------------------------------
        int alive = 0, lastAlive = -1;
        for (Blob* b : blobs) if (b->alive()) { ++alive; lastAlive = b->id(); }
        if (alive == 1)      win(lastAlive);
        else if (alive == 0) declareDraw();
        else if (elapsed() >= kTime) declareDraw();   // both survived
    }

    static float ease_approach(float cur, float tgt, float k, float dt) {
        return tgt + (cur - tgt) * std::exp(-k * dt);
    }

    void onDraw3D(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        ctx.lighting.begin();
        prims::platform(Vector3{0,0,0}, kCols*kCell, kRows*kCell, 0.6f,
                        Color{34,32,44,255}, Color{70,66,86,255});
        // Maze walls.
        for (int y = 0; y < kRows; ++y) {
            for (int x = 0; x < kCols; ++x) {
                if (!nav_.blocked(x,y)) continue;
                Vector3 c = nav_.cellToWorld(x,y);
                prims::platform(Vector3{c.x, 3.0f, c.z}, kCell, kCell, 3.0f,
                                Color{48,44,62,255}, Color{86,80,108,255});
            }
        }
        ctx.lighting.end();

        // --- The Hunter ---------------------------------------------------
        // A jagged red blob with glowing eyes. Colour shifts hotter by state.
        Color body{180,40,50,255};
        if (state_ == State::Chase) body = Color{220,50,55,255};
        if (state_ == State::Lunge) body = Color{255,70,60,255};
        float pulse = 0.85f + 0.15f*std::sin((float)GetTime()*
                       (state_==State::Lunge?20.0f:6.0f));
        Vector3 hp = hunterPos_;
        DrawSphereEx(hp, 0.7f*pulse, 10, 10, body);
        DrawSphereWires(hp, 0.74f*pulse, 7, 7,
                        Color{255,120,110,180});
        // Glowing eyes on the facing side.
        Vector3 right = Vector3Normalize(
            Vector3CrossProduct(Vector3{0,1,0}, hunterFacing_));
        for (int e = -1; e <= 1; e += 2) {
            Vector3 eye = Vector3Add(hp,
                Vector3Add(Vector3Scale(hunterFacing_, 0.5f),
                           Vector3Scale(right, e*0.26f)));
            eye.y += 0.18f;
            DrawSphereEx(eye, 0.16f, 6, 6, Color{255,230,90,255});
            DrawSphereEx(eye, 0.09f, 5, 5, Color{255,255,200,255});
        }
        // A faint vision cone on the floor while hunting.
        if (state_ == State::Chase || state_ == State::Lunge) {
            Vector3 tip = Vector3Add(hp,
                Vector3Scale(hunterFacing_, kSightRange));
            tip.y = 0.08f;
            DrawCylinderWires(Vector3{hp.x,0.08f,hp.z}, 0.1f, 2.2f,
                              0.02f, 12, Color{255,80,70,90});
            (void)tip;
        }
    }

    void onDrawHUD(GameContext& ctx, std::vector<Blob*>& blobs) override {
        int cx = ctx.screenW/2;
        const char* st = "";
        Color sc = ui::inkDim();
        switch (state_) {
            case State::Patrol:      st = "the hunter prowls...";  break;
            case State::Investigate: st = "the hunter heard something"; sc = ui::accent(); break;
            case State::Chase:       st = "THE HUNTER SEES YOU";   sc = ui::danger(); break;
            case State::Lunge:       st = "RUN";                   sc = ui::danger(); break;
        }
        ui::centerText(st, cx, 84, 24, sc);
        // Survival timer + who's alive.
        float left = kTime - elapsed();
        if (left < 0) left = 0;
        ui::centerText(TextFormat("survive  -  %.0f", left), cx, 116, 20,
                       ui::inkDim());
        for (size_t i = 0; i < blobs.size(); ++i) {
            const char* tag = blobs[i]->alive() ? "ALIVE" : "CAUGHT";
            Color c = blobs[i]->alive() ? ctx.config.playerColor[i]
                                        : ui::inkDim();
            int x = (i==0) ? 40 : ctx.screenW-150;
            DrawText(tag, x, 110, 22, c);
        }
    }

public:
    float timeLimit() const override { return kTime; }
    MinigameInfo info() const override {
        return MinigameInfo{
            "The Hunt",
            "something is in the maze with you",
            "stay out of sight  -  keep quiet  -  survive",
            WinKind::Survival,
        };
    }

private:
    enum class State { Patrol, Investigate, Chase, Lunge };

    static constexpr float kTime        = 35.0f;
    static constexpr float kSightRange  = 9.0f;
    static constexpr float kHearRange   = 7.0f;
    static constexpr float kLungeRange  = 3.2f;
    static constexpr float kCatchRange  = 0.95f;
    static constexpr float kChaseMemory = 3.0f;
    static constexpr float kPatrolSpeed = 4.0f;
    static constexpr float kChaseSpeed  = 7.4f;   // < sprinting blob (8.5)
    static constexpr float kLungeSpeed  = 11.0f;  // briefly faster — danger
    static constexpr float kLungeTime   = 0.9f;

    NavGrid nav_;
    Vector3 hunterPos_{}, hunterVel_{}, hunterFacing_{0,0,1};
    State   state_ = State::Patrol;
    float   stateTime_ = 0.0f;
    Vector3 patrolGoal_{}, lastKnown_{};
    int     target_ = -1;
    std::vector<Vector3> path_;
    int     pathIndex_ = 0;
    float   repathTimer_ = 0.0f;
    bool    caughtFx_[2] = {false,false};
};

} // namespace

REGISTER_MINIGAME(TheHunt);
