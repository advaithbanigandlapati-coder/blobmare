// =============================================================================
//  Minigame: Dash Race
//  A straight obstacle track with gaps and hazard bumpers. First blob to cross
//  the finish line wins. Falling off respawns you at the last checkpoint.
// =============================================================================
#include "game/MinigameBase.h"
#include "game/MinigameRegistry.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "render/Prims.h"
#include "raymath.h"
#include <cmath>
#include <vector>

namespace {

class DashRace : public MinigameBase {
protected:
    struct Seg { Vector3 pos; float sx, sz; bool checkpoint; };

    void onSetup(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)ctx;
        world().setGravity(Vector3{ 0, -30, 0 });
        world().setKillY(-10.0f);
        segs_.clear();

        // Build a track running along +X with gaps between platforms.
        float x = 0.0f;
        for (int i = 0; i < 9; ++i) {
            Seg s;
            s.sx = (i == 0 || i == 8) ? 5.0f : 3.0f;
            s.sz = 6.0f;
            s.pos = Vector3{ x + s.sx*0.5f, 0.0f, 0.0f };
            s.checkpoint = (i % 2 == 0);
            segs_.push_back(s);
            x += s.sx + ((i < 8) ? 1.7f : 0.0f);  // gap
        }
        finishX_ = x - 2.0f;

        for (auto& s : segs_) {
            world().addBox(phys::makeBox(
                Vector3{ s.pos.x, -0.4f, s.pos.z },
                Vector3{ s.sx*0.5f, 0.4f, s.sz*0.5f }));
        }
        // Hazard bumpers on a couple of mid platforms.
        bumpers_.clear();
        bumpers_.push_back(Vector3{ segs_[3].pos.x, 0.7f, 0.0f });
        bumpers_.push_back(Vector3{ segs_[5].pos.x, 0.7f, 1.6f });
        bumpers_.push_back(Vector3{ segs_[5].pos.x, 0.7f, -1.6f });

        for (size_t i = 0; i < blobs.size(); ++i) {
            spawn_[i] = Vector3{ 2.0f, 1.2f, (i==0?-1.4f:1.4f) };
            blobs[i]->respawn(spawn_[i]);
        }
    }

    void onUpdate(GameContext& ctx, std::vector<Blob*>& blobs,
                  float dt) override {
        for (Blob* b : blobs) {
            b->integrate(world(), dt);
            int id = b->id();

            // Checkpoint capture: standing on a checkpoint segment updates
            // the respawn point.
            if (b->grounded()) {
                for (auto& s : segs_) {
                    if (!s.checkpoint) continue;
                    if (std::fabs(b->position().x - s.pos.x) < s.sx*0.5f) {
                        spawn_[id] = Vector3{ b->position().x, 1.2f,
                                              (id==0?-1.4f:1.4f) };
                    }
                }
            }
            // Hazard bumpers shove the blob backward.
            for (auto& hb : bumpers_) {
                if (Vector3Distance(b->position(), hb) < b->radius()+0.65f) {
                    Vector3 push = Vector3Subtract(b->position(), hb);
                    push.y = 0.4f;
                    b->addImpulse(Vector3Scale(Vector3Normalize(push), 9.0f));
                    ctx.audio.play(Sfx::Bounce, 0.7f, 0.1f);
                    ctx.shake.add(0.2f);
                }
            }
            // Fell off -> respawn at checkpoint.
            if (!b->alive()) {
                b->revive();
                b->respawn(spawn_[id]);
                ctx.audio.play(Sfx::Whoosh, 0.6f);
            }
            // Finish line.
            if (b->position().x >= finishX_ && !finished()) {
                ctx.particles.confetti(b->position(), 70);
                ctx.audio.play(Sfx::Win);
                win(id);
            }
        }
        blobBump(ctx, blobs, 0.6f);

        // Safety: if nobody finishes in time, the furthest blob wins so a
        // match can never stall on a race.
        if (!finished() && elapsed() >= kTime) {
            float x0 = blobs[0]->position().x;
            float x1 = blobs[1]->position().x;
            if (std::fabs(x0 - x1) < 0.5f) declareDraw();
            else                          win(x0 > x1 ? 0 : 1);
        }
    }

    void onDraw3D(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        ctx.lighting.begin();
        for (auto& s : segs_) {
            Color top = s.checkpoint ? Color{60,90,70,255} : Color{52,56,78,255};
            Color rim = s.checkpoint ? Color{120,200,140,255}
                                     : Color{100,120,160,255};
            prims::platform(s.pos, s.sx, s.sz, 0.8f, top, rim);
        }
        ctx.lighting.end();
        for (auto& hb : bumpers_)
            prims::hazardSphere(hb, 0.65f, Color{230,80,90,255});
        // Finish banner.
        prims::doorway(Vector3{ finishX_, 0, 0 }, 5.0f, 4.0f,
                       Color{120,100,60,255}, Color{255,210,90,255});
    }

    void onDrawHUD(GameContext& ctx, std::vector<Blob*>& blobs) override {
        int cx = ctx.screenW/2;
        ui::centerText("RACE TO THE GLOWING DOOR", cx, 84, 22, ui::inkDim());
        // Per-player progress bars.
        for (size_t i = 0; i < blobs.size(); ++i) {
            float prog = blobs[i]->position().x / finishX_;
            Rectangle r{ cx - 200.0f, 112.0f + i*22, 400.0f, 14.0f };
            ui::bar(r, prog, ctx.config.playerColor[i], Color{0,0,0,140});
        }
    }

public:
    float timeLimit() const override { return kTime; }
    MinigameInfo info() const override {
        return MinigameInfo{
            "Dash Race",
            "first across the line wins",
            "jump the gaps  -  dash for speed  -  dodge bumpers",
            WinKind::FirstToGoal,
        };
    }

private:
    static constexpr float kTime = 45.0f;
    std::vector<Seg> segs_;
    std::vector<Vector3> bumpers_;
    Vector3 spawn_[2]{};
    float   finishX_ = 40.0f;
};

} // namespace

REGISTER_MINIGAME(DashRace);
