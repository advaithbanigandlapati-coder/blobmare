// =============================================================================
//  Minigame: Bounce Battle
//  A small arena floored with trampolines and NO walls. Everyone bounces
//  endlessly; the goal is to bump your opponent off the edge into the void.
//  Last blob standing wins.
// =============================================================================
#include "game/MinigameBase.h"
#include "game/MinigameRegistry.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "render/Prims.h"
#include "raymath.h"
#include <cmath>
#include <vector>

namespace {

class BounceBattle : public MinigameBase {
protected:
    void onSetup(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)ctx;
        world().setGravity(Vector3{ 0, -26, 0 });
        world().setKillY(-13.0f);
        // A square trampoline pad — modelled as a thin floor box. No walls:
        // falling off the side is the whole point.
        world().addBox(phys::makeBox(Vector3{0,-0.3f,0},
                                     Vector3{ kPad, 0.3f, kPad }));
        for (size_t i = 0; i < blobs.size(); ++i) {
            blobs[i]->respawn(Vector3{ (i==0?-2.5f:2.5f), 2.0f, 0.0f });
            // Lower gravity feel + lively bounce: soften friction.
            blobs[i]->tuning().friction = 3.0f;
        }
    }

    void onUpdate(GameContext& ctx, std::vector<Blob*>& blobs,
                  float dt) override {
        for (Blob* b : blobs) {
            b->integrate(world(), dt);
            // Trampoline: on landing, launch back up.
            if (b->grounded() && b->alive()) {
                Vector3 v = b->velocity();
                v.y = kBounce;
                b->setVelocity(v);
                ctx.particles.dust(
                    Vector3{b->position().x, 0.1f, b->position().z},
                    6, Color{150,170,255,255});
                ctx.audio.play(Sfx::Bounce, 0.45f, 0.12f);
            }
        }
        // Hard, springy shoves are the core mechanic.
        blobBump(ctx, blobs, 1.05f);
        resolveLastStanding(blobs);
    }

    void onDraw3D(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        ctx.lighting.begin();
        // Trampoline pad with a springy two-tone look.
        prims::platform(Vector3{0,0,0}, kPad*2, kPad*2, 0.5f,
                        Color{70,80,140,255}, Color{140,160,255,255});
        ctx.lighting.end();
        // Bounce grid on the pad surface.
        prims::groundGrid(Vector3{0,0.06f,0}, kPad, 1.0f,
                          Color{160,180,255,120});
        // Void rings below.
        for (int i = 1; i <= 3; ++i)
            DrawCylinderWires(Vector3{0,-i*3.5f,0}, kPad*0.7f, kPad*0.7f,
                              0.02f, 24, Color{60,50,80,80});
    }

    void onDrawHUD(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        ui::centerText("BOUNCE THEM INTO THE VOID", ctx.screenW/2, 84, 22,
                       ui::inkDim());
    }

public:
    MinigameInfo info() const override {
        return MinigameInfo{
            "Bounce Battle",
            "everything is a trampoline",
            "shove and dash to launch your rival off",
            WinKind::LastStanding,
        };
    }

private:
    static constexpr float kPad    = 5.0f;
    static constexpr float kBounce = 12.5f;
};

} // namespace

REGISTER_MINIGAME(BounceBattle);
