// =============================================================================
//  Minigame: Safe Zone
//  The arena floor is dangerous except for a shifting safe patch. When the
//  alarm sounds, get inside the safe zone before the sweep — anyone outside
//  is eliminated. Survive every sweep to win; if both survive to the end it's
//  a shared win (Survival WinKind).
// =============================================================================
#include "game/MinigameBase.h"
#include "game/MinigameRegistry.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "render/Prims.h"
#include "raymath.h"
#include <cmath>
#include <vector>

namespace {

class SafeZone : public MinigameBase {
protected:
    void onSetup(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)ctx;
        world().setGravity(Vector3{ 0, -28, 0 });
        world().setGround(0.0f);
        world().setKillY(-12.0f);
        for (int s = -1; s <= 1; s += 2) {
            world().addBox(phys::makeBox(Vector3{ s*9.0f, 2.0f, 0 },
                                         Vector3{ 0.5f, 2.0f, 9.0f }));
            world().addBox(phys::makeBox(Vector3{ 0, 2.0f, s*9.0f },
                                         Vector3{ 9.0f, 2.0f, 0.5f }));
        }
        zone_ = Vector3{ 0, 0, 0 };
        nextZone_ = pickZone();
        phase_ = Phase::Calm;
        phaseTime_ = 0.0f;
        sweepNumber_ = 0;
        for (size_t i = 0; i < blobs.size(); ++i)
            blobs[i]->respawn(Vector3{ (i==0?-3.0f:3.0f), 1.2f, 0.0f });
    }

    Vector3 pickZone() const {
        return Vector3{ (float)GetRandomValue(-55,55)/10.0f, 0.0f,
                        (float)GetRandomValue(-55,55)/10.0f };
    }

    void onUpdate(GameContext& ctx, std::vector<Blob*>& blobs,
                  float dt) override {
        for (Blob* b : blobs) b->integrate(world(), dt);
        blobBump(ctx, blobs, 0.6f);
        if (finished()) return;

        phaseTime_ += dt;
        switch (phase_) {
            case Phase::Calm:
                if (phaseTime_ >= kCalmTime) {
                    phase_ = Phase::Warn;
                    phaseTime_ = 0.0f;
                    ctx.audio.play(Sfx::Spooky, 0.7f);
                }
                break;
            case Phase::Warn:
                // The next zone is shown; players must move toward it.
                if (phaseTime_ >= kWarnTime) {
                    // SWEEP: eliminate anyone outside the (new) safe zone.
                    zone_ = nextZone_;
                    phase_ = Phase::Sweep;
                    phaseTime_ = 0.0f;
                    ctx.shake.add(0.6f);
                    ctx.audio.play(Sfx::Hit, 0.9f);
                    for (Blob* b : blobs) {
                        if (!b->alive()) continue;
                        Vector3 p = b->position();
                        float d = Vector3Distance(
                            Vector3{p.x,0,p.z}, Vector3{zone_.x,0,zone_.z});
                        if (d > kZoneR - b->radius()*0.5f) {
                            b->kill();
                            ctx.particles.burst(p, 34,
                                Color{200,80,220,255}, 10);
                        } else {
                            ctx.particles.ring(Vector3{p.x,0.2f,p.z},
                                b->radius()+0.3f, 12,
                                Color{120,255,160,255}, 2.0f);
                        }
                    }
                    ++sweepNumber_;
                }
                break;
            case Phase::Sweep:
                if (phaseTime_ >= kSweepTime) {
                    phase_ = Phase::Calm;
                    phaseTime_ = 0.0f;
                    nextZone_ = pickZone();
                }
                break;
        }

        // Elimination check.
        if (resolveLastStanding(blobs)) return;

        // Survived the full set of sweeps -> Survival win for everyone alive.
        if (sweepNumber_ >= kTotalSweeps && phase_ == Phase::Calm
                && phaseTime_ > 1.0f) {
            int alive = 0, last = -1;
            for (Blob* b : blobs) if (b->alive()) { ++alive; last = b->id(); }
            if (alive >= 2)      declareDraw();   // both survived: shared win
            else if (alive == 1) win(last);
            else                 declareDraw();
        }
    }

    void onDraw3D(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        // Floor: hazardous tint that flares during the sweep.
        float danger = (phase_ == Phase::Sweep)
            ? (1.0f - phaseTime_/kSweepTime) : 0.0f;
        Color floorC{ (unsigned char)(60 + 120*danger),
                      (unsigned char)(44),
                      (unsigned char)(70 + 60*danger), 255 };
        ctx.lighting.begin();
        prims::platform(Vector3{0,0,0}, 18, 18, 0.6f, floorC,
                        Color{150,90,170,255});
        for (int s = -1; s <= 1; s += 2) {
            prims::wall(Vector3{s*9.0f,0,-9}, Vector3{s*9.0f,0,9},
                        4.0f, 0.5f, Color{50,40,62,255});
            prims::wall(Vector3{-9,0,s*9.0f}, Vector3{9,0,s*9.0f},
                        4.0f, 0.5f, Color{50,40,62,255});
        }
        ctx.lighting.end();

        // Current safe zone (solid green) and the telegraphed next one.
        auto drawZone = [](Vector3 c, float r, Color col) {
            DrawCylinder(Vector3{c.x,0.07f,c.z}, r, r, 0.04f, 36, col);
            DrawCylinderWires(Vector3{c.x,0.09f,c.z}, r, r, 0.04f, 36,
                              Color{col.r,col.g,col.b,220});
        };
        if (phase_ != Phase::Warn)
            drawZone(zone_, kZoneR, Color{60,200,110,90});
        if (phase_ == Phase::Warn) {
            float p = 0.5f + 0.5f*std::sin((float)GetTime()*8.0f);
            drawZone(nextZone_, kZoneR,
                     Color{255,210,90,(unsigned char)(60+120*p)});
        }
    }

    void onDrawHUD(GameContext& ctx, std::vector<Blob*>& blobs) override {
        (void)blobs;
        int cx = ctx.screenW/2;
        const char* msg = "STAY IN THE GREEN";
        Color c = ui::inkDim();
        if (phase_ == Phase::Warn) { msg = "GET TO THE SAFE ZONE!"; c = ui::accent(); }
        if (phase_ == Phase::Sweep){ msg = "SWEEP!";                c = ui::danger(); }
        ui::centerText(msg, cx, 84, 24, c);
        ui::centerText(TextFormat("sweep %d / %d",
                       std::min(sweepNumber_+1,kTotalSweeps), kTotalSweeps),
                       cx, 116, 18, ui::inkDim());
    }

public:
    MinigameInfo info() const override {
        return MinigameInfo{
            "Safe Zone",
            "outrun the sweep",
            "reach the glowing safe zone before each sweep",
            WinKind::Survival,
        };
    }

private:
    enum class Phase { Calm, Warn, Sweep };
    static constexpr float kCalmTime  = 3.2f;
    static constexpr float kWarnTime  = 2.4f;
    static constexpr float kSweepTime = 1.0f;
    static constexpr float kZoneR     = 2.6f;
    static constexpr int   kTotalSweeps = 6;

    Vector3 zone_{}, nextZone_{};
    Phase   phase_ = Phase::Calm;
    float   phaseTime_ = 0.0f;
    int     sweepNumber_ = 0;
};

} // namespace

REGISTER_MINIGAME(SafeZone);
