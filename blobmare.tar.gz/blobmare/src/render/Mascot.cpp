#include "render/Mascot.h"
#include "raymath.h"
#include <cmath>

namespace mascot {

namespace {
const Color kSoot     = { 24, 22, 30, 255 };
const Color kEyeWhite = { 245, 244, 250, 255 };
const Color kPupil    = { 18, 16, 24, 255 };

// DrawTriangle culls clockwise winding; draw both so a spike always shows.
void triBoth(Vector2 a, Vector2 b, Vector2 c, Color col) {
    DrawTriangle(a, b, c, col);
    DrawTriangle(a, c, b, col);
}

// A stable per-index pseudo-random in [0,1]: keeps the fur coat consistent
// frame to frame without storing state.
float hash01(int i) {
    float s = std::sin((float)i * 12.9898f) * 43758.5453f;
    return s - std::floor(s);
}
}

void draw(float cx, float cy, float r, float time,
          float squashY, float alpha, Vector2 lookAt) {
    auto fade = [&](Color c) {
        c.a = (unsigned char)(c.a * alpha); return c;
    };

    float shiver = std::sin(time * 30.0f) * 0.012f
                 + std::sin(time * 17.0f) * 0.010f;
    cx += std::sin(time * 23.0f) * (r * 0.012f);   // micro-jitter

    // --- Little legs (behind body) ---
    for (int s = -1; s <= 1; s += 2) {
        float legX = cx + s * r * 0.34f;
        float legTopY = cy + r * 0.74f * squashY;
        float wob = std::sin(time * 8.0f + s) * (r * 0.025f);
        DrawLineEx(Vector2{ legX, legTopY },
                   Vector2{ legX + wob, legTopY + r * 0.32f },
                   r * 0.085f, fade(kSoot));
        DrawCircleV(Vector2{ legX + wob, legTopY + r * 0.32f },
                    r * 0.058f, fade(kSoot));
    }

    // --- Fuzzy fur: two layers of quivering spikes ---
    const int kSpikes = 88;
    for (int layer = 0; layer < 2; ++layer) {
        for (int i = 0; i < kSpikes; ++i) {
            float ang = (float)i / kSpikes * 2.0f * PI
                      + (layer ? 0.035f : 0.0f);
            float n = std::sin(ang * 7.0f) * 0.5f + std::sin(ang * 13.0f) * 0.5f;
            float baseLen = layer ? 0.30f : (0.52f + 0.20f * n);
            float jit = hash01(i + layer * 777) * (layer ? 0.06f : 0.14f);
            float quiver = std::sin(time * (layer ? 19.0f : 24.0f)
                                    + hash01(i) * 6.28f)
                           * (layer ? 0.04f : 0.06f) + shiver;
            float len = (baseLen + jit + quiver) * r;
            float wIn  = layer ? 0.5f  : 0.55f;
            float wOut = layer ? 0.86f : 0.80f;
            float width = (0.085f + hash01(i + 99) * 0.05f) * r
                          * (layer ? 1.4f : 1.0f);
            Vector2 base{ cx + std::cos(ang) * r * wIn,
                          cy + std::sin(ang) * r * wIn * squashY };
            Vector2 tip{ cx + std::cos(ang) * (r * wOut + len),
                         cy + std::sin(ang) * (r * wOut + len) * squashY };
            Vector2 perp{ -std::sin(ang) * width, std::cos(ang) * width };
            triBoth(Vector2{ base.x + perp.x, base.y + perp.y },
                    Vector2{ base.x - perp.x, base.y - perp.y },
                    tip, fade(kSoot));
        }
    }

    // --- Solid body core ---
    DrawEllipse((int)cx, (int)cy, r * 0.92f, r * 0.92f * squashY, fade(kSoot));

    // --- Eyes ---
    float eyeR  = r * 0.30f;
    float eyeDX = r * 0.34f;
    float eyeY  = cy - r * 0.06f * squashY;
    // Gaze: toward lookAt if given, else a gentle idle drift.
    float gx = std::sin(time * 1.3f) * 0.12f;
    float gy = 0.10f;
    if (lookAt.x >= 0.0f) {
        Vector2 d = Vector2Subtract(lookAt, Vector2{ cx, eyeY });
        float L = Vector2Length(d);
        if (L > 1.0f) { gx = (d.x / L) * 0.34f; gy = (d.y / L) * 0.34f; }
    }
    bool blink = std::fmod(time, 3.4f) > 3.28f;   // a quick blink every ~3.4s
    for (int s = -1; s <= 1; s += 2) {
        Vector2 ec{ cx + s * eyeDX, eyeY };
        DrawEllipse((int)ec.x, (int)ec.y, eyeR, eyeR, fade(kEyeWhite));
        if (!blink) {
            Vector2 pc{ ec.x + gx * eyeR, ec.y + gy * eyeR };
            DrawCircleV(pc, eyeR * 0.46f, fade(kPupil));
            DrawCircleV(Vector2{ pc.x - eyeR*0.16f, pc.y - eyeR*0.18f },
                        eyeR * 0.16f, fade(Color{255,255,255,235}));
        } else {
            DrawLineEx(Vector2{ ec.x - eyeR*0.7f, ec.y },
                       Vector2{ ec.x + eyeR*0.7f, ec.y },
                       eyeR * 0.26f, fade(kPupil));
        }
    }
}

} // namespace mascot
