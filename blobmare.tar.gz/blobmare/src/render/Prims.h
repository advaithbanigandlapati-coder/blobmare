#pragma once
// Shared stylised 3D drawing helpers. Centralising these keeps every arena
// and minigame visually consistent and saves a lot of repetitive rlgl code.
#include "raylib.h"

namespace prims {

// A platform: a slightly bevelled slab with a darker rim, drawn from its
// top-centre. Looks far better than a bare DrawCube.
void platform(Vector3 topCenter, float sizeX, float sizeZ, float thickness,
              Color top, Color rim);

// A circular disc platform (Sumo arena, pressure plates...).
void disc(Vector3 topCenter, float radius, float thickness, Color top, Color rim);

// A wall segment between two ground points, of a given height.
void wall(Vector3 a, Vector3 b, float height, float thickness, Color color);

// A glowing hazard cube/sphere with an emissive feel (pulses over time).
void hazardCube(Vector3 center, float size, Color color);
void hazardSphere(Vector3 center, float radius, Color color);

// A collectible orb that bobs and spins (pass a per-orb phase for variety).
void collectible(Vector3 center, float radius, Color color, float phase);

// A doorway frame (used heavily by the hub hallway).
void doorway(Vector3 base, float width, float height, Color frame, Color innerGlow);

// A soft ground grid fading into the dark — sells the dim-hallway depth.
void groundGrid(Vector3 center, float extent, float cell, Color line);

// A simple pillar / column.
void pillar(Vector3 base, float radius, float height, Color color);

// Checkered floor tile patch.
void checkerFloor(Vector3 center, float extent, float cell, Color a, Color b);

} // namespace prims
