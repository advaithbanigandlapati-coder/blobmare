#include "render/Prims.h"
#include "raymath.h"
#include "rlgl.h"
#include <cmath>

namespace prims {

static Color shade(Color c, float k) {
    auto cl = [](float v){ return (unsigned char)(v < 0 ? 0 : (v > 255 ? 255 : v)); };
    return Color{ cl(c.r * k), cl(c.g * k), cl(c.b * k), c.a };
}

void platform(Vector3 topCenter, float sx, float sz, float thickness,
              Color top, Color rim) {
    Vector3 c{ topCenter.x, topCenter.y - thickness * 0.5f, topCenter.z };
    // Body.
    DrawCube(c, sx, thickness, sz, shade(top, 0.82f));
    // Top face inset (the "bevel").
    DrawCube(Vector3{ topCenter.x, topCenter.y - 0.02f, topCenter.z },
             sx * 0.96f, 0.06f, sz * 0.96f, top);
    // Rim outline.
    DrawCubeWires(c, sx, thickness, sz, shade(rim, 0.7f));
}

void disc(Vector3 topCenter, float radius, float thickness, Color top, Color rim) {
    Vector3 bottom{ topCenter.x, topCenter.y - thickness, topCenter.z };
    DrawCylinder(bottom, radius, radius, thickness, 40, shade(top, 0.8f));
    DrawCylinder(Vector3{ topCenter.x, topCenter.y - 0.04f, topCenter.z },
                 radius * 0.985f, radius * 0.985f, 0.06f, 40, top);
    DrawCylinderWires(bottom, radius, radius, thickness, 40, shade(rim, 0.7f));
}

void wall(Vector3 a, Vector3 b, float height, float thickness, Color color) {
    Vector3 mid = Vector3Scale(Vector3Add(a, b), 0.5f);
    mid.y += height * 0.5f;
    float len = Vector3Distance(a, b);
    float ang = atan2f(b.x - a.x, b.z - a.z) * RAD2DEG;
    rlPushMatrix();
    rlTranslatef(mid.x, mid.y, mid.z);
    rlRotatef(ang, 0, 1, 0);
    DrawCube(Vector3{0,0,0}, thickness, height, len, color);
    DrawCubeWires(Vector3{0,0,0}, thickness, height, len, shade(color, 0.65f));
    rlPopMatrix();
}

void hazardCube(Vector3 center, float size, Color color) {
    float pulse = 0.75f + 0.25f * sinf((float)GetTime() * 6.0f);
    DrawCube(center, size, size, size, shade(color, pulse));
    DrawCubeWires(center, size * 1.02f, size * 1.02f, size * 1.02f,
                  shade(color, 1.3f));
}

void hazardSphere(Vector3 center, float radius, Color color) {
    float pulse = 0.7f + 0.3f * sinf((float)GetTime() * 7.0f);
    DrawSphereEx(center, radius, 12, 12, shade(color, pulse));
    DrawSphereWires(center, radius * 1.04f, 8, 8, shade(color, 1.4f));
}

void collectible(Vector3 center, float radius, Color color, float phase) {
    float t = (float)GetTime() * 2.0f + phase;
    Vector3 p = center;
    p.y += sinf(t) * 0.18f;
    rlPushMatrix();
    rlTranslatef(p.x, p.y, p.z);
    rlRotatef(t * 60.0f, 0, 1, 0);
    DrawSphereEx(Vector3{0,0,0}, radius, 8, 8, color);
    // Halo ring.
    DrawCylinderWires(Vector3{0,-0.01f,0}, radius*1.5f, radius*1.5f, 0.01f, 16,
                      Color{color.r, color.g, color.b, 120});
    rlPopMatrix();
}

void doorway(Vector3 base, float width, float height, Color frame, Color innerGlow) {
    float t = width * 0.16f;             // frame thickness
    // Left & right posts.
    DrawCube(Vector3{ base.x - width*0.5f, base.y + height*0.5f, base.z },
             t, height, t, frame);
    DrawCube(Vector3{ base.x + width*0.5f, base.y + height*0.5f, base.z },
             t, height, t, frame);
    // Lintel.
    DrawCube(Vector3{ base.x, base.y + height, base.z },
             width + t, t, t, frame);
    // Inner glow panel (slightly recessed).
    DrawCube(Vector3{ base.x, base.y + height*0.5f, base.z - t*0.3f },
             width - t*0.3f, height - t*0.3f, 0.05f, innerGlow);
}

void groundGrid(Vector3 center, float extent, float cell, Color line) {
    int n = (int)(extent / cell);
    for (int i = -n; i <= n; ++i) {
        float f = i * cell;
        // Fade lines toward the edges.
        float fade = 1.0f - (float)std::abs(i) / (n + 1);
        Color c = line; c.a = (unsigned char)(line.a * fade);
        DrawLine3D(Vector3{ center.x - extent, center.y, center.z + f },
                   Vector3{ center.x + extent, center.y, center.z + f }, c);
        DrawLine3D(Vector3{ center.x + f, center.y, center.z - extent },
                   Vector3{ center.x + f, center.y, center.z + extent }, c);
    }
}

void pillar(Vector3 base, float radius, float height, Color color) {
    DrawCylinder(base, radius, radius * 0.86f, height, 16, color);
    DrawCylinderWires(base, radius, radius * 0.86f, height, 16, shade(color, 0.7f));
    // Cap.
    DrawCylinder(Vector3{ base.x, base.y + height, base.z },
                 radius * 1.15f, radius * 1.15f, height * 0.06f, 16,
                 shade(color, 1.1f));
}

void checkerFloor(Vector3 center, float extent, float cell, Color a, Color b) {
    int n = (int)(extent / cell);
    for (int ix = -n; ix < n; ++ix) {
        for (int iz = -n; iz < n; ++iz) {
            Color c = ((ix + iz) & 1) ? a : b;
            Vector3 tile{ center.x + (ix + 0.5f) * cell,
                          center.y,
                          center.z + (iz + 0.5f) * cell };
            DrawCube(tile, cell, 0.1f, cell, c);
        }
    }
}

} // namespace prims
