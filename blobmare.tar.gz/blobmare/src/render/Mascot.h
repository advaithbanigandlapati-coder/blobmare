#pragma once
// =============================================================================
//  Mascot — the Shpoingle soot-sprite, drawn in 2D screen space
// =============================================================================
//
//  The studio mascot (a fuzzy spiky soot ball with googly eyes and little
//  legs) appears on the splash, the menu, and result screens. This is the one
//  shared procedural drawer so it looks identical everywhere.
//
//  Purely 2D — call it inside a normal 2D draw pass with a screen position
//  and a pixel radius. It is deterministic given 'time'; pass the running
//  clock for the idle quiver / blink.
//
#include "raylib.h"

namespace mascot {

// Draw the soot sprite centred at (cx,cy) with body radius 'r' pixels.
//   time     — running seconds, drives quiver/blink/leg wobble
//   squashY  — vertical squash (1 = round; <1 = squashed; >1 = stretched)
//   alpha    — 0..1 overall opacity
//   lookAt   — screen point the eyes glance toward (pass the centre for none)
void draw(float cx, float cy, float r, float time,
          float squashY = 1.0f, float alpha = 1.0f,
          Vector2 lookAt = Vector2{ -1, -1 });

} // namespace mascot
