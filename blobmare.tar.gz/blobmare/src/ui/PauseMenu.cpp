#include "ui/PauseMenu.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include <cmath>
#include <algorithm>

namespace {
constexpr int kRootRows = 3;   // Resume, Settings, QuitToMenu
constexpr int kSetRows  = 5;   // Music, Sfx, Fullscreen, Shake, Back
}

void PauseMenu::open(bool networked) {
    open_ = true;
    networked_ = networked;
    page_ = Page::Root;
    rootRow_ = 0;
    setRow_ = 0;
    time_ = 0.0f;
}

void PauseMenu::close() {
    open_ = false;
}

void PauseMenu::applyAudio(GameContext& ctx) const {
    ctx.audio.setMusicVolume(ctx.settings.musicVolume);
    ctx.audio.setSfxVolume(ctx.settings.sfxVolume);
}

PauseResult PauseMenu::update(GameContext& ctx) {
    time_ += GetFrameTime();
    Input& in = ctx.input;

    if (page_ == Page::Root) {
        int dy = in.navY();
        if (dy != 0) {
            rootRow_ = (rootRow_ + dy + kRootRows) % kRootRows;
            ctx.audio.play(Sfx::UiMove);
        }
        if (in.cancelPressed()) {                 // Esc again = resume
            ctx.audio.play(Sfx::UiBack);
            close();
            return PauseResult::Resume;
        }
        if (in.confirmPressed()) {
            switch (rootRow_) {
                case 0:  // Resume
                    ctx.audio.play(Sfx::UiSelect);
                    close();
                    return PauseResult::Resume;
                case 1:  // Settings
                    ctx.audio.play(Sfx::UiSelect);
                    page_ = Page::Settings;
                    setRow_ = 0;
                    break;
                case 2:  // Quit to menu
                    ctx.audio.play(Sfx::UiBack);
                    close();
                    return PauseResult::QuitToMenu;
            }
        }
        return PauseResult::None;
    }

    // --- Settings page ---
    int dy = in.navY();
    if (dy != 0) {
        setRow_ = (setRow_ + dy + kSetRows) % kSetRows;
        ctx.audio.play(Sfx::UiMove);
    }
    int dx = in.navX();
    if (dx != 0) {
        switch (setRow_) {
            case 0:  // Music volume
                ctx.settings.musicVolume = std::clamp(
                    ctx.settings.musicVolume + dx * 0.1f, 0.0f, 1.0f);
                applyAudio(ctx);
                ctx.audio.play(Sfx::UiMove);
                break;
            case 1:  // SFX volume
                ctx.settings.sfxVolume = std::clamp(
                    ctx.settings.sfxVolume + dx * 0.1f, 0.0f, 1.0f);
                applyAudio(ctx);
                ctx.audio.play(Sfx::UiSelect, 0.7f);   // audible sample
                break;
            case 2:  // Fullscreen
                ctx.settings.fullscreen = !ctx.settings.fullscreen;
                ToggleFullscreen();
                ctx.audio.play(Sfx::UiMove);
                break;
            case 3:  // Screen shake
                ctx.settings.screenShake = !ctx.settings.screenShake;
                ctx.audio.play(Sfx::UiMove);
                break;
            default: break;
        }
    }
    if (in.confirmPressed()) {
        if (setRow_ == 2) {                       // toggle fullscreen
            ctx.settings.fullscreen = !ctx.settings.fullscreen;
            ToggleFullscreen();
            ctx.audio.play(Sfx::UiSelect);
        } else if (setRow_ == 3) {                // toggle shake
            ctx.settings.screenShake = !ctx.settings.screenShake;
            ctx.audio.play(Sfx::UiSelect);
        } else if (setRow_ == 4) {                // Back
            ctx.audio.play(Sfx::UiBack);
            page_ = Page::Root;
        }
    }
    if (in.cancelPressed()) {
        ctx.audio.play(Sfx::UiBack);
        page_ = Page::Root;
    }
    return PauseResult::None;
}

// --- Drawing ---------------------------------------------------------------

void PauseMenu::drawRoot(GameContext& ctx) const {
    int cx = ctx.screenW / 2;
    Rectangle box{ cx - 220.0f, ctx.screenH/2 - 190.0f, 440.0f, 380.0f };
    ui::panelBox(box, ui::panel(), ui::accent());

    ui::centerTextShadow("PAUSED", cx, (int)box.y + 28, 48, ui::accent());

    const char* rows[kRootRows] = { "Resume", "Settings", "Quit to Menu" };
    int baseY = (int)box.y + 120;
    for (int i = 0; i < kRootRows; ++i) {
        int y = baseY + i * 64;
        bool sel = (rootRow_ == i);
        if (sel) {
            float p = 0.5f + 0.5f * std::sin(time_ * 6.0f);
            Rectangle hl{ cx - 170.0f, (float)y - 8, 340.0f, 48.0f };
            Color hc = ui::accent(); hc.a = (unsigned char)(40 + 50 * p);
            ui::panelBox(hl, hc, ui::accent());
        }
        ui::centerText(rows[i], cx, y, 30, sel ? ui::accent() : ui::inkDim());
    }
    if (networked_) {
        ui::centerText("networked - the other blob keeps playing",
                       cx, (int)(box.y + box.height - 38), 15, ui::inkDim());
    }
}

void PauseMenu::drawSettings(GameContext& ctx) const {
    int cx = ctx.screenW / 2;
    Rectangle box{ cx - 280.0f, ctx.screenH/2 - 210.0f, 560.0f, 420.0f };
    ui::panelBox(box, ui::panel(), ui::accent());
    ui::centerTextShadow("SETTINGS", cx, (int)box.y + 26, 40, ui::accent());

    int baseY = (int)box.y + 110;
    const int rowH = 56;

    auto rowHighlight = [&](int i) {
        if (setRow_ != i) return;
        float p = 0.5f + 0.5f * std::sin(time_ * 6.0f);
        Rectangle hl{ cx - 250.0f, (float)(baseY + i*rowH) - 8, 500.0f, 44.0f };
        Color hc = ui::accent(); hc.a = (unsigned char)(35 + 45 * p);
        ui::panelBox(hl, hc, ui::accent());
    };
    auto label = [&](int i, const char* text) {
        Color c = (setRow_ == i) ? ui::ink() : ui::inkDim();
        DrawText(text, cx - 230, baseY + i*rowH, 26, c);
    };
    auto sliderAt = [&](int i, float v) {
        Rectangle bar{ (float)cx + 20, (float)(baseY + i*rowH) + 4, 180.0f, 16.0f };
        ui::bar(bar, v, ui::accent2(), Color{0,0,0,150});
        DrawText(TextFormat("%d%%", (int)(v*100 + 0.5f)),
                 cx + 214, baseY + i*rowH, 22,
                 (setRow_==i)?ui::accent():ui::inkDim());
        if (setRow_ == i) {
            DrawText("<", cx - 8, baseY + i*rowH, 24, ui::accent2());
            DrawText(">", cx + 268, baseY + i*rowH, 24, ui::accent2());
        }
    };
    auto toggleAt = [&](int i, bool on) {
        const char* s = on ? "ON" : "OFF";
        Color c = on ? ui::accent2() : ui::inkDim();
        DrawText(s, cx + 120, baseY + i*rowH, 26, (setRow_==i)?ui::accent():c);
        if (setRow_ == i) {
            DrawText("<", cx + 80, baseY + i*rowH, 24, ui::accent2());
            DrawText(">", cx + 176, baseY + i*rowH, 24, ui::accent2());
        }
    };

    for (int i = 0; i < kSetRows; ++i) rowHighlight(i);
    label(0, "Music Volume");   sliderAt(0, ctx.settings.musicVolume);
    label(1, "SFX Volume");     sliderAt(1, ctx.settings.sfxVolume);
    label(2, "Fullscreen");     toggleAt(2, ctx.settings.fullscreen);
    label(3, "Screen Shake");   toggleAt(3, ctx.settings.screenShake);
    label(4, "Back");

    ui::centerText("arrows to adjust  -  Esc to go back",
                   cx, (int)(box.y + box.height - 36), 15, ui::inkDim());
}

void PauseMenu::draw(GameContext& ctx) const {
    if (!open_) return;
    // Dim the frozen game beneath.
    DrawRectangle(0, 0, ctx.screenW, ctx.screenH, Color{0,0,0,170});
    if (page_ == Page::Root) drawRoot(ctx);
    else                     drawSettings(ctx);
}
