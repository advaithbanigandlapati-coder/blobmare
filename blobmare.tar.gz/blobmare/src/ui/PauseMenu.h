#pragma once
// =============================================================================
//  PauseMenu — an in-place pause overlay usable by any gameplay scene
// =============================================================================
//
//  Pause is NOT a scene: it must freeze the game beneath it and draw on top of
//  the still-rendered world. So it is a small self-contained overlay object a
//  scene owns and drives:
//
//      if (pause_.active()) { pause_.update(ctx); pause_.draw(ctx); return; }
//      ... normal scene update ...
//      if (ctx.input.pausePressed()) pause_.open();
//
//  It contains a Resume / Settings / Quit-to-Menu flow. The Settings sub-panel
//  adjusts volume, fullscreen, and the screen-shake toggle live.
//
#include "raylib.h"

struct GameContext;

enum class PauseResult { None, Resume, QuitToMenu };

class PauseMenu {
public:
    void open(bool networked = false);
    void close();
    bool active() const { return open_; }

    PauseResult update(GameContext& ctx);
    void draw(GameContext& ctx) const;

private:
    enum class Page { Root, Settings };

    bool   open_ = false;
    bool   networked_ = false;
    Page   page_ = Page::Root;
    int    rootRow_ = 0;
    int    setRow_  = 0;
    float  time_ = 0.0f;

    void applyAudio(GameContext& ctx) const;
    void drawRoot(GameContext& ctx) const;
    void drawSettings(GameContext& ctx) const;
};
