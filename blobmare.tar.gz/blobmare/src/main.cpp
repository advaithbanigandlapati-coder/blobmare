// =============================================================================
//  Blobmare - main entry point
//
//  A local-multiplayer blob party game: two blobs journey through a dim,
//  doorway-lined hallway, competing in a random slate of minigames drawn from
//  a large pool. First blob to the round target survives the Blobmare.
//
//  Architecture:
//    main()  ->  GameContext (shared services)  ->  SceneManager
//    Scenes: Title / Menu / Hub / Match / Results
//    Match  ->  Minigame (interface)  ->  MinigameRegistry (random draw of N)
//
//  The whole game is asset-free: art is procedural primitives, audio is a
//  startup synth. raylib is fetched and built by CMake.
// =============================================================================
#include "raylib.h"
#include "core/GameContext.h"
#include "game/Scene.h"

int main() {
    // --- Window ----------------------------------------------------------
    const int kWidth  = 1280;
    const int kHeight = 720;

    SetConfigFlags(FLAG_MSAA_4X_HINT | FLAG_WINDOW_RESIZABLE | FLAG_VSYNC_HINT);
    InitWindow(kWidth, kHeight, "Blobmare");
    SetWindowMinSize(960, 540);
    SetTargetFPS(60);
    SetExitKey(KEY_NULL);   // ESC is handled in-game, never an instant quit.

    // --- Shared services -------------------------------------------------
    GameContext ctx;
    ctx.screenW = kWidth;
    ctx.screenH = kHeight;
    ctx.audio.init();
    ctx.lighting.init();
    ctx.camera.init();
    // Apply initial settings.
    ctx.audio.setMusicVolume(ctx.settings.musicVolume);
    ctx.audio.setSfxVolume(ctx.settings.sfxVolume);

    SceneManager scenes;
    scenes.start(ctx, SceneId::Splash);

    // --- Main loop -------------------------------------------------------
    {
        while (!WindowShouldClose() && !ctx.quitRequested) {
            // Track live window size so HUD layout follows resizes.
            ctx.screenW = GetScreenWidth();
            ctx.screenH = GetScreenHeight();

            // Clamp dt so a stall (e.g. window drag) can't explode the sim.
            float dt = GetFrameTime();
            if (dt > 0.05f) dt = 0.05f;

            ctx.input.update();
            ctx.audio.updateMusic();
            // Keep the shake system in sync with the accessibility setting.
            ctx.shake.setEnabled(ctx.settings.screenShake);
            scenes.update(ctx, dt);

            BeginDrawing();
            ClearBackground(BLACK);
            scenes.draw(ctx);
            EndDrawing();
        }
    }

    // --- Shutdown --------------------------------------------------------
    // Order matters: the active scene owns Blobs, and a Blob's BlobMesh holds
    // a GPU mesh that must be freed while the GL context is still alive.
    // releaseScene() destroys the scene (and its blobs) here, BEFORE
    // CloseWindow tears down the context.
    scenes.releaseScene(ctx);
    ctx.lighting.shutdown();
    ctx.audio.shutdown();
    CloseWindow();
    return 0;
}
