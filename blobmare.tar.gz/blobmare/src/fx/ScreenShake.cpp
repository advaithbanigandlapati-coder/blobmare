#include "fx/ScreenShake.h"
#include <cmath>

void ScreenShake::add(float trauma) {
    if (!enabled_) return;          // accessibility: shake disabled
    trauma_ += trauma;
    if (trauma_ > 1.0f) trauma_ = 1.0f;
    if (trauma_ < 0.0f) trauma_ = 0.0f;
}

void ScreenShake::update(float dt) {
    time_ += dt;
    trauma_ -= kDecayPerSec * dt;
    if (trauma_ < 0.0f) trauma_ = 0.0f;
}

// Layered sines at incommensurate frequencies read as smooth pseudo-noise,
// which feels better than per-frame white noise.
static float noise2(float t, float seed) {
    return 0.6f * std::sin(t * 1.0f + seed)
         + 0.3f * std::sin(t * 2.17f + seed * 3.1f)
         + 0.1f * std::sin(t * 4.53f + seed * 7.7f);
}

Vector3 ScreenShake::positionalOffset() const {
    float s = trauma_ * trauma_;
    float t = time_ * kFreq;
    return Vector3{
        noise2(t, 11.3f) * s * kMaxOffset,
        noise2(t, 47.9f) * s * kMaxOffset,
        noise2(t, 91.1f) * s * kMaxOffset * 0.6f,
    };
}

float ScreenShake::rollDegrees() const {
    float s = trauma_ * trauma_;
    return noise2(time_ * kFreq, 123.4f) * s * kMaxRoll;
}
