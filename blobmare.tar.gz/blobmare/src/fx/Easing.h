#pragma once
// Easing & tween helpers. Header-only: tiny, pure, inlined everywhere.
#include <cmath>

namespace ease {

inline float clamp01(float t) { return t < 0.0f ? 0.0f : (t > 1.0f ? 1.0f : t); }
inline float lerp(float a, float b, float t) { return a + (b - a) * t; }

inline float inQuad(float t)  { return t * t; }
inline float outQuad(float t) { return 1.0f - (1.0f - t) * (1.0f - t); }
inline float inOutQuad(float t) {
    return t < 0.5f ? 2.0f * t * t : 1.0f - std::pow(-2.0f * t + 2.0f, 2.0f) / 2.0f;
}
inline float inCubic(float t)  { return t * t * t; }
inline float outCubic(float t) { float u = 1.0f - t; return 1.0f - u * u * u; }
inline float inOutCubic(float t) {
    return t < 0.5f ? 4.0f * t * t * t : 1.0f - std::pow(-2.0f * t + 2.0f, 3.0f) / 2.0f;
}
// Overshoots past 1 then settles — great for pops and reveals.
inline float outBack(float t) {
    const float c1 = 1.70158f, c3 = c1 + 1.0f;
    float u = t - 1.0f;
    return 1.0f + c3 * u * u * u + c1 * u * u;
}
// Springy settle.
inline float outElastic(float t) {
    if (t <= 0.0f) return 0.0f;
    if (t >= 1.0f) return 1.0f;
    const float c4 = (2.0f * 3.14159265f) / 3.0f;
    return std::pow(2.0f, -10.0f * t) * std::sin((t * 10.0f - 0.75f) * c4) + 1.0f;
}
inline float outBounce(float t) {
    const float n1 = 7.5625f, d1 = 2.75f;
    if (t < 1.0f / d1)      return n1 * t * t;
    else if (t < 2.0f / d1) { t -= 1.5f / d1;  return n1 * t * t + 0.75f; }
    else if (t < 2.5f / d1) { t -= 2.25f / d1; return n1 * t * t + 0.9375f; }
    else                    { t -= 2.625f / d1; return n1 * t * t + 0.984375f; }
}

// Frame-rate independent exponential smoothing toward a target.
// 'speed' is roughly "how many e-folds per second".
inline float approach(float cur, float target, float speed, float dt) {
    return target + (cur - target) * std::exp(-speed * dt);
}

} // namespace ease
