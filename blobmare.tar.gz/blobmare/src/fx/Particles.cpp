#include "fx/Particles.h"
#include "raymath.h"
#include "rlgl.h"
#include <cmath>
#include <cstdlib>

namespace {
float frand() { return (float)GetRandomValue(0, 10000) / 10000.0f; }
float frand(float a, float b) { return a + (b - a) * frand(); }
Vector3 randUnit() {
    float z = frand(-1.0f, 1.0f);
    float a = frand(0.0f, 2.0f * PI);
    float r = std::sqrt(1.0f - z * z);
    return Vector3{ r * std::cos(a), z, r * std::sin(a) };
}
} // namespace

void ParticleSystem::clear() {
    for (auto& p : pool_) p.alive = false;
    cursor_ = 0;
}

Particle& ParticleSystem::spawn() {
    // Round-robin reuse: the oldest slot is overwritten if the pool is full.
    Particle& p = pool_[cursor_];
    cursor_ = (cursor_ + 1) % kMax;
    p = Particle{};
    p.alive = true;
    return p;
}

int ParticleSystem::liveCount() const {
    int n = 0;
    for (const auto& p : pool_) if (p.alive) ++n;
    return n;
}

void ParticleSystem::update(float dt) {
    for (auto& p : pool_) {
        if (!p.alive) continue;
        p.life -= dt;
        if (p.life <= 0.0f) { p.alive = false; continue; }
        p.vel.y -= p.gravity * dt;
        if (p.drag > 0.0f) {
            float k = std::exp(-p.drag * dt);
            p.vel = Vector3Scale(p.vel, k);
        }
        p.pos = Vector3Add(p.pos, Vector3Scale(p.vel, dt));
        p.rot = Vector3Add(p.rot, Vector3Scale(p.spin, dt));
        // Confetti flutter: gentle horizontal sway.
        if (p.kind == ParticleKind::Confetti) {
            p.pos.x += std::sin(p.life * 9.0f + p.rot.x) * dt * 0.6f;
        }
    }
}

void ParticleSystem::draw() const {
    for (const auto& p : pool_) {
        if (!p.alive) continue;
        float t = p.life / p.maxLife;             // 1 -> 0
        unsigned char a = (unsigned char)(255.0f * (t > 1.0f ? 1.0f : t));
        Color c = p.color; c.a = a;

        switch (p.kind) {
            case ParticleKind::Spark: {
                float s = p.size * (0.3f + 0.7f * t);
                DrawCube(p.pos, s, s, s, c);
            } break;
            case ParticleKind::Dust: {
                DrawSphereEx(p.pos, p.size * (0.6f + 0.4f * t), 5, 5, c);
            } break;
            case ParticleKind::Smoke: {
                float s = p.size * (1.4f - 0.7f * t);
                c.a = (unsigned char)(a * 0.5f);
                DrawSphereEx(p.pos, s, 6, 6, c);
            } break;
            case ParticleKind::Confetti: {
                rlPushMatrix();
                rlTranslatef(p.pos.x, p.pos.y, p.pos.z);
                rlRotatef(p.rot.x * RAD2DEG, 1, 0, 0);
                rlRotatef(p.rot.y * RAD2DEG, 0, 1, 0);
                rlRotatef(p.rot.z * RAD2DEG, 0, 0, 1);
                DrawCube(Vector3{0,0,0}, p.size, p.size * 0.18f, p.size * 1.6f, c);
                rlPopMatrix();
            } break;
            case ParticleKind::Splat: {
                // age 0->1; quick grow then shrink (sin hump).
                float age = 1.0f - (t > 1.0f ? 1.0f : t);
                float s = p.size * std::sin(age * PI) * 1.1f;
                if (s < 0.0f) s = 0.0f;
                DrawCylinder(p.pos, s, s, 0.04f, 12, c);
            } break;
        }
    }
}

void ParticleSystem::burst(Vector3 pos, int count, Color color, float speed, float spread) {
    for (int i = 0; i < count; ++i) {
        Particle& p = spawn();
        p.kind = ParticleKind::Spark;
        p.pos = pos;
        Vector3 dir = randUnit();
        p.vel = Vector3Scale(dir, speed * frand(0.4f, 1.0f) * spread);
        p.color = color;
        p.maxLife = p.life = frand(0.35f, 0.7f);
        p.size = frand(0.07f, 0.16f);
        p.gravity = 9.0f;
        p.drag = 1.2f;
    }
}

void ParticleSystem::impact(Vector3 pos, Vector3 normal, int count, Color color) {
    for (int i = 0; i < count; ++i) {
        Particle& p = spawn();
        p.kind = ParticleKind::Spark;
        p.pos = pos;
        Vector3 dir = Vector3Normalize(Vector3Add(normal, Vector3Scale(randUnit(), 0.8f)));
        p.vel = Vector3Scale(dir, frand(3.0f, 9.0f));
        p.color = color;
        p.maxLife = p.life = frand(0.25f, 0.55f);
        p.size = frand(0.08f, 0.18f);
        p.gravity = 11.0f;
        p.drag = 1.5f;
    }
}

void ParticleSystem::dust(Vector3 pos, int count, Color color) {
    for (int i = 0; i < count; ++i) {
        Particle& p = spawn();
        p.kind = ParticleKind::Dust;
        p.pos = Vector3Add(pos, Vector3Scale(randUnit(), 0.3f));
        p.vel = Vector3{ frand(-0.4f, 0.4f), frand(0.1f, 0.6f), frand(-0.4f, 0.4f) };
        p.color = color;
        p.maxLife = p.life = frand(1.5f, 3.5f);
        p.size = frand(0.05f, 0.13f);
        p.gravity = -0.3f; // gentle rise
        p.drag = 0.6f;
    }
}

void ParticleSystem::smokePuff(Vector3 pos, int count, Color color) {
    for (int i = 0; i < count; ++i) {
        Particle& p = spawn();
        p.kind = ParticleKind::Smoke;
        p.pos = pos;
        p.vel = Vector3{ frand(-1.0f, 1.0f), frand(0.5f, 2.0f), frand(-1.0f, 1.0f) };
        p.color = color;
        p.maxLife = p.life = frand(0.6f, 1.2f);
        p.size = frand(0.25f, 0.5f);
        p.gravity = -1.0f;
        p.drag = 2.0f;
    }
}

void ParticleSystem::confetti(Vector3 pos, int count) {
    const Color palette[] = {
        {255,99,99,255},{99,200,255,255},{255,214,99,255},
        {160,255,140,255},{220,140,255,255},{255,255,255,255},
    };
    for (int i = 0; i < count; ++i) {
        Particle& p = spawn();
        p.kind = ParticleKind::Confetti;
        p.pos = Vector3Add(pos, Vector3{frand(-1.5f,1.5f), frand(0,1.0f), frand(-1.5f,1.5f)});
        p.vel = Vector3{ frand(-2.5f,2.5f), frand(4.0f,9.0f), frand(-2.5f,2.5f) };
        p.spin = Vector3{ frand(-8,8), frand(-8,8), frand(-8,8) };
        p.color = palette[GetRandomValue(0, 5)];
        p.maxLife = p.life = frand(2.0f, 4.0f);
        p.size = frand(0.18f, 0.32f);
        p.gravity = 5.5f;
        p.drag = 0.4f;
    }
}

void ParticleSystem::splat(Vector3 pos, Color color, float size) {
    Particle& p = spawn();
    p.kind = ParticleKind::Splat;
    p.pos = pos;
    p.color = color;
    p.maxLife = p.life = 0.4f;
    p.size = size;
}

void ParticleSystem::ring(Vector3 center, float radius, int count, Color color, float speed) {
    for (int i = 0; i < count; ++i) {
        float a = (float)i / count * 2.0f * PI;
        Particle& p = spawn();
        p.kind = ParticleKind::Spark;
        p.pos = Vector3Add(center, Vector3{ std::cos(a) * radius, 0.1f, std::sin(a) * radius });
        p.vel = Vector3{ std::cos(a) * speed, frand(1.0f, 3.0f), std::sin(a) * speed };
        p.color = color;
        p.maxLife = p.life = frand(0.4f, 0.8f);
        p.size = frand(0.1f, 0.2f);
        p.gravity = 10.0f;
        p.drag = 1.0f;
    }
}
