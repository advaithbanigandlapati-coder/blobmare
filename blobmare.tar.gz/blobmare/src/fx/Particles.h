#pragma once
// Pooled 3D particle system. Fixed-size pool, no per-frame allocation.
// Particles are drawn as small 3D primitives inside a Begin/EndMode3D block.
#include "raylib.h"
#include <array>

enum class ParticleKind {
    Spark,    // small bright cube, gravity, shrinks
    Dust,     // soft slow sphere, drifts up, fades
    Smoke,    // grows while fading
    Confetti, // spinning flake under gravity with flutter
    Splat,    // quick scale-pop flat disc
};

struct Particle {
    bool  alive = false;
    ParticleKind kind = ParticleKind::Spark;
    Vector3 pos{}, vel{};
    Vector3 spin{};            // confetti rotation rate
    Vector3 rot{};             // confetti current rotation
    Color color{255,255,255,255};
    float life = 0.0f, maxLife = 1.0f;
    float size = 0.1f;
    float drag = 0.0f;
    float gravity = 0.0f;
};

class ParticleSystem {
public:
    void clear();
    void update(float dt);
    void draw() const;          // call inside BeginMode3D/EndMode3D
    int  liveCount() const;

    // --- Emitters --------------------------------------------------------
    void burst(Vector3 pos, int count, Color color, float speed, float spread = 1.0f);
    void impact(Vector3 pos, Vector3 normal, int count, Color color);
    void dust(Vector3 pos, int count, Color color);
    void smokePuff(Vector3 pos, int count, Color color);
    void confetti(Vector3 pos, int count);
    void splat(Vector3 pos, Color color, float size);
    void ring(Vector3 center, float radius, int count, Color color, float speed);

private:
    static constexpr int kMax = 3000;
    std::array<Particle, kMax> pool_{};
    int cursor_ = 0;
    Particle& spawn();
};
