#pragma once
// Trauma-based screen shake. Trauma decays linearly; actual shake = trauma^2
// so small bumps stay subtle and big hits punch. Additive on the camera.
#include "raylib.h"

class ScreenShake {
public:
    // Add trauma in [0,1]. Clamped. Big hits ~0.6, small bumps ~0.2.
    void add(float trauma);
    void update(float dt);

    // Master enable (accessibility setting). When off, add() is ignored and
    // any residual trauma decays out; offsets read as zero.
    void setEnabled(bool on) { enabled_ = on; }
    bool enabled() const { return enabled_; }

    // Positional jitter added to camera position (world units).
    Vector3 positionalOffset() const;
    // Camera roll in degrees (rotates the up vector slightly).
    float rollDegrees() const;

    float trauma() const { return trauma_; }

private:
    float trauma_ = 0.0f;
    bool  enabled_ = true;
    float time_   = 0.0f;
    // Tuning.
    static constexpr float kDecayPerSec = 1.6f;
    static constexpr float kMaxOffset   = 0.55f; // world units
    static constexpr float kMaxRoll     = 2.4f;  // degrees
    static constexpr float kFreq        = 26.0f; // shake frequency
};
