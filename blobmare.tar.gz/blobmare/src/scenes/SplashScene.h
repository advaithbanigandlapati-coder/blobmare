#pragma once
// =============================================================================
//  SplashScene — the Shpoingle Studios startup logo
// =============================================================================
//
//  The first thing the player sees, in the spirit of a studio bumper (the way
//  Team Cherry opens Hollow Knight). A soot-sprite mascot — a fuzzy spiky
//  black ball with big googly eyes and little legs — bounces in, shivers,
//  blinks, and the words "SHPOINGLE STUDIOS" rise beneath it. A soft chime
//  plays. Then the whole thing dissolves into the title screen.
//
//  Entirely procedural: the sprite is drawn from primitives (a ring of fur
//  spikes + eyes + legs), no asset files. The mascot matches the studio logo.
//
//  The splash is skippable — any key / click jumps straight to the title.
//
#include "game/Scene.h"
#include <vector>

class SplashScene : public Scene {
public:
    void enter(GameContext& ctx, SceneManager& mgr) override;
    void update(GameContext& ctx, SceneManager& mgr, float dt) override;
    void draw(GameContext& ctx) override;

private:
    enum class Phase {
        BounceIn,    // mascot drops + squashes in
        Settle,      // shiver + blink, name fades up
        Hold,        // brief beat with everything on screen
        FadeOut      // dissolve to title
    };

    Phase  phase_ = Phase::BounceIn;
    float  time_  = 0.0f;        // time within the current phase
    float  total_ = 0.0f;        // total elapsed
    bool   chimePlayed_ = false;
    bool   blinkOpen_ = true;
    float  blinkTimer_ = 1.4f;

    // Each fur spike: an angle + a length + a per-spike shiver phase.
    struct Spike { float ang, len, phase, width; };
    std::vector<Spike> spikes_;

    void finish(SceneManager& mgr);
};
