#include "scenes/MatchScene.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "game/MinigameRegistry.h"
#include "net/RtMicSource.h"
#include "fx/Easing.h"
#include "raymath.h"
#include <cmath>
#include <algorithm>

namespace {
constexpr float kFixed       = 1.0f / 120.0f;
constexpr float kIntroTime   = 2.6f;
constexpr float kCountStep   = 0.85f;     // seconds per countdown number
constexpr float kWinFreeze   = 2.8f;
}

void MatchScene::enter(GameContext& ctx, SceneManager& mgr) {
    (void)mgr;
    phase_      = Phase::Intro;
    phaseTime_  = 0.0f;
    accum_      = 0.0f;
    countNumber_= 3;
    lastCountShown_ = 99;
    result_     = MinigameResult{};
    hitStop_    = 0.0f;

    // Pick the current minigame from the slate.
    int gi = 0;
    if (ctx.match.hasMoreMinigames())
        gi = ctx.match.slate[ctx.match.index];
    gi = std::clamp(gi, 0, std::max(0, MinigameRegistry::instance().count() - 1));
    game_ = MinigameRegistry::instance().create(gi);

    // Build player blobs.
    blobPtrs_.clear();
    for (int i = 0; i < 2; ++i) {
        blobs_[i].init(i, ctx.config.playerColor[i], ctx.config.playerSize[i]);
        // Apply the player's custom character from the editor, if they made
        // one; otherwise init() already gave them the default critter.
        if (ctx.config.playerLimbsCustom[i])
            blobs_[i].setLimbs(ctx.config.playerLimbs[i]);
        blobPtrs_.push_back(&blobs_[i]);
    }

    // Let the minigame build its arena and place blobs.
    game_->setup(ctx, blobPtrs_);

    // Networked client: bind this minigame's physics World to the predictor
    // so reconciliation can re-simulate the local blob in the correct arena.
    if (ctx.net.mode() == NetMode::Client) {
        ctx.net.bindPredictionWorld(game_->physicsWorld(), kFixed);
    }
    // Networked match: bring up proximity voice chat. Try the real mic
    // (RtMicSource); if no microphone is available or permission is denied,
    // fall back to the synthetic source so the match still runs cleanly.
    if (ctx.net.isNetworked() && !ctx.net.voiceActive()) {
        auto mic = std::make_unique<net::RtMicSource>();
        if (mic->start()) {
            ctx.net.enableVoice(std::move(mic));
        } else {
            TraceLog(LOG_WARNING, "Voice: %s — using synthetic source",
                     mic->lastError());
            ctx.net.enableVoice(std::make_unique<net::SyntheticMicSource>());
        }
    }

    ctx.camera.init();
    ctx.camera.clearStaticShot();
    ctx.camera.setHeight(9.0f);
    ctx.camera.setDistance(13.0f);
    ctx.camera.setPitch(40.0f);
    ctx.camera.setTargets(game_->cameraTargets(blobPtrs_));
    ctx.camera.snap();

    ctx.audio.setMusic(Audio::Music::Minigame);
    ctx.particles.clear();
}

void MatchScene::exit(GameContext& ctx) {
    (void)ctx;
    game_.reset();
}

void MatchScene::stepSim(GameContext& ctx, float dt, bool inputEnabled) {
    // Sample devices + sync the network ONCE per sim step. In Local mode this
    // is a trivial passthrough; in Host/Client mode it pumps the session and
    // resolves which input each blob acts on (local device vs networked).
    ctx.net.sampleAndSync(ctx.input, dt * 1000.0f);

    // Blobs read their resolved input (minigame may override afterwards).
    for (int i = 0; i < 2; ++i) {
        blobs_[i].control(ctx.net.inputForBlob(i, ctx.input), dt,
                          inputEnabled, inputEnabled);
        if (blobs_[i].dashStartedThisStep())
            ctx.audio.play(Sfx::Dash, 0.7f, 0.1f);
    }
    game_->update(ctx, blobPtrs_, dt, inputEnabled);

    // Client: apply the host's authoritative snapshot. For the LOCAL blob this
    // runs reconciliation (re-simulate from authority if prediction diverged);
    // for the remote blob it snaps to the snapshot. Then record this tick's
    // predicted local-blob state so future reconciliations can replay it.
    // Host: capture this tick's state and broadcast it.
    if (ctx.net.mode() == NetMode::Client) {
        ctx.net.applyLatestSnapshot(blobPtrs_);
        ctx.net.recordPredictionFrame(blobPtrs_);
    } else if (ctx.net.mode() == NetMode::Host) {
        int score[2] = { ctx.match.score[0], ctx.match.score[1] };
        ctx.net.captureAndPublish(blobPtrs_, (uint8_t)SceneId::Match,
                                  (uint8_t)ctx.match.index, score);
    }

    // Advance the shared sim tick (network input is keyed on it).
    ctx.net.advanceTick();

    // Proximity voice: capture/send/receive + attenuate by blob distance.
    if (ctx.net.isNetworked())
        ctx.net.updateVoice(blobPtrs_);
}

void MatchScene::resolveAndAdvance(GameContext& ctx) {
    result_ = game_->result();
    ctx.match.lastWasDraw = result_.draw;
    ctx.match.lastWinner  = result_.draw ? -1 : result_.winner;
    if (!result_.draw && (result_.winner == 0 || result_.winner == 1)) {
        ctx.match.score[result_.winner]++;
    }
    ctx.match.index++;
}

void MatchScene::update(GameContext& ctx, SceneManager& mgr, float dt) {
    // --- Pause overlay ---------------------------------------------------
    // While paused the whole match sim is frozen. In networked play we don't
    // pause the sim (the other peer plays on) — pause only opens settings.
    if (pause_.active()) {
        ctx.paused = true;
        PauseResult res = pause_.update(ctx);
        if (res == PauseResult::QuitToMenu) {
            ctx.paused = false;
            ctx.net.end();
            mgr.requestSwitch(SceneId::Menu);
        } else if (res == PauseResult::Resume) {
            ctx.paused = false;
        }
        // In networked mode keep pumping the sim even while the menu is up.
        if (ctx.net.isNetworked() && pause_.active()) {
            ctx.paused = false;   // don't freeze a networked match
        } else {
            return;               // local match: frozen, skip the sim
        }
    }
    if (ctx.input.pausePressed() && phase_ != Phase::WinFreeze
        && !pause_.active()) {
        ctx.audio.play(Sfx::UiBack);
        pause_.open(ctx.net.isNetworked());
        if (!ctx.net.isNetworked()) return;
    }

    phaseTime_ += dt;

    switch (phase_) {
        case Phase::Intro: {
            if (phaseTime_ >= kIntroTime || ctx.input.confirmPressed()) {
                phase_ = Phase::Countdown;
                phaseTime_ = 0.0f;
                countNumber_ = 3;
            }
            // Blobs still settle physically during the splash.
            accum_ += dt;
            int steps = 0;
            while (accum_ >= kFixed && steps < 8) {
                stepSim(ctx, kFixed, false);
                accum_ -= kFixed; ++steps;
            }
        } break;

        case Phase::Countdown: {
            int idx = (int)(phaseTime_ / kCountStep);
            countNumber_ = 3 - idx;
            if (countNumber_ != lastCountShown_ && countNumber_ >= 1) {
                lastCountShown_ = countNumber_;
                ctx.audio.play(Sfx::Countdown);
                ctx.shake.add(0.12f);
            }
            accum_ += dt;
            int steps = 0;
            while (accum_ >= kFixed && steps < 8) {
                stepSim(ctx, kFixed, false);
                accum_ -= kFixed; ++steps;
            }
            if (phaseTime_ >= kCountStep * 3.0f) {
                phase_ = Phase::Play;
                phaseTime_ = 0.0f;
                ctx.audio.play(Sfx::Go);
                ctx.shake.add(0.3f);
            }
        } break;

        case Phase::Play: {
            // Hit-stop: freeze briefly on big impacts for game feel.
            float simDt = dt * ctx.timeScale;
            if (hitStop_ > 0.0f) {
                hitStop_ -= dt;
                simDt = 0.0f;
            }
            accum_ += simDt;
            int steps = 0;
            while (accum_ >= kFixed && steps < 8) {
                stepSim(ctx, kFixed, true);
                accum_ -= kFixed; ++steps;
            }
            if (game_->finished()) {
                phase_ = Phase::WinFreeze;
                phaseTime_ = 0.0f;
                resolveAndAdvance(ctx);
                // Celebration.
                if (!result_.draw && result_.winner >= 0) {
                    blobs_[result_.winner].setEmote(Emote::Happy);
                    int loser = 1 - result_.winner;
                    blobs_[loser].setEmote(Emote::Dizzy);
                    ctx.audio.play(Sfx::Win);
                    Vector3 wp = blobs_[result_.winner].position();
                    ctx.particles.confetti(Vector3{wp.x, wp.y + 2.0f, wp.z}, 90);
                } else {
                    ctx.audio.play(Sfx::Lose);
                }
                ctx.shake.add(0.5f);
            }
        } break;

        case Phase::WinFreeze: {
            // Keep particles/physics ticking gently for the celebration.
            accum_ += dt;
            int steps = 0;
            while (accum_ >= kFixed && steps < 8) {
                stepSim(ctx, kFixed, false);
                accum_ -= kFixed; ++steps;
            }
            if (phaseTime_ >= kWinFreeze || ctx.input.confirmPressed()) {
                mgr.requestSwitch(SceneId::Hub);
            }
        } break;
    }

    ctx.shake.update(dt);
    ctx.particles.update(dt);
    if (game_) ctx.camera.setTargets(game_->cameraTargets(blobPtrs_));
    ctx.camera.update(dt, ctx.shake);
}

// --- Drawing ---------------------------------------------------------------

void MatchScene::drawScoreHUD(GameContext& ctx) {
    for (int i = 0; i < 2; ++i) {
        float bx = (i == 0) ? 24.0f : ctx.screenW - 224.0f;
        Rectangle pill{ bx, 22, 200, 52 };
        ui::panelBox(pill, ui::panel(), ctx.config.playerColor[i]);
        DrawCircle((int)bx + 30, 48, 16, ctx.config.playerColor[i]);
        DrawText(ctx.config.playerName[i], (int)bx + 54, 32, 20, ui::ink());
        DrawText(TextFormat("%d", ctx.match.score[i]),
                 (int)bx + 160, 28, 34, ui::accent());
    }
    // Minigame counter, centre-top.
    ui::centerText(TextFormat("minigame %d / %d",
                              ctx.match.index + 1,
                              (int)ctx.match.slate.size()),
                   ctx.screenW / 2, 28, 18, ui::inkDim());
}

void MatchScene::drawIntroHUD(GameContext& ctx) {
    MinigameInfo info = game_->info();
    int cx = ctx.screenW / 2;

    float t = ease::clamp01(phaseTime_ / 0.4f);
    float pop = ease::outBack(t);
    int   yo  = (int)((1.0f - pop) * 60.0f);

    DrawRectangle(0, ctx.screenH/2 - 150, ctx.screenW, 300,
                  Color{0,0,0,150});

    ui::centerTextShadow(info.name.c_str(), cx,
                         ctx.screenH/2 - 90 + yo, 64, ui::accent());
    ui::centerText(info.tagline.c_str(), cx,
                   ctx.screenH/2 - 18 + yo, 24, ui::ink());
    ui::centerText(info.howTo.c_str(), cx,
                   ctx.screenH/2 + 28 + yo, 22, ui::accent2());

    const char* kind = "";
    switch (info.winKind) {
        case WinKind::LastStanding: kind = "last blob standing wins"; break;
        case WinKind::FirstToGoal:  kind = "first to the goal wins";  break;
        case WinKind::HighScore:    kind = "highest score wins";      break;
        case WinKind::Survival:     kind = "survive to win";          break;
    }
    ui::centerText(kind, cx, ctx.screenH/2 + 70 + yo, 18, ui::inkDim());
}

void MatchScene::drawCountdownHUD(GameContext& ctx) {
    int cx = ctx.screenW / 2, cy = ctx.screenH / 2;
    float local = std::fmod(phaseTime_, kCountStep) / kCountStep;
    float scale = 1.0f + (1.0f - ease::outCubic(local)) * 1.6f;
    unsigned char a = (unsigned char)(255 * (1.0f - local * 0.5f));

    const char* txt = (countNumber_ >= 1)
                        ? TextFormat("%d", countNumber_) : "GO!";
    int size = (int)(140 * scale);
    int w = MeasureText(txt, size);
    Color c = (countNumber_ >= 1) ? ui::accent() : ui::accent2();
    c.a = a;
    DrawText(txt, cx - w/2 + 4, cy - size/2 + 4, size, Color{0,0,0,(unsigned char)(a*0.5f)});
    DrawText(txt, cx - w/2,     cy - size/2,     size, c);
}

void MatchScene::drawWinHUD(GameContext& ctx) {
    int cx = ctx.screenW / 2;
    float t = ease::clamp01(phaseTime_ / 0.5f);
    int yo = (int)((1.0f - ease::outBack(t)) * -50.0f);

    DrawRectangle(0, 120, ctx.screenW, 150, Color{0,0,0,140});
    if (result_.draw) {
        ui::centerTextShadow("DRAW!", cx, 150 + yo, 72, ui::inkDim());
        ui::centerText("no point awarded", cx, 226 + yo, 22, ui::inkDim());
    } else {
        const char* nm = ctx.config.playerName[result_.winner];
        ui::centerTextShadow(TextFormat("%s WINS!", nm), cx, 150 + yo, 72,
                             ctx.config.playerColor[result_.winner]);
        ui::centerText("a point toward the match", cx, 226 + yo, 22, ui::ink());
    }
    float p = ui::pulse(3.0f);
    Color cc = ui::ink(); cc.a = (unsigned char)(110 + 130 * p);
    ui::centerText("returning to the hallway...", cx, ctx.screenH - 70, 20, cc);
}

void MatchScene::draw(GameContext& ctx) {
    ClearBackground(ui::bg());

    ctx.lighting.setCamera(ctx.camera.eye());

    // --- Shadow depth pass: render all 3D geometry from the light's view ---
    // The minigame + blobs are drawn again here depth-only; lighting.begin()
    // swaps to the depth shader automatically while the shadow pass is open.
    ctx.lighting.setShadowFocus(Vector3{0, 1.0f, 0}, 20.0f);
    ctx.lighting.beginShadowPass();
    if (ctx.lighting.shadowsActive()) {
        if (game_) game_->draw3D(ctx, blobPtrs_);
        float a = accum_ / kFixed;
        for (int i = 0; i < 2; ++i) blobs_[i].draw(ctx.lighting, a);
    }
    ctx.lighting.endShadowPass();

    BeginMode3D(ctx.camera.cam());
    {
        if (game_) game_->draw3D(ctx, blobPtrs_);

        float alpha = accum_ / kFixed;
        // Apply the netcode prediction-correction ease to the local blob only.
        int localIdx = (ctx.net.mode() == NetMode::Client)
                       ? ctx.net.localBlobIndex() : -1;
        for (int i = 0; i < 2; ++i) {
            Vector3 off = (i == localIdx) ? ctx.net.predictionVisualOffset()
                                          : Vector3{0,0,0};
            blobs_[i].draw(ctx.lighting, alpha, off);
        }

        ctx.lighting.begin();
        ctx.particles.draw();
        ctx.lighting.end();
    }
    EndMode3D();

    // --- 2D HUD -----------------------------------------------------------
    drawScoreHUD(ctx);
    if (game_) game_->drawHUD(ctx, blobPtrs_);

    // Time-limit clock.
    if (game_ && phase_ == Phase::Play) {
        float lim = game_->timeLimit();
        if (lim > 0.0f) {
            float left = lim - phaseTime_;
            if (left < 0.0f) left = 0.0f;
            Rectangle bar{ ctx.screenW/2.0f - 150, 54, 300, 14 };
            Color fill = (left < 5.0f) ? ui::danger() : ui::accent2();
            ui::bar(bar, left / lim, fill, Color{0,0,0,140});
            // Audible low-time warning: one tick per second under 5s.
            int sec = (int)std::ceil(left);
            if (left <= 5.0f && sec != lastClockTick_) {
                lastClockTick_ = sec;
                if (left > 0.05f) ctx.audio.play(Sfx::Tick, 0.7f);
            }
        }
    }

    switch (phase_) {
        case Phase::Intro:     drawIntroHUD(ctx);     break;
        case Phase::Countdown: drawCountdownHUD(ctx); break;
        case Phase::Play:                              break;
        case Phase::WinFreeze: drawWinHUD(ctx);       break;
    }

    ui::vignette(ctx.screenW, ctx.screenH, 0.6f);

    // Pause overlay draws last, on top of everything.
    pause_.draw(ctx);
}
