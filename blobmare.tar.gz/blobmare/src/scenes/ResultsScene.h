#pragma once
// ResultsScene: the match is over. The winning blob celebrates on a podium in
// a spotlit version of the hallway; the final score is shown. Players can run
// the match back (fresh random slate) or return to the menu.
#include "game/Scene.h"
#include "blob/Blob.h"
#include "physics/World.h"

class ResultsScene : public Scene {
public:
    void enter(GameContext& ctx, SceneManager& mgr) override;
    void update(GameContext& ctx, SceneManager& mgr, float dt) override;
    void draw(GameContext& ctx) override;

private:
    World world_;
    Blob  blobs_[2];
    float time_  = 0.0f;
    float accum_ = 0.0f;
    int   winner_ = -1;
    bool  tie_ = false;
    int   row_ = 0;          // 0 = rematch, 1 = menu
    float confettiTimer_ = 0.0f;
};
