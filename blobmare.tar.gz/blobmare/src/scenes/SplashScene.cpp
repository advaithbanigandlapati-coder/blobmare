#include "scenes/SplashScene.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "raymath.h"
#include <cmath>

namespace {
// Phase durations (seconds).
constexpr float kBounceIn = 0.85f;
constexpr float kSettle   = 1.40f;
constexpr float kHold     = 1.05f;
constexpr float kFadeOut  = 0.70f;

// Soot-sprite colours.
const Color kSoot      = { 24, 22, 30, 255 };     // near-black fuzzy body
// (kSootEdge removed — fur now uses kSoot directly)
const Color kEyeWhite  = { 245, 244, 250, 255 };
const Color kPupil     = { 18, 16, 24, 255 };

float easeOutBack(float t) {
    const float c1 = 1.70158f, c3 = c1 + 1.0f;
    float u = t - 1.0f;
    return 1.0f + c3 * u * u * u + c1 * u * u;
}
float easeOutCubic(float t) { float u = 1.0f - t; return 1.0f - u*u*u; }

// DrawTriangle culls clockwise triangles; this draws either winding safely.
void triFuzz(Vector2 a, Vector2 b, Vector2 c, Color col) {
    DrawTriangle(a, b, c, col);
    DrawTriangle(a, c, b, col);
}
}


void SplashScene::enter(GameContext& ctx, SceneManager& mgr) {
    (void)ctx; (void)mgr;
    phase_ = Phase::BounceIn;
    time_ = total_ = 0.0f;
    chimePlayed_ = false;
    blinkOpen_ = true;
    blinkTimer_ = 1.4f;

    // Build the ring of fur spikes — many short dark spikes radiating out,
    // each with its own shiver phase so the whole coat quivers.
    spikes_.clear();
    const int kSpikes = 96;
    for (int i = 0; i < kSpikes; ++i) {
        Spike s;
        s.ang   = (float)i / kSpikes * 2.0f * PI;
        // Long, ragged spikes so the soot sprite reads as FUZZY, not a ball.
        float n = std::sin(s.ang * 7.0f) * 0.5f + std::sin(s.ang * 13.0f) * 0.5f;
        s.len   = 0.52f + 0.20f * n + 0.14f * (float)GetRandomValue(0, 100) / 100.0f;
        s.phase = (float)GetRandomValue(0, 628) / 100.0f;
        s.width = 0.085f + 0.05f * (float)GetRandomValue(0, 100) / 100.0f;
        spikes_.push_back(s);
    }
}

void SplashScene::finish(SceneManager& mgr) {
    mgr.requestSwitch(SceneId::Title);
}

void SplashScene::update(GameContext& ctx, SceneManager& mgr, float dt) {
    time_  += dt;
    total_ += dt;

    // Skippable — any key or click jumps to the title.
    if (GetKeyPressed() != 0 || IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
        finish(mgr);
        return;
    }

    // Blink cycle.
    blinkTimer_ -= dt;
    if (blinkTimer_ <= 0.0f) {
        blinkOpen_ = !blinkOpen_;
        blinkTimer_ = blinkOpen_ ? (float)GetRandomValue(120, 320) / 100.0f
                                 : 0.12f;
    }

    switch (phase_) {
        case Phase::BounceIn:
            if (time_ >= kBounceIn) { phase_ = Phase::Settle; time_ = 0.0f; }
            break;
        case Phase::Settle:
            // The chime lands as the name begins to rise.
            if (!chimePlayed_ && time_ > 0.15f) {
                ctx.audio.play(Sfx::Win, 0.7f);
                chimePlayed_ = true;
            }
            if (time_ >= kSettle) { phase_ = Phase::Hold; time_ = 0.0f; }
            break;
        case Phase::Hold:
            if (time_ >= kHold) { phase_ = Phase::FadeOut; time_ = 0.0f; }
            break;
        case Phase::FadeOut:
            if (time_ >= kFadeOut) { finish(mgr); }
            break;
    }
}

void SplashScene::draw(GameContext& ctx) {
    // A soft warm off-white field, like the studio logo card.
    ClearBackground(Color{ 246, 244, 238, 255 });

    const float cx = ctx.screenW * 0.5f;
    const float cy = ctx.screenH * 0.46f;

    // --- Mascot transform per phase --------------------------------------
    float scale = 1.0f, squashY = 1.0f, dropY = 0.0f, alpha = 1.0f;

    if (phase_ == Phase::BounceIn) {
        float t = time_ / kBounceIn;
        scale  = easeOutBack(t);
        dropY  = -(1.0f - easeOutCubic(t)) * 220.0f;     // falls into place
        // Squash on landing.
        if (t > 0.78f) {
            float l = (t - 0.78f) / 0.22f;
            squashY = 1.0f - 0.18f * std::sin(l * PI);
        }
    } else if (phase_ == Phase::FadeOut) {
        float t = time_ / kFadeOut;
        alpha = 1.0f - t;
        scale = 1.0f + 0.10f * t;                        // gentle puff-out
    }

    // Continuous idle shiver — the soot sprite is never quite still.
    float shiver = std::sin(total_ * 30.0f) * 0.012f
                 + std::sin(total_ * 17.0f) * 0.010f;

    float R = ctx.screenH * 0.165f * scale;              // body radius (px)
    float bodyCX = cx + std::sin(total_ * 23.0f) * 1.6f; // micro-jitter
    float bodyCY = cy + dropY;

    auto fade = [&](Color c) {
        c.a = (unsigned char)(c.a * alpha); return c;
    };

    // --- Little legs (drawn behind the body) -----------------------------
    for (int s = -1; s <= 1; s += 2) {
        float legX = bodyCX + s * R * 0.34f;
        float legTopY = bodyCY + R * 0.74f * squashY;
        float wob = std::sin(total_ * 8.0f + s) * 3.0f;
        DrawLineEx(Vector2{ legX, legTopY },
                   Vector2{ legX + wob, legTopY + R * 0.32f },
                   R * 0.085f, fade(kSoot));
        DrawCircleV(Vector2{ legX + wob, legTopY + R * 0.32f },
                    R * 0.055f, fade(kSoot));
    }

    // --- Fuzzy fur coat: a ring of quivering spikes ----------------------
    // Spikes are rooted well INSIDE the body and reach well past its edge, so
    // the silhouette is unmistakably fuzzy. Drawn before the solid core.
    for (const auto& sp : spikes_) {
        float quiver = std::sin(total_ * 24.0f + sp.phase) * 0.06f + shiver;
        float len = (sp.len + quiver) * R;
        float ang = sp.ang;
        float rootR = R * 0.55f;        // rooted deep inside
        Vector2 base{
            bodyCX + std::cos(ang) * rootR,
            bodyCY + std::sin(ang) * rootR * squashY };
        Vector2 tip{
            bodyCX + std::cos(ang) * (R * 0.80f + len),
            bodyCY + std::sin(ang) * (R * 0.80f + len) * squashY };
        Vector2 perp{ -std::sin(ang) * sp.width * R,
                       std::cos(ang) * sp.width * R };
        triFuzz(
            Vector2{ base.x + perp.x, base.y + perp.y },
            Vector2{ base.x - perp.x, base.y - perp.y },
            tip, fade(kSoot));
    }
    // A second, shorter inner fuzz layer fills any gaps between spikes.
    for (const auto& sp : spikes_) {
        float quiver = std::sin(total_ * 19.0f + sp.phase * 1.7f) * 0.04f;
        float ang = sp.ang + 0.03f;
        float len = (0.30f + quiver) * R;
        Vector2 base{ bodyCX + std::cos(ang) * R * 0.5f,
                      bodyCY + std::sin(ang) * R * 0.5f * squashY };
        Vector2 tip{ bodyCX + std::cos(ang) * (R * 0.86f + len),
                     bodyCY + std::sin(ang) * (R * 0.86f + len) * squashY };
        Vector2 perp{ -std::sin(ang) * sp.width * R * 1.4f,
                       std::cos(ang) * sp.width * R * 1.4f };
        triFuzz(
            Vector2{ base.x + perp.x, base.y + perp.y },
            Vector2{ base.x - perp.x, base.y - perp.y },
            tip, fade(kSoot));
    }

    // --- Solid body core --------------------------------------------------
    DrawEllipse((int)bodyCX, (int)bodyCY,
                R * 0.92f, R * 0.92f * squashY, fade(kSoot));

    // --- Eyes -------------------------------------------------------------
    float eyeR  = R * 0.30f;
    float eyeDX = R * 0.34f;
    float eyeY  = bodyCY - R * 0.06f * squashY;
    // Eyes look slightly toward the viewer, with a gentle drift.
    float gaze  = std::sin(total_ * 1.3f) * 0.12f;
    for (int s = -1; s <= 1; s += 2) {
        Vector2 ec{ bodyCX + s * eyeDX, eyeY };
        DrawEllipse((int)ec.x, (int)ec.y, eyeR, eyeR, fade(kEyeWhite));
        if (blinkOpen_) {
            Vector2 pc{ ec.x + gaze * eyeR, ec.y + 0.10f * eyeR };
            DrawCircleV(pc, eyeR * 0.46f, fade(kPupil));
            // Catch-light.
            DrawCircleV(Vector2{ pc.x - eyeR*0.16f, pc.y - eyeR*0.18f },
                        eyeR * 0.15f, fade(Color{255,255,255,235}));
        } else {
            // Closed: a soft horizontal lid line.
            DrawLineEx(Vector2{ ec.x - eyeR*0.7f, ec.y },
                       Vector2{ ec.x + eyeR*0.7f, ec.y },
                       eyeR * 0.26f, fade(kPupil));
        }
    }

    // --- Studio name ------------------------------------------------------
    // Rises and fades in during Settle, holds, then fades with everything.
    float nameA = 0.0f;
    if (phase_ == Phase::Settle)
        nameA = easeOutCubic(Clamp(time_ / (kSettle * 0.8f), 0.0f, 1.0f));
    else if (phase_ == Phase::Hold)   nameA = 1.0f;
    else if (phase_ == Phase::FadeOut) nameA = alpha;

    if (nameA > 0.001f) {
        float rise = (1.0f - nameA) * 24.0f;
        int nameY = (int)(cy + R + 70.0f + rise);
        Color ink = Color{ 28, 26, 34,
            (unsigned char)(255 * nameA) };
        Color sub = Color{ 90, 86, 98,
            (unsigned char)(255 * nameA) };
        // Big wordmark + smaller "STUDIOS" under it.
        const char* big = "SHPOINGLE";
        int bs = 56;
        int bw = MeasureText(big, bs);
        DrawText(big, (int)cx - bw/2, nameY, bs, ink);
        const char* sm = "S T U D I O S";
        int ss = 26;
        int sw = MeasureText(sm, ss);
        DrawText(sm, (int)cx - sw/2, nameY + bs + 6, ss, sub);
    }

    // A faint "press any key to skip" once we're past the bounce.
    if (phase_ != Phase::BounceIn && phase_ != Phase::FadeOut) {
        const char* skip = "press any key";
        int sw = MeasureText(skip, 16);
        DrawText(skip, ctx.screenW - sw - 28, ctx.screenH - 34, 16,
                 Color{ 150, 146, 140, 160 });
    }
}
