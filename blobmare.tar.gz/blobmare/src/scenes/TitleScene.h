#pragma once
// The title screen: a slow, moody shot of a single blob in a dark hallway,
// the BLOBMARE logo, and a pulsing prompt. Any input advances to the menu.
#include "game/Scene.h"
#include "blob/Blob.h"

class TitleScene : public Scene {
public:
    void enter(GameContext& ctx, SceneManager& mgr) override;
    void update(GameContext& ctx, SceneManager& mgr, float dt) override;
    void draw(GameContext& ctx) override;

private:
    Blob  blob_;
    float time_ = 0.0f;
    float accum_ = 0.0f;
};
