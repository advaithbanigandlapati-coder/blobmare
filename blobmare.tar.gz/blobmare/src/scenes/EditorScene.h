#pragma once
// =============================================================================
//  EditorScene — the character editor: build your blob's limbs
// =============================================================================
//
//  A blob sits in the centre of the screen. The player builds its arms and
//  legs by DRAGGING limbs out of the body:
//
//    * Press on the body surface  -> a new limb starts at that point.
//    * Drag outward               -> the limb extends; drag distance = length,
//                                     drag direction = where the limb sticks.
//    * Release                    -> the limb is committed.
//
//  An existing limb can be picked up by its tip and re-dragged, or deleted.
//  A side panel shows limb count, the arm/leg toggle for the selected limb,
//  thickness, and Save / Reset / Done.
//
//  The result is a LimbLoadout, written into ctx.config.playerLimbs[player]
//  so the player's custom "abomination" carries into every match.
//
//  CONTROLS
//    Mouse: drag on the body to add a limb; drag a tip to reshape; click a
//           panel button to act. Right-drag orbits the camera.
//    Keyboard fallback: arrows move a cursor, Space adds/grabs, Tab cycles
//           limbs, Del removes, Enter saves.
//
#include "game/Scene.h"
#include "blob/Blob.h"
#include "blob/BlobLimbs.h"
#include <vector>

class EditorScene : public Scene {
public:
    void enter(GameContext& ctx, SceneManager& mgr) override;
    void exit(GameContext& ctx) override;
    void update(GameContext& ctx, SceneManager& mgr, float dt) override;
    void draw(GameContext& ctx) override;

private:
    enum class Drag { None, NewLimb, MoveTip };

    Blob        preview_;          // the blob being edited (display only)
    LimbLoadout loadout_;          // the loadout under construction
    int         editPlayer_ = 0;   // which player's character we're editing

    // Camera orbit.
    float camYaw_   = 0.6f;
    float camPitch_ = 0.32f;
    float camDist_  = 5.6f;
    Camera3D cam_{};

    // Interaction state.
    Drag    drag_ = Drag::None;
    int     dragLimb_ = -1;        // index of the limb being created/edited
    int     selected_ = -1;        // currently selected limb (panel target)
    float   time_ = 0.0f;
    bool    orbiting_ = false;
    bool    wantExit_ = false;     // set by the Done button
    Vector2 lastMouse_{0,0};

    // Build the orbit camera from yaw/pitch/dist.
    void updateCamera();
    // Ray-pick the body sphere; returns true + the hit point + its local dir.
    bool pickBody(GameContext& ctx, Vector3& hitLocal) const;
    // Ray-pick a limb tip; returns the limb index or -1.
    int  pickTip(GameContext& ctx) const;
    // Apply loadout_ to the preview blob.
    void applyLoadout();
    // Commit loadout_ into ctx.config for the edited player.
    void save(GameContext& ctx);

    void drawPanel(GameContext& ctx);
};
