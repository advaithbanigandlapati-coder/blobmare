#include "scenes/MenuScene.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "render/Mascot.h"
#include "game/MinigameRegistry.h"
#include "raylib.h"
#include <cmath>
#include <algorithm>

namespace {
// A springy ease — overshoots then settles, the core of "juice".
float popEase(float t) {
    if (t <= 0.0f) return 0.0f;
    if (t >= 1.0f) return 1.0f;
    return 1.0f + 2.70158f * std::pow(t - 1.0f, 3.0f)
                + 1.70158f * std::pow(t - 1.0f, 2.0f);
}
}

void MenuScene::enter(GameContext& ctx, SceneManager& mgr) {
    (void)mgr;
    time_ = 0.0f;
    row_  = (int)Row::Start;
    showHelp_ = false;
    for (auto& p : pop_) p = 0.0f;

    // Scatter some soft drifting background blobs in candy colours.
    drifters_.clear();
    Color tints[] = { ui::candy::grape(), ui::candy::mint(),
                      ui::candy::coral(), ui::candy::sun() };
    for (int i = 0; i < 9; ++i) {
        Drifter d;
        d.x = (float)GetRandomValue(0, ctx.screenW);
        d.y = (float)GetRandomValue(0, ctx.screenH);
        d.r = (float)GetRandomValue(60, 190);
        d.speed = (float)GetRandomValue(8, 24);
        d.phase = (float)GetRandomValue(0, 628) / 100.0f;
        d.tint  = tints[i % 4];
        drifters_.push_back(d);
    }
    mascotX_ = ctx.screenW * 0.16f;
    mascotBounce_ = 0.0f;
    ctx.audio.setMusic(Audio::Music::Hub);
}

void MenuScene::update(GameContext& ctx, SceneManager& mgr, float dt) {
    time_ += dt;
    Input& in = ctx.input;

    // Ease each row's pop toward its hover state.
    for (int i = 0; i < (int)Row::COUNT; ++i) {
        float target = (i == row_) ? 1.0f : 0.0f;
        pop_[i] += (target - pop_[i]) * std::min(1.0f, dt * 14.0f);
    }
    // Mascot strolls along the bottom, bouncing.
    mascotX_ += dt * 46.0f;
    if (mascotX_ > ctx.screenW + 80.0f) mascotX_ = -80.0f;
    mascotBounce_ = std::fabs(std::sin(time_ * 4.2f));

    if (showHelp_) {
        if (in.cancelPressed() || in.confirmPressed()) {
            ctx.audio.play(Sfx::UiBack);
            showHelp_ = false;
        }
        return;
    }

    int dy = in.navY();
    if (dy != 0) {
        row_ = (row_ + dy + (int)Row::COUNT) % (int)Row::COUNT;
        ctx.audio.play(Sfx::UiMove);
    }

    int dx = in.navX();
    if (dx != 0) {
        if (row_ == (int)Row::Rounds) {
            ctx.config.roundsToWin =
                std::clamp(ctx.config.roundsToWin + dx, 1, 9);
            ctx.audio.play(Sfx::UiMove);
        } else if (row_ == (int)Row::Minigames) {
            ctx.config.minigameCount =
                std::clamp(ctx.config.minigameCount + dx, 1, 9);
            ctx.audio.play(Sfx::UiMove);
        }
    }

    if (in.confirmPressed()) {
        switch ((Row)row_) {
            case Row::Start:
                ctx.audio.play(Sfx::UiSelect);
                mgr.requestSwitch(SceneId::Lobby);
                break;
            case Row::Editor:
                ctx.audio.play(Sfx::UiSelect);
                mgr.requestSwitch(SceneId::Editor);
                break;
            case Row::HowToPlay:
                ctx.audio.play(Sfx::UiSelect);
                showHelp_ = true;
                break;
            case Row::Quit:
                ctx.audio.play(Sfx::UiBack);
                mgr.requestSwitch(SceneId::Quit);
                break;
            default: break;
        }
    }
    if (in.cancelPressed()) {
        ctx.audio.play(Sfx::UiBack);
        mgr.requestSwitch(SceneId::Title);
    }
}

// --- Background -------------------------------------------------------------

void MenuScene::drawBackground(GameContext& ctx) {
    // Vertical sky gradient.
    DrawRectangleGradientV(0, 0, ctx.screenW, ctx.screenH,
                           ui::candy::skyTop(), ui::candy::sky());
    // Soft drifting blobs — low alpha so they read as gentle background shapes.
    for (auto& d : drifters_) {
        float y = d.y + std::sin(time_ * 0.3f + d.phase) * 24.0f;
        float x = d.x + std::cos(time_ * 0.22f + d.phase) * 30.0f;
        Color c = d.tint; c.a = 46;
        DrawCircle((int)x, (int)y, d.r, c);
        c.a = 28;
        DrawCircle((int)x, (int)y, d.r * 1.35f, c);
    }
    // A bright ground band at the bottom.
    float gy = ctx.screenH * 0.84f;
    DrawRectangleGradientV(0, (int)gy, ctx.screenW,
                           ctx.screenH - (int)gy,
                           Color{120,210,150,255}, Color{96,188,128,255});
}

// --- Draw -------------------------------------------------------------------

void MenuScene::draw(GameContext& ctx) {
    drawBackground(ctx);
    int cx = ctx.screenW / 2;

    // --- Logo: a big, bouncy, candy wordmark --------------------------------
    float logoBob = std::sin(time_ * 2.2f) * 8.0f;
    float logoSquash = 1.0f + std::sin(time_ * 2.2f) * 0.03f;
    const char* title = "BLOBMARE";
    int ts = 96;
    int tw = MeasureText(title, ts);
    int lx = cx - tw / 2;
    int ly = (int)(72 + logoBob);
    // Chunky multi-layer drop shadow for a thick sticker look.
    for (int s = 8; s >= 1; --s) {
        DrawText(title, lx + s/2, ly + s, ts,
                 Color{ 34, 30, 54, (unsigned char)(180 - s*14) });
    }
    DrawText(title, lx, ly, ts, ui::candy::sun());
    // Bright top-edge highlight.
    DrawText(title, lx, ly - 3, ts, Color{255,236,180,90});
    (void)logoSquash;

    // --- Menu rows ---------------------------------------------------------
    struct RowDef { Row r; const char* label; bool slider; };
    const RowDef rows[] = {
        { Row::Rounds,    "Rounds to win",      true  },
        { Row::Minigames, "Minigames / match",  true  },
        { Row::Start,     "PLAY",               false },
        { Row::Editor,    "Character Editor",   false },
        { Row::HowToPlay, "How to Play",        false },
        { Row::Quit,      "Quit",               false },
    };

    const int baseY = 248;
    const int rowH  = 72;
    const float panelW = 560.0f;

    for (const auto& rd : rows) {
        int idx = (int)rd.r;
        float pop = popEase(pop_[idx]);
        int y = baseY + idx * rowH;
        bool sel = (row_ == idx);

        // The selected row swells and lifts; "PLAY" is always the biggest.
        float scale = 1.0f + pop * 0.06f + (rd.r == Row::Start ? 0.10f : 0.0f);
        float w = panelW * scale;
        float h = 58.0f * scale;
        float bx = cx - w / 2;
        float by = y - (h - 58.0f) / 2.0f;
        Rectangle box{ bx, by, w, h };

        // Button colour: PLAY is sunny, others cream; selected pops brighter.
        Color fill = (rd.r == Row::Start) ? ui::candy::sun()
                                          : ui::candy::cream();
        if (sel) {
            fill.r = (unsigned char)std::min(255, fill.r + 18);
            fill.g = (unsigned char)std::min(255, fill.g + 18);
            fill.b = (unsigned char)std::min(255, fill.b + 10);
        }
        // Chunky shadow under the button.
        Rectangle shadow = box;
        shadow.y += 7.0f + pop * 3.0f;
        DrawRectangleRounded(shadow, 0.5f, 8, ui::candy::shade());
        // The button itself.
        DrawRectangleRounded(box, 0.5f, 8, fill);
        // Bright inner top highlight.
        Rectangle hi{ box.x + 10, box.y + 6, box.width - 20, box.height*0.34f };
        DrawRectangleRounded(hi, 0.7f, 6, Color{255,255,255,70});
        // Selected outline.
        if (sel) {
            DrawRectangleRoundedLines(box, 0.5f, 8,
                                      ui::candy::ink());
        }

        // Label.
        int fs = (rd.r == Row::Start) ? 38 : 30;
        fs = (int)(fs * scale);
        Color textC = ui::candy::ink();
        int labW = MeasureText(rd.label, fs);
        int labX = rd.slider ? (int)(bx + 28)
                             : (int)(cx - labW / 2);
        int labY = (int)(by + h/2 - fs/2);
        DrawText(rd.label, labX, labY, fs, textC);

        // Slider value + arrows.
        if (rd.slider) {
            int val = (rd.r == Row::Rounds) ? ctx.config.roundsToWin
                                            : ctx.config.minigameCount;
            const char* vs = TextFormat("%d", val);
            int vw = MeasureText(vs, fs);
            int vx = (int)(bx + w - 64);
            DrawText(vs, vx - vw/2, labY, fs, ui::candy::grape());
            if (sel) {
                DrawText("<", vx - 44, labY, fs, ui::candy::coral());
                DrawText(">", vx + 28, labY, fs, ui::candy::coral());
            }
        } else if (sel) {
            // A little arrow pointer on the selected action row.
            DrawText(">", (int)(bx + 22), labY, fs, ui::candy::coral());
        }
    }

    // --- Mascot strolling the ground band ----------------------------------
    float groundY = ctx.screenH * 0.84f;
    float hop = mascotBounce_ * 26.0f;
    mascot::draw(mascotX_, groundY - 26.0f - hop, 34.0f, time_,
                 1.0f - mascotBounce_ * 0.12f, 1.0f);

    // --- Footer ------------------------------------------------------------
    const char* pool = TextFormat("%d minigames  -  %d drawn per match",
                                   MinigameRegistry::instance().count(),
                                   ctx.config.minigameCount);
    int pw = MeasureText(pool, 18);
    DrawText(pool, cx - pw/2, ctx.screenH - 30, 18,
             Color{ 40, 36, 60, 180 });

    if (showHelp_) drawHelp(ctx);
}

// --- How-to-play overlay ----------------------------------------------------

void MenuScene::drawHelp(GameContext& ctx) {
    DrawRectangle(0, 0, ctx.screenW, ctx.screenH, Color{34,30,54,180});
    int cx = ctx.screenW / 2;
    Rectangle box{ cx - 360.0f, 130.0f, 720.0f, 440.0f };
    DrawRectangleRounded(box, 0.12f, 10, ui::candy::cream());
    DrawRectangleRoundedLines(box, 0.12f, 10, ui::candy::grape());

    ui::centerText("HOW TO PLAY", cx, 165, 38, ui::candy::grape());

    const char* lines[] = {
        "Two blobs. A hallway of doors. A random slate of minigames.",
        "First blob to the round target survives the Blobmare.",
        "",
        "Player 1:  W A S D move   -   Space jump   -   J action   -   Shift dash",
        "Player 2:  Arrow keys, or a gamepad (auto-detected)",
        "",
        "Esc pauses.  Build your own creature in the Character Editor.",
    };
    int ly = 230;
    for (const char* ln : lines) {
        int lw = MeasureText(ln, 20);
        DrawText(ln, cx - lw/2, ly, 20, ui::candy::ink());
        ly += 34;
    }
    ui::centerText("press any key to go back", cx, 540, 18,
                   Color{120,110,140,255});
}
