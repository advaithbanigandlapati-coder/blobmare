#include "scenes/TitleScene.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "physics/World.h"
#include "render/Prims.h"
#include "raymath.h"
#include <cmath>
#include <vector>

namespace {
constexpr float kFixed = 1.0f / 120.0f;   // physics step
}

void TitleScene::enter(GameContext& ctx, SceneManager& mgr) {
    (void)mgr;
    blob_.init(0, ctx.config.playerColor[0], 0.0f);
    blob_.respawn(Vector3{ 0.0f, 1.4f, 0.0f });
    blob_.setEmote(Emote::Neutral);
    time_ = 0.0f;
    ctx.audio.setMusic(Audio::Music::Hub);
    ctx.audio.play(Sfx::Powerup, 0.6f);

    ctx.camera.init();
    ctx.camera.setStaticShot(Vector3{ 3.2f, 3.0f, 7.5f },
                             Vector3{ 0.0f, 1.2f, 0.0f });
    ctx.camera.snap();
}

void TitleScene::update(GameContext& ctx, SceneManager& mgr, float dt) {
    time_ += dt;

    // Fixed-step the idle blob so it has a tiny living wobble.
    accum_ += dt;
    int steps = 0;
    while (accum_ >= kFixed && steps < 8) {
        // Make the title blob hop occasionally for character.
        PlayerInput idle{};
        if (std::fmod(time_, 2.6f) < kFixed) idle.jumpPressed = idle.jump = true;
        blob_.control(idle, kFixed, true, true);
        // No real world; fake a ground at y=0.
        World w; w.setGround(0.0f); w.setGravity(Vector3{0,-24,0});
        blob_.integrate(w, kFixed);
        accum_ -= kFixed;
        ++steps;
    }

    ctx.shake.update(dt);
    ctx.camera.update(dt, ctx.shake);

    if (ctx.input.anyActionPressed() || ctx.input.confirmPressed()) {
        ctx.audio.play(Sfx::UiSelect);
        mgr.requestSwitch(SceneId::Menu);
    }
}

void TitleScene::draw(GameContext& ctx) {
    // Bright candy sky instead of the dim void.
    DrawRectangleGradientV(0, 0, ctx.screenW, ctx.screenH,
                           ui::candy::skyTop(), ui::candy::sky());

    BeginMode3D(ctx.camera.cam());
    {
        // A short stretch of hallway floor and a couple of doorways — lifted
        // to brighter, friendlier tones.
        prims::groundGrid(Vector3{0,0,0}, 16.0f, 1.0f, Color{180,210,235,160});
        prims::checkerFloor(Vector3{0,-0.06f,0}, 4.0f, 1.0f,
                            Color{120,170,210,255}, Color{150,195,230,255});
        for (int i = -1; i <= 1; i += 2) {
            prims::doorway(Vector3{ i * 3.4f, 0.0f, -2.0f }, 2.0f, 3.0f,
                           Color{160,130,225,255}, Color{120,95,195,255});
        }
        prims::pillar(Vector3{ -4.5f, 0.0f, 1.0f }, 0.4f, 4.0f,
                      Color{110,205,160,255});
        prims::pillar(Vector3{  4.5f, 0.0f, 1.0f }, 0.4f, 4.0f,
                      Color{110,205,160,255});

        ctx.lighting.setCamera(ctx.camera.eye());
        blob_.draw(ctx.lighting, 1.0f);

        ctx.lighting.begin();
        ctx.particles.draw();
        ctx.lighting.end();
    }
    EndMode3D();

    // --- Title text -------------------------------------------------------
    int cx = ctx.screenW / 2;
    float bob = std::sin(time_ * 2.0f) * 8.0f;

    // Chunky candy wordmark with a thick layered shadow.
    const char* logo = "BLOBMARE";
    int logoSize = 100;
    int lw = MeasureText(logo, logoSize);
    int lx = cx - lw/2;
    int ly = 86 + (int)bob;
    for (int s = 9; s >= 1; --s) {
        DrawText(logo, lx + s/2, ly + s, logoSize,
                 Color{ 34, 30, 54, (unsigned char)(170 - s*12) });
    }
    DrawText(logo, lx, ly, logoSize, ui::candy::sun());
    DrawText(logo, lx, ly - 3, logoSize, Color{255,236,180,90});

    // Tagline on a little rounded ribbon.
    const char* tag = "a blob party nightmare";
    int tagW = MeasureText(tag, 26);
    Rectangle ribbon{ (float)(cx - tagW/2 - 22), (float)(200 + bob),
                      (float)(tagW + 44), 42.0f };
    DrawRectangleRounded(ribbon, 0.6f, 6, ui::candy::grape());
    DrawText(tag, cx - tagW/2, (int)(208 + bob), 26, ui::candy::cream());

    // Bouncy prompt pill near the bottom.
    float p = ui::pulse(3.0f);
    const char* prompt = "press  SPACE  /  ENTER  /  any button";
    int pw = MeasureText(prompt, 24);
    float pscale = 1.0f + p * 0.05f;
    int ppx = (int)(cx - pw*pscale/2);
    int ppy = ctx.screenH - 150;
    Rectangle pill{ (float)(ppx - 26), (float)(ppy - 12),
                    (float)(pw*pscale + 52), 52.0f };
    Color pillC = ui::candy::cream();
    pillC.a = (unsigned char)(200 + 55 * p);
    DrawRectangleRounded(pill, 0.7f, 8, pillC);
    DrawText(prompt, ppx, ppy, (int)(24*pscale), ui::candy::ink());

    const char* studio = "a Shpoingle Studios game";
    int sw = MeasureText(studio, 18);
    DrawText(studio, cx - sw/2, ctx.screenH - 44, 18,
             Color{ 40, 36, 60, 170 });
}
