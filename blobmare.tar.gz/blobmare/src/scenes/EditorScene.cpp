#include "scenes/EditorScene.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "render/Prims.h"
#include "raymath.h"
#include "rlgl.h"
#include <cmath>
#include <algorithm>

namespace {
constexpr float kBodyRadius = 1.0f;       // preview blob radius (display)
const Vector3   kBodyPos    = { 0, 1.2f, 0 };
constexpr int   kPanelW     = 300;
}

// --- Lifecycle --------------------------------------------------------------

void EditorScene::enter(GameContext& ctx, SceneManager& mgr) {
    (void)mgr;
    editPlayer_ = 0;
    time_ = 0.0f;
    drag_ = Drag::None;
    dragLimb_ = -1;
    selected_ = -1;

    // Start from the player's existing custom loadout, or the default critter.
    if (ctx.config.playerLimbsCustom[editPlayer_])
        loadout_ = ctx.config.playerLimbs[editPlayer_];
    else
        loadout_ = LimbLoadout::defaultCritter();

    preview_.init(0, ctx.config.playerColor[editPlayer_], 0.0f);
    preview_.respawn(kBodyPos);
    applyLoadout();

    camYaw_ = 0.6f; camPitch_ = 0.32f; camDist_ = 5.6f;
    updateCamera();
    ctx.audio.setMusic(Audio::Music::Hub);
}

void EditorScene::exit(GameContext& ctx) { (void)ctx; }

void EditorScene::applyLoadout() {
    preview_.setLimbs(loadout_);
    // Settle the springs so the preview shows the rest pose immediately.
    for (int i = 0; i < 120; ++i)
        preview_.limbs().update(kBodyPos, Vector3{0,0,0}, Vector3{0,0,0},
                                Vector3{0,0,1}, kBodyRadius, true, 1.0f/120);
}

void EditorScene::save(GameContext& ctx) {
    ctx.config.playerLimbs[editPlayer_] = loadout_;
    ctx.config.playerLimbsCustom[editPlayer_] = true;
    ctx.audio.play(Sfx::Powerup);
}

// --- Camera -----------------------------------------------------------------

void EditorScene::updateCamera() {
    float cp = std::cos(camPitch_), sp = std::sin(camPitch_);
    float cy = std::cos(camYaw_),   sy = std::sin(camYaw_);
    cam_.position = Vector3{
        kBodyPos.x + camDist_ * cp * sy,
        kBodyPos.y + camDist_ * sp,
        kBodyPos.z + camDist_ * cp * cy };
    cam_.target = kBodyPos;
    cam_.up = Vector3{0,1,0};
    cam_.fovy = 46.0f;
    cam_.projection = CAMERA_PERSPECTIVE;
}

// --- Picking ----------------------------------------------------------------

bool EditorScene::pickBody(GameContext& ctx, Vector3& hitLocal) const {
    Vector2 m = GetMousePosition();
    if (m.x > ctx.screenW - kPanelW) return false;     // over the panel
    Ray ray = GetMouseRay(m, cam_);
    RayCollision rc = GetRayCollisionSphere(ray, kBodyPos, kBodyRadius);
    if (!rc.hit) return false;
    // Local direction = surface normal in the blob's local space. The preview
    // blob faces +Z and is not rotated, so world == local here.
    hitLocal = Vector3Normalize(Vector3Subtract(rc.point, kBodyPos));
    return true;
}

int EditorScene::pickTip(GameContext& ctx) const {
    Vector2 m = GetMousePosition();
    if (m.x > ctx.screenW - kPanelW) return -1;
    Ray ray = GetMouseRay(m, cam_);
    int best = -1; float bestDist = 1e30f;
    const auto& L = preview_.limbs();
    for (size_t i = 0; i < L.loadout().limbs.size(); ++i) {
        // Tip world position: re-derive from the limb config rest geometry.
        const LimbConfig& c = L.loadout().limbs[i];
        Vector3 a = Vector3Normalize(c.attach);
        Vector3 root = Vector3Add(kBodyPos, Vector3Scale(a, kBodyRadius*0.92f));
        Vector3 down = Vector3{0,-1,0};
        Vector3 hang = (c.kind == LimbKind::Leg)
            ? Vector3Normalize(Vector3Add(down, Vector3Scale(a, 0.25f)))
            : Vector3Normalize(Vector3Add(down, Vector3Scale(a, 0.7f)));
        Vector3 tip = Vector3Add(root, Vector3Scale(hang, c.length));
        RayCollision rc = GetRayCollisionSphere(ray, tip, c.thickness * 2.0f);
        if (rc.hit && rc.distance < bestDist) { bestDist = rc.distance; best = (int)i; }
    }
    return best;
}

// --- Update -----------------------------------------------------------------

void EditorScene::update(GameContext& ctx, SceneManager& mgr, float dt) {
    time_ += dt;

    // --- Camera orbit (right mouse drag) ---
    if (IsMouseButtonPressed(MOUSE_BUTTON_RIGHT)) {
        orbiting_ = true; lastMouse_ = GetMousePosition();
    }
    if (IsMouseButtonReleased(MOUSE_BUTTON_RIGHT)) orbiting_ = false;
    if (orbiting_) {
        Vector2 m = GetMousePosition();
        camYaw_   -= (m.x - lastMouse_.x) * 0.008f;
        camPitch_ += (m.y - lastMouse_.y) * 0.008f;
        camPitch_ = std::clamp(camPitch_, -0.4f, 1.3f);
        lastMouse_ = m;
    }
    float wheel = GetMouseWheelMove();
    if (wheel != 0.0f) camDist_ = std::clamp(camDist_ - wheel * 0.4f, 3.5f, 9.0f);
    updateCamera();

    // --- Limb drag interaction (left mouse) ---
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
        int tip = pickTip(ctx);
        Vector3 hitLocal;
        if (tip >= 0) {
            // Grab an existing limb's tip to reshape it.
            drag_ = Drag::MoveTip;
            dragLimb_ = tip;
            selected_ = tip;
            ctx.audio.play(Sfx::UiSelect);
        } else if (pickBody(ctx, hitLocal)) {
            // Start a brand-new limb at the clicked surface point.
            if (loadout_.limbs.size() < 8) {
                LimbConfig c;
                c.kind = LimbKind::Arm;
                c.attach = hitLocal;
                c.length = 0.5f;
                c.thickness = 0.14f;
                loadout_.limbs.push_back(c);
                drag_ = Drag::NewLimb;
                dragLimb_ = (int)loadout_.limbs.size() - 1;
                selected_ = dragLimb_;
                applyLoadout();
                ctx.audio.play(Sfx::UiSelect);
            }
        }
    }

    if (drag_ != Drag::None && dragLimb_ >= 0 &&
        dragLimb_ < (int)loadout_.limbs.size()) {
        // While dragging, re-pick the body: the attach point follows the
        // cursor across the surface, and length grows with how far past the
        // body edge the cursor is pulled.
        Vector3 hitLocal;
        LimbConfig& c = loadout_.limbs[dragLimb_];
        if (pickBody(ctx, hitLocal)) {
            c.attach = hitLocal;
        } else {
            // Cursor left the body — project onto the body silhouette and use
            // the distance from the body centre on screen to set length.
            Vector2 m = GetMousePosition();
            Vector2 centre = GetWorldToScreen(kBodyPos, cam_);
            float pix = Vector2Distance(m, centre);
            // Map screen distance to limb length (0.5 .. 2.2).
            c.length = std::clamp(0.5f + (pix - 60.0f) / 120.0f, 0.5f, 2.2f);
        }
        applyLoadout();
    }

    if (IsMouseButtonReleased(MOUSE_BUTTON_LEFT)) {
        if (drag_ == Drag::NewLimb && dragLimb_ >= 0) {
            // A limb barely dragged out is a misclick — discard tiny stubs.
            if (loadout_.limbs[dragLimb_].length < 0.55f) {
                loadout_.limbs.erase(loadout_.limbs.begin() + dragLimb_);
                if (selected_ == dragLimb_) selected_ = -1;
                applyLoadout();
            }
        }
        drag_ = Drag::None;
        dragLimb_ = -1;
    }

    // --- Keyboard shortcuts ---
    if (IsKeyPressed(KEY_TAB) && !loadout_.limbs.empty()) {
        selected_ = (selected_ + 1) % (int)loadout_.limbs.size();
        ctx.audio.play(Sfx::UiMove);
    }
    if ((IsKeyPressed(KEY_DELETE) || IsKeyPressed(KEY_BACKSPACE)) &&
        selected_ >= 0 && selected_ < (int)loadout_.limbs.size()) {
        loadout_.limbs.erase(loadout_.limbs.begin() + selected_);
        selected_ = -1;
        applyLoadout();
        ctx.audio.play(Sfx::UiBack);
    }
    // Toggle arm/leg on the selected limb.
    if (IsKeyPressed(KEY_T) && selected_ >= 0 &&
        selected_ < (int)loadout_.limbs.size()) {
        LimbConfig& c = loadout_.limbs[selected_];
        c.kind = (c.kind == LimbKind::Arm) ? LimbKind::Leg : LimbKind::Arm;
        applyLoadout();
        ctx.audio.play(Sfx::UiSelect);
    }
    if (IsKeyPressed(KEY_ENTER)) { save(ctx); }
    if (IsKeyPressed(KEY_ESCAPE) || wantExit_) {
        ctx.audio.play(Sfx::UiBack);
        mgr.requestSwitch(SceneId::Menu);
    }

    // Idle wobble so the preview feels alive.
    preview_.limbs().update(kBodyPos, Vector3{0,0,0},
        Vector3{ std::sin(time_*2.0f)*1.5f, 0, 0 },
        Vector3{0,0,1}, kBodyRadius, true, dt);
}

// --- Draw -------------------------------------------------------------------

void EditorScene::draw(GameContext& ctx) {
    ClearBackground(ui::bg());

    ctx.lighting.setCamera(cam_.position);
    ctx.lighting.setShadowFocus(kBodyPos, 8.0f);
    ctx.lighting.beginShadowPass();
    if (ctx.lighting.shadowsActive()) {
        ctx.lighting.begin();
        prims::platform(Vector3{0,0,0}, 9, 9, 0.4f,
                        Color{52,50,68,255}, Color{72,70,90,255});
        ctx.lighting.end();
        preview_.draw(ctx.lighting, 1.0f);
    }
    ctx.lighting.endShadowPass();

    BeginMode3D(cam_);
    ctx.lighting.begin();
    prims::platform(Vector3{0,0,0}, 9, 9, 0.4f,
                    Color{52,50,68,255}, Color{72,70,90,255});
    ctx.lighting.end();

    preview_.draw(ctx.lighting, 1.0f);

    // Highlight the selected limb's tip with a ring.
    if (selected_ >= 0 && selected_ < (int)loadout_.limbs.size()) {
        const LimbConfig& c = loadout_.limbs[selected_];
        Vector3 a = Vector3Normalize(c.attach);
        Vector3 root = Vector3Add(kBodyPos, Vector3Scale(a, kBodyRadius*0.92f));
        Vector3 down = Vector3{0,-1,0};
        Vector3 hang = (c.kind == LimbKind::Leg)
            ? Vector3Normalize(Vector3Add(down, Vector3Scale(a, 0.25f)))
            : Vector3Normalize(Vector3Add(down, Vector3Scale(a, 0.7f)));
        Vector3 tip = Vector3Add(root, Vector3Scale(hang, c.length));
        DrawSphereWires(tip, c.thickness * 2.4f, 8, 8, ui::accent());
    }
    EndMode3D();

    // --- 2D overlay -------------------------------------------------------
    ui::centerTextShadow("CHARACTER EDITOR", ctx.screenW/2 - kPanelW/2, 36,
                         40, ui::accent());
    ui::centerText("drag limbs out of the body  -  right-drag to orbit",
                   ctx.screenW/2 - kPanelW/2, 80, 18, ui::inkDim());

    drawPanel(ctx);
}

void EditorScene::drawPanel(GameContext& ctx) {
    int px = ctx.screenW - kPanelW;
    Rectangle panel{ (float)px, 0, (float)kPanelW, (float)ctx.screenH };
    DrawRectangleRec(panel, ui::panel());
    DrawLine(px, 0, px, ctx.screenH, ui::accent());

    int x = px + 24;
    int y = 40;
    DrawText("YOUR ABOMINATION", x, y, 22, ui::accent()); y += 40;
    DrawText(TextFormat("limbs: %d / 8", (int)loadout_.limbs.size()),
             x, y, 20, ui::ink()); y += 36;

    // Per-limb list.
    for (size_t i = 0; i < loadout_.limbs.size(); ++i) {
        const LimbConfig& c = loadout_.limbs[i];
        bool sel = ((int)i == selected_);
        Rectangle row{ (float)x - 8, (float)y - 4, (float)kPanelW - 32, 30 };
        if (sel) DrawRectangleRec(row, Color{255,196,92,40});
        const char* kind = (c.kind == LimbKind::Arm) ? "arm" : "leg";
        DrawText(TextFormat("%s %d   len %.1f", kind, (int)i+1, c.length),
                 x, y, 18, sel ? ui::accent() : ui::inkDim());
        y += 32;
    }
    y += 12;

    // Controls help.
    DrawText("- click+drag body: new limb", x, y, 15, ui::inkDim()); y += 22;
    DrawText("- drag a tip: reshape it",     x, y, 15, ui::inkDim()); y += 22;
    DrawText("- Tab: select   T: arm/leg",   x, y, 15, ui::inkDim()); y += 22;
    DrawText("- Del: remove selected limb",  x, y, 15, ui::inkDim()); y += 34;

    // Buttons.
    auto button = [&](const char* label, int by, Color tint) -> bool {
        Rectangle b{ (float)x - 8, (float)by, (float)kPanelW - 32, 44 };
        Vector2 m = GetMousePosition();
        bool hover = CheckCollisionPointRec(m, b);
        DrawRectangleRounded(b, 0.3f, 6,
            hover ? tint : Color{(unsigned char)(tint.r*0.5f),
                                 (unsigned char)(tint.g*0.5f),
                                 (unsigned char)(tint.b*0.5f),255});
        int tw = MeasureText(label, 20);
        DrawText(label, (int)(b.x + b.width/2 - tw/2), by + 12, 20, ui::bg());
        return hover && IsMouseButtonPressed(MOUSE_BUTTON_LEFT);
    };

    if (button("SAVE CHARACTER", y, ui::accent())) save(ctx);
    y += 56;
    if (button("RESET TO DEFAULT", y, ui::accent2())) {
        loadout_ = LimbLoadout::defaultCritter();
        selected_ = -1;
        applyLoadout();
        ctx.audio.play(Sfx::UiBack);
    }
    y += 56;
    if (button("DONE", y, Color{160,220,160,255})) {
        save(ctx);
        wantExit_ = true;
    }

    // Saved confirmation.
    if (ctx.config.playerLimbsCustom[editPlayer_]) {
        DrawText("custom character saved", x, ctx.screenH - 40, 15,
                 Color{160,220,160,255});
    }
}
