#pragma once
// The menu — the bright, bouncy front-of-house screen. Choose match options,
// open the editor, start a match. Styled in the candy palette with a juicy
// hover-pop on the buttons and the soot-sprite mascot bouncing along.
#include "game/Scene.h"
#include <vector>

class MenuScene : public Scene {
public:
    void enter(GameContext& ctx, SceneManager& mgr) override;
    void update(GameContext& ctx, SceneManager& mgr, float dt) override;
    void draw(GameContext& ctx) override;

private:
    enum class Row { Rounds, Minigames, Start, Editor, HowToPlay, Quit, COUNT };
    int   row_ = (int)Row::Start;
    float time_ = 0.0f;
    bool  showHelp_ = false;

    // Per-row "pop" animation: eases to 1 when hovered, 0 otherwise.
    float pop_[(int)Row::COUNT] = {0};

    // Decorative background blobs that drift behind the menu.
    struct Drifter { float x, y, r, speed, phase; Color tint; };
    std::vector<Drifter> drifters_;

    // The mascot bounces along the bottom.
    float mascotX_ = 0.0f;
    float mascotBounce_ = 0.0f;

    void drawHelp(GameContext& ctx);
    void drawBackground(GameContext& ctx);
};
