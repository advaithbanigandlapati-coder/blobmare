#pragma once
// MatchScene runs exactly ONE minigame from the match slate:
//
//   Intro splash (name + how-to)  ->  3-2-1-GO countdown  ->  play
//   ->  win freeze  ->  award point  ->  back to the Hub.
//
// It owns the two player blobs, drives the fixed-step loop, applies hit-stop,
// renders the shared 3D pass, and lets the minigame draw its arena/HUD.
#include "game/Scene.h"
#include "game/Minigame.h"
#include "blob/Blob.h"
#include "ui/PauseMenu.h"
#include <memory>
#include <vector>

class MatchScene : public Scene {
public:
    void enter(GameContext& ctx, SceneManager& mgr) override;
    void exit(GameContext& ctx) override;
    void update(GameContext& ctx, SceneManager& mgr, float dt) override;
    void draw(GameContext& ctx) override;

private:
    enum class Phase { Intro, Countdown, Play, WinFreeze };

    std::unique_ptr<Minigame> game_;
    Blob   blobs_[2];
    std::vector<Blob*> blobPtrs_;

    Phase  phase_ = Phase::Intro;
    float  phaseTime_ = 0.0f;
    float  accum_ = 0.0f;
    int    countNumber_ = 3;
    int    lastCountShown_ = 99;
    MinigameResult result_{};
    float  hitStop_ = 0.0f;
    int    lastClockTick_ = -1;
    PauseMenu pause_;

    void stepSim(GameContext& ctx, float dt, bool inputEnabled);
    void resolveAndAdvance(GameContext& ctx);
    void drawCountdownHUD(GameContext& ctx);
    void drawIntroHUD(GameContext& ctx);
    void drawWinHUD(GameContext& ctx);
    void drawScoreHUD(GameContext& ctx);
};
