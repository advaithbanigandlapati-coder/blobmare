#pragma once
// =============================================================================
//  LobbyScene — choose how to play: local, or networked
// =============================================================================
//
//  Entry point to multiplayer. Modes:
//    * Local 2P            — couch co-op, no netcode (NetMode::Local)
//    * Networked (loopback)— full net path in-process; a netcode self-test
//    * Host Online         — bind a UDP port, wait for a client to connect
//    * Join Online         — enter a host IP, connect over UDP
//
//  For Host/Join Online the scene shows connection state and, for Join, a
//  simple IP text-entry field. Once the NetSession handshake completes it
//  hands off to the Hub exactly like the other modes.
//
//  TESTING NOTE: the UDP transport is localhost-verified. Cross-machine play
//  needs two machines — see docs/NETCODE.md.
//
#include "game/Scene.h"
#include <memory>
#include <string>

namespace net { class NetSession; }

class LobbyScene : public Scene {
public:
    void enter(GameContext& ctx, SceneManager& mgr) override;
    void exit(GameContext& ctx) override;
    void update(GameContext& ctx, SceneManager& mgr, float dt) override;
    void draw(GameContext& ctx) override;

private:
    enum class Row { LocalPlay, NetLoopback, HostOnline, JoinOnline, Back,
                     COUNT };
    enum class Phase {
        Choosing,     // picking a mode
        EnterIp,      // typing the host IP (Join Online only)
        Hosting,      // host: socket bound, waiting for a client
        Connecting,   // client/loopback: handshake in progress
        Ready,        // connected — brief beat before the Hub
        Failed        // connection error; shows a message
    };

    int    row_ = 0;
    Phase  phase_ = Phase::Choosing;
    float  time_ = 0.0f;
    float  connectTimer_ = 0.0f;
    std::string status_;
    std::string ipInput_ = "127.0.0.1";
    uint16_t port_ = 41730;

    // Sessions. For loopback, both are owned here. For UDP, only the local
    // session exists in this process.
    std::shared_ptr<net::NetSession> hostSession_;
    std::shared_ptr<net::NetSession> clientSession_;   // loopback only

    void onConfirm(GameContext& ctx, SceneManager& mgr);
    void startLoopbackSession(GameContext& ctx);
    void startUdpHost(GameContext& ctx);
    void startUdpJoin(GameContext& ctx);
    void pumpHandshake(GameContext& ctx, SceneManager& mgr, float dt);
    bool rowEnabled(Row r) const;
};
