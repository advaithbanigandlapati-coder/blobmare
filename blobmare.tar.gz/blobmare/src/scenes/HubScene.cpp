#include "scenes/HubScene.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "render/Prims.h"
#include "game/MinigameRegistry.h"
#include "raymath.h"
#include <cmath>
#include <algorithm>

namespace {
constexpr float kFixed = 1.0f / 120.0f;
constexpr float kHallHalfW = 4.0f;     // hallway is 8 units wide
constexpr float kHallStartZ = 6.0f;    // blobs spawn here
constexpr float kDoorZ      = -15.0f;  // active door sits here
}

void HubScene::buildHallway(GameContext& ctx) {
    world_.clear();
    world_.setGravity(Vector3{ 0, -26, 0 });
    world_.setGround(0.0f);
    world_.setKillY(-30.0f);

    // Side walls running the length of the corridor.
    float zFar = kDoorZ - 2.0f, zNear = kHallStartZ + 4.0f;
    float wallH = 6.0f, wallT = 0.6f;
    for (int s = -1; s <= 1; s += 2) {
        world_.addBox(phys::makeBox(
            Vector3{ s * (kHallHalfW + wallT * 0.5f), wallH * 0.5f,
                     (zFar + zNear) * 0.5f },
            Vector3{ wallT * 0.5f, wallH * 0.5f, (zNear - zFar) * 0.5f }));
    }
    // End wall behind the door.
    world_.addBox(phys::makeBox(
        Vector3{ 0, wallH * 0.5f, kDoorZ - 2.3f },
        Vector3{ kHallHalfW, wallH * 0.5f, 0.4f }));
    // Back wall behind spawn.
    world_.addBox(phys::makeBox(
        Vector3{ 0, wallH * 0.5f, zNear },
        Vector3{ kHallHalfW, wallH * 0.5f, 0.4f }));
    (void)ctx;
}

void HubScene::enter(GameContext& ctx, SceneManager& mgr) {
    (void)mgr;
    time_ = 0.0f;
    accum_ = 0.0f;
    triggered_ = false;
    triggerTimer_ = 0.0f;
    doorZ_ = kDoorZ;

    buildHallway(ctx);

    // If the match has no slate yet, this is the first hub visit: draw one.
    if (ctx.match.slate.empty()) {
        ctx.match.reset();
        ctx.match.seed = (uint64_t)GetTime() ^ ((uint64_t)GetRandomValue(1, 1<<30) << 21);
        ctx.match.slate = MinigameRegistry::instance()
                              .drawSlate(ctx.config.minigameCount, ctx.match.seed);
    }

    // Sudden death: the slate is spent but the score is tied. Append one more
    // minigame so the match always produces a winner — the spec's tiebreaker.
    if (ctx.match.needsTiebreaker()) {
        int reg = MinigameRegistry::instance().count();
        if (reg > 0) {
            // A fresh random pick, seeded off the round count so it varies.
            uint64_t tbSeed = ctx.match.seed ^ (0x71E5u + ctx.match.index);
            auto extra = MinigameRegistry::instance().drawSlate(1, tbSeed);
            if (!extra.empty()) {
                ctx.match.slate.push_back(extra[0]);
                ctx.match.isSuddenDeath = true;
            }
        }
    }

    matchDone_ = ctx.match.matchOver(ctx.config.roundsToWin);

    for (int i = 0; i < 2; ++i) {
        blobs_[i].init(i, ctx.config.playerColor[i], ctx.config.playerSize[i]);
        blobs_[i].respawn(Vector3{ (i == 0 ? -1.4f : 1.4f), 1.2f, kHallStartZ });
        blobs_[i].setEmote(Emote::Neutral);
    }

    ctx.camera.init();
    ctx.camera.setHeight(7.0f);
    ctx.camera.setDistance(11.0f);
    ctx.camera.setPitch(34.0f);
    ctx.camera.clearStaticShot();
    ctx.camera.setTargets({ blobs_[0].position(), blobs_[1].position() });
    ctx.camera.snap();

    ctx.audio.setMusic(Audio::Music::Hub);
    ctx.particles.clear();
}

void HubScene::stepSim(GameContext& ctx, float dt) {
    for (int i = 0; i < 2; ++i) {
        blobs_[i].control(ctx.input.player(i), dt, !triggered_, !triggered_);
        blobs_[i].integrate(world_, dt);
        // Keep blobs from wandering out the open door sideways.
        Vector3 p = blobs_[i].position();
        float lim = kHallHalfW - blobs_[i].radius() - 0.6f;
        if (p.x < -lim) { p.x = -lim; blobs_[i].setPosition(p); }
        if (p.x >  lim) { p.x =  lim; blobs_[i].setPosition(p); }
        // Re-spawn if somehow voided.
        if (!blobs_[i].alive()) {
            blobs_[i].respawn(Vector3{ (i==0?-1.4f:1.4f), 1.2f, kHallStartZ });
        }
    }
}

void HubScene::update(GameContext& ctx, SceneManager& mgr, float dt) {
    time_ += dt;

    if (ctx.input.pausePressed()) {
        ctx.audio.play(Sfx::UiBack);
        mgr.requestSwitch(SceneId::Menu);
        return;
    }

    accum_ += dt;
    int steps = 0;
    while (accum_ >= kFixed && steps < 8) {
        stepSim(ctx, kFixed);
        accum_ -= kFixed;
        ++steps;
    }

    // Door reached?
    if (!triggered_) {
        for (int i = 0; i < 2; ++i) {
            if (blobs_[i].position().z < doorZ_ + 2.4f) {
                triggered_ = true;
                blobs_[i].setEmote(Emote::Determined);
                ctx.audio.play(Sfx::DoorOpen);
                ctx.shake.add(0.3f);
            }
        }
    } else {
        triggerTimer_ += dt;
        // Suck both blobs toward the door for a beat, then switch.
        for (int i = 0; i < 2; ++i) {
            Vector3 p = blobs_[i].position();
            Vector3 toDoor = Vector3Subtract(
                Vector3{ 0, p.y, doorZ_ }, p);
            blobs_[i].setVelocity(Vector3Scale(Vector3Normalize(toDoor), 5.0f));
        }
        if (triggerTimer_ > 0.7f) {
            mgr.requestSwitch(matchDone_ ? SceneId::Results : SceneId::Match);
        }
    }

    ctx.shake.update(dt);
    ctx.particles.update(dt);
    ctx.camera.setTargets({ blobs_[0].position(), blobs_[1].position() });
    ctx.camera.update(dt, ctx.shake);
}

void HubScene::draw(GameContext& ctx) {
    // Pitch black. The hallway is a void; you see only what little light
    // there is. This is the Blobmare identity — a party game with dread.
    ClearBackground(Color{ 6, 5, 9, 255 });

    // The door does not cheerfully glow — it pulses a low, cold, uneasy light.
    // The final door is a colder white; a sudden-death door bleeds red.
    Color doorGlow;
    if (matchDone_)               doorGlow = Color{ 210, 200, 220, 255 };
    else if (ctx.match.isSuddenDeath &&
             ctx.match.index == (int)ctx.match.slate.size() - 1)
                                  doorGlow = Color{ 200, 60, 66, 255 };
    else                          doorGlow = Color{ 96, 110, 150, 255 };
    float glow = 0.32f + 0.16f * std::sin(time_ * 1.7f);   // slow, dim breath

    BeginMode3D(ctx.camera.cam());
    {
        ctx.lighting.setCamera(ctx.camera.eye());

        // Floor: barely-there. A dim checker fading instantly into black.
        prims::checkerFloor(Vector3{0,-0.06f,-4.0f}, 4.0f, 1.0f,
                            Color{16,14,22,255}, Color{11,10,16,255});

        // Hallway walls — almost invisible, just enough edge to feel enclosed.
        ctx.lighting.begin();
        for (int s = -1; s <= 1; s += 2) {
            prims::wall(Vector3{ s*kHallHalfW, 0, 8.0f },
                        Vector3{ s*kHallHalfW, 0, -16.0f },
                        6.0f, 0.5f, Color{18,16,24,255});
        }
        ctx.lighting.end();

        // Side doorways: pure black voids in the dark. You sense them more
        // than see them — uneasy shapes in the periphery.
        for (int z = 4; z >= -12; z -= 4) {
            for (int s = -1; s <= 1; s += 2) {
                prims::doorway(Vector3{ s*(kHallHalfW-0.05f), 0, (float)z },
                               1.8f, 2.8f, Color{22,20,30,255},
                               Color{3,3,5,255});
            }
        }

        // The ACTIVE door at the corridor end. Its frame is a dim outline;
        // the opening itself is a deep, almost-black portal with only a faint
        // uneasy shimmer — you genuinely cannot tell what waits beyond it.
        Color frame = Color{ (unsigned char)(doorGlow.r*0.30f),
                             (unsigned char)(doorGlow.g*0.30f),
                             (unsigned char)(doorGlow.b*0.34f), 255 };
        Color inner = Color{ (unsigned char)(doorGlow.r*glow),
                             (unsigned char)(doorGlow.g*glow),
                             (unsigned char)(doorGlow.b*glow), 255 };
        prims::doorway(Vector3{ 0, 0, doorZ_ }, 3.0f, 4.0f, frame, inner);

        // A faint, narrow spill of light on the floor before the door — the
        // only thing guiding the blobs forward through the dark.
        DrawCylinder(Vector3{0,0.02f,doorZ_+1.6f}, 0.25f, 2.2f, 0.04f, 24,
                     Color{inner.r,inner.g,inner.b,40});

        // Blobs.
        for (auto& b : blobs_) b.draw(ctx.lighting, accum_ / kFixed);

        ctx.lighting.begin();
        ctx.particles.draw();
        ctx.lighting.end();
    }
    EndMode3D();

    // --- HUD --------------------------------------------------------------
    int cx = ctx.screenW / 2;

    // Score pills, top corners.
    for (int i = 0; i < 2; ++i) {
        float bx = (i == 0) ? 40.0f : ctx.screenW - 280.0f;
        Rectangle pill{ bx, 30, 240, 64 };
        ui::panelBox(pill, ui::panel(), ctx.config.playerColor[i]);
        DrawCircle((int)bx + 38, 62, 20, ctx.config.playerColor[i]);
        DrawText(ctx.config.playerName[i], (int)bx + 70, 42, 24, ui::ink());
        DrawText(TextFormat("%d", ctx.match.score[i]),
                 (int)bx + 190, 38, 40, ui::accent());
    }

    // Next-up banner — deliberately NO minigame name. The whole point of the
    // dark hallway is that you do not know what is behind the door.
    if (matchDone_) {
        ui::centerTextShadow("the final door", cx, 40, 34,
                             Color{210,200,220,255});
        ui::centerText("walk through to see who survived the Blobmare", cx, 84,
                       20, ui::inkDim());
    } else if (ctx.match.hasMoreMinigames()) {
        bool tiebreak = ctx.match.isSuddenDeath &&
            ctx.match.index == (int)ctx.match.slate.size() - 1;
        if (tiebreak) {
            ui::centerTextShadow("SUDDEN DEATH", cx, 36, 38, ui::danger());
            ui::centerText("one more door. winner takes the match.",
                           cx, 82, 20, ui::inkDim());
        } else {
            // A cryptic line instead of the minigame's name.
            static const char* kOminous[] = {
                "something waits behind the door",
                "you cannot see what comes next",
                "the door does not say what it holds",
                "step through. find out.",
            };
            int which = ctx.match.index % 4;
            ui::centerTextShadow("THE NEXT DOOR", cx, 40, 32,
                                 Color{150,160,200,255});
            ui::centerText(kOminous[which], cx, 82, 20, ui::inkDim());
        }
        ui::centerText(TextFormat("door %d of %d",
                                  ctx.match.index + 1,
                                  (int)ctx.match.slate.size()),
                       cx, 108, 18, ui::inkDim());
    }

    if (!triggered_) {
        float p = ui::pulse(2.4f);
        Color c = Color{150,160,200,255};
        c.a = (unsigned char)(90 + 110 * p);
        ui::centerText("walk into the dark", cx, ctx.screenH - 70, 24, c);
    }

    // A heavy vignette — the dark presses in from every edge.
    ui::vignette(ctx.screenW, ctx.screenH, 1.0f);
}
