#pragma once
// The Hub: a dim, doorway-lined hallway. Between minigames the two blobs walk
// here together; the next minigame's door glows at the end of the corridor.
// Both blobs must reach the glowing door (or any blob touches it) to begin.
// This is the connective tissue that makes a "match" feel like a journey
// through a Blobmare rather than a menu list.
#include "game/Scene.h"
#include "blob/Blob.h"
#include "physics/World.h"
#include <vector>

class HubScene : public Scene {
public:
    void enter(GameContext& ctx, SceneManager& mgr) override;
    void update(GameContext& ctx, SceneManager& mgr, float dt) override;
    void draw(GameContext& ctx) override;

private:
    World  world_;
    Blob   blobs_[2];
    float  accum_ = 0.0f;
    float  time_  = 0.0f;
    float  doorZ_ = -14.0f;     // z of the active door
    bool   triggered_ = false;
    float  triggerTimer_ = 0.0f;
    bool   matchDone_ = false;  // true -> next door leads to Results

    void buildHallway(GameContext& ctx);
    void stepSim(GameContext& ctx, float dt);
};
