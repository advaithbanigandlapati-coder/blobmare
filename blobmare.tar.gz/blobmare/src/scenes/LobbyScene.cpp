#include "scenes/LobbyScene.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "net/NetSession.h"
#include "net/Transport.h"
#include "net/UdpTransport.h"
#include "game/MinigameRegistry.h"
#include "raylib.h"
#include <cmath>
#include <cctype>

using namespace net;

namespace { constexpr uint16_t kDefaultPort = 41730; }

void LobbyScene::enter(GameContext& ctx, SceneManager& mgr) {
    (void)mgr;
    row_ = 0;
    phase_ = Phase::Choosing;
    time_ = 0.0f;
    connectTimer_ = 0.0f;
    status_.clear();
    port_ = kDefaultPort;
    ctx.audio.setMusic(Audio::Music::Hub);
}

void LobbyScene::exit(GameContext& ctx) {
    (void)ctx;
    // On a successful hand-off ctx.net owns the live session; nothing to free.
}

bool LobbyScene::rowEnabled(Row) const {
    return true;   // all modes are now available
}

// --- Session starters -------------------------------------------------------

void LobbyScene::startLoopbackSession(GameContext& ctx) {
    LoopbackTransport *hT, *cT;
    LoopbackTransport::Sim sim;
    sim.latencyMs = 25.0f; sim.jitterMs = 5.0f;
    LoopbackTransport::makePair(hT, cT, sim);

    SessionConfig cfg;
    cfg.matchSeed = (uint32_t)(GetTime() * 1000.0) ^ 0x9E3779B9u;
    cfg.minigameCount = (uint8_t)ctx.config.minigameCount;
    cfg.roundsToWin   = (uint8_t)ctx.config.roundsToWin;

    hostSession_   = std::make_shared<NetSession>();
    clientSession_ = std::make_shared<NetSession>();
    hostSession_->begin(std::unique_ptr<Transport>(hT), cfg);
    clientSession_->begin(std::unique_ptr<Transport>(cT), SessionConfig{});

    ctx.net.beginNetworked(hostSession_);
    ctx.net.attachLoopbackPartner(clientSession_);
}

void LobbyScene::startUdpHost(GameContext& ctx) {
    auto udp = std::make_unique<UdpTransport>();
    if (!udp->startHost(port_)) {
        status_ = udp->lastError();
        phase_ = Phase::Failed;
        return;
    }
    SessionConfig cfg;
    cfg.matchSeed = (uint32_t)(GetTime() * 1000.0) ^ 0x9E3779B9u;
    cfg.minigameCount = (uint8_t)ctx.config.minigameCount;
    cfg.roundsToWin   = (uint8_t)ctx.config.roundsToWin;

    hostSession_ = std::make_shared<NetSession>();
    hostSession_->begin(std::move(udp), cfg);
    clientSession_.reset();                 // no in-process partner over UDP
    ctx.net.beginNetworked(hostSession_);

    phase_ = Phase::Hosting;
    connectTimer_ = 0.0f;
    status_ = TextFormat("listening on UDP port %d", (int)port_);
}

void LobbyScene::startUdpJoin(GameContext& ctx) {
    auto udp = std::make_unique<UdpTransport>();
    if (!udp->startClient(ipInput_, port_)) {
        status_ = udp->lastError();
        phase_ = Phase::Failed;
        return;
    }
    hostSession_ = std::make_shared<NetSession>();
    hostSession_->begin(std::move(udp), SessionConfig{});  // client role
    clientSession_.reset();
    ctx.net.beginNetworked(hostSession_);

    phase_ = Phase::Connecting;
    connectTimer_ = 0.0f;
    status_ = TextFormat("connecting to %s:%d ...", ipInput_.c_str(),
                         (int)port_);
}

// --- Menu confirm -----------------------------------------------------------

void LobbyScene::onConfirm(GameContext& ctx, SceneManager& mgr) {
    switch ((Row)row_) {
        case Row::LocalPlay:
            ctx.audio.play(Sfx::UiSelect);
            ctx.net.beginLocal();
            ctx.match.reset();
            mgr.requestSwitch(SceneId::Hub);
            break;
        case Row::NetLoopback:
            ctx.audio.play(Sfx::UiSelect);
            startLoopbackSession(ctx);
            phase_ = Phase::Connecting;
            connectTimer_ = 0.0f;
            status_ = "establishing local session...";
            break;
        case Row::HostOnline:
            ctx.audio.play(Sfx::UiSelect);
            startUdpHost(ctx);
            break;
        case Row::JoinOnline:
            ctx.audio.play(Sfx::UiSelect);
            phase_ = Phase::EnterIp;       // type the IP first
            status_.clear();
            break;
        case Row::Back:
            ctx.audio.play(Sfx::UiBack);
            mgr.requestSwitch(SceneId::Menu);
            break;
        case Row::COUNT: break;
    }
}

// --- Handshake pumping ------------------------------------------------------

void LobbyScene::pumpHandshake(GameContext& ctx, SceneManager& mgr, float dt) {
    float dtMs = dt * 1000.0f;
    if (hostSession_)   hostSession_->update(dtMs);
    if (clientSession_) clientSession_->update(dtMs);
    connectTimer_ += dt;

    bool ready = false;
    if (clientSession_) {
        // Loopback: both ends must connect.
        ready = hostSession_ &&
                hostSession_->state()   == SessionState::Connected &&
                clientSession_->state() == SessionState::Connected;
    } else {
        // UDP: just the local session.
        ready = hostSession_ &&
                hostSession_->state() == SessionState::Connected;
    }

    if (ready) {
        phase_ = Phase::Ready;
        status_ = "connected";
        ctx.audio.play(Sfx::Powerup);
        // Adopt the negotiated config + seed (host's config wins).
        ctx.config.minigameCount = hostSession_->config().minigameCount;
        ctx.config.roundsToWin   = hostSession_->config().roundsToWin;
        ctx.match.reset();
        ctx.match.seed = hostSession_->config().matchSeed;
        ctx.match.slate = MinigameRegistry::instance()
            .drawSlate(ctx.config.minigameCount, ctx.match.seed);
        connectTimer_ = 0.0f;
        return;
    }
    // Timeouts: loopback is instant; UDP gets a real grace window.
    float limit = clientSession_ ? 5.0f : 20.0f;
    if (connectTimer_ > limit) {
        status_ = clientSession_ ? "local session failed"
                                 : "no connection — check IP / port / firewall";
        phase_ = Phase::Failed;
        ctx.net.end();
        hostSession_.reset();
        clientSession_.reset();
    }
    (void)mgr;
}

// --- Update -----------------------------------------------------------------

void LobbyScene::update(GameContext& ctx, SceneManager& mgr, float dt) {
    time_ += dt;
    Input& in = ctx.input;

    switch (phase_) {
        case Phase::Choosing: {
            int dy = in.navY();
            if (dy != 0) {
                row_ = (row_ + dy + (int)Row::COUNT) % (int)Row::COUNT;
                ctx.audio.play(Sfx::UiMove);
            }
            if (in.confirmPressed()) onConfirm(ctx, mgr);
            if (in.cancelPressed()) {
                ctx.audio.play(Sfx::UiBack);
                mgr.requestSwitch(SceneId::Menu);
            }
        } break;

        case Phase::EnterIp: {
            // Text entry: digits and dots, backspace, enter to connect.
            int c = GetCharPressed();
            while (c > 0) {
                if (((c >= '0' && c <= '9') || c == '.')
                    && ipInput_.size() < 15) {
                    ipInput_ += (char)c;
                }
                c = GetCharPressed();
            }
            if (IsKeyPressed(KEY_BACKSPACE) && !ipInput_.empty())
                ipInput_.pop_back();
            if (in.confirmPressed() && !ipInput_.empty()) {
                ctx.audio.play(Sfx::UiSelect);
                startUdpJoin(ctx);
            }
            if (in.cancelPressed()) {
                ctx.audio.play(Sfx::UiBack);
                phase_ = Phase::Choosing;
            }
        } break;

        case Phase::Hosting: {
            // Pump until a client connects.
            pumpHandshake(ctx, mgr, dt);
            if (in.cancelPressed()) {
                ctx.audio.play(Sfx::UiBack);
                ctx.net.end();
                hostSession_.reset();
                phase_ = Phase::Choosing;
            }
        } break;

        case Phase::Connecting: {
            pumpHandshake(ctx, mgr, dt);
        } break;

        case Phase::Ready: {
            connectTimer_ += dt;
            if (connectTimer_ > 1.2f || in.confirmPressed())
                mgr.requestSwitch(SceneId::Hub);
        } break;

        case Phase::Failed: {
            if (in.confirmPressed() || in.cancelPressed()) {
                ctx.audio.play(Sfx::UiBack);
                phase_ = Phase::Choosing;
            }
        } break;
    }
}

// --- Draw -------------------------------------------------------------------

void LobbyScene::draw(GameContext& ctx) {
    ClearBackground(ui::bg());
    int cx = ctx.screenW / 2;

    ui::centerTextShadow("MULTIPLAYER", cx, 64, 56, ui::accent());

    if (phase_ == Phase::Choosing) {
        ui::centerText("Blobmare is best with a friend", cx, 126, 20,
                       ui::inkDim());
        struct RD { Row r; const char* label; const char* hint; };
        const RD rows[] = {
            { Row::LocalPlay,   "Local 2P",
              "two players, one screen" },
            { Row::NetLoopback, "Networked Match (self-test)",
              "runs the full net path in one process" },
            { Row::HostOnline,  "Host Online",
              "bind a port, wait for a friend to join" },
            { Row::JoinOnline,  "Join Online",
              "enter a host's IP address" },
            { Row::Back,        "Back", "" },
        };
        const int baseY = 210, rowH = 74;
        for (const auto& rd : rows) {
            int y = baseY + (int)rd.r * rowH;
            bool sel = (row_ == (int)rd.r);
            if (sel) {
                float p = 0.5f + 0.5f * std::sin(time_ * 6.0f);
                Rectangle hl{ cx - 340.0f, (float)y - 10, 680.0f, 60.0f };
                Color hc = ui::accent(); hc.a = (unsigned char)(40 + 50 * p);
                ui::panelBox(hl, hc, ui::accent());
                DrawText(">", cx - 322, y, 30, ui::accent());
            }
            DrawText(rd.label, cx - 280, y, 30,
                     sel ? ui::ink() : ui::inkDim());
            DrawText(rd.hint, cx - 280, y + 33, 16, ui::inkDim());
        }
    } else if (phase_ == Phase::EnterIp) {
        Rectangle box{ cx - 280.0f, 230.0f, 560.0f, 220.0f };
        ui::panelBox(box, ui::panel(), ui::accent());
        ui::centerText("ENTER HOST IP", cx, 258, 30, ui::accent());
        // The IP field.
        Rectangle field{ cx - 200.0f, 320.0f, 400.0f, 52.0f };
        ui::panelBox(field, Color{20,18,30,255}, ui::accent2());
        const char* shown = TextFormat("%s%s", ipInput_.c_str(),
            (std::fmod(time_, 1.0f) < 0.5f) ? "_" : " ");
        ui::centerText(shown, cx, 334, 30, ui::ink());
        ui::centerText(TextFormat("port %d  -  type digits and dots, Enter to connect",
                       (int)port_), cx, 396, 16, ui::inkDim());
        ui::centerText("Esc to go back", cx, 420, 16, ui::inkDim());
    } else {
        // Hosting / Connecting / Ready / Failed status panel.
        Rectangle box{ cx - 280.0f, 270.0f, 560.0f, 180.0f };
        ui::panelBox(box, ui::panel(),
                     phase_ == Phase::Failed ? ui::danger() : ui::accent());
        Color sc = ui::ink();
        if (phase_ == Phase::Ready)  sc = ui::accent2();
        if (phase_ == Phase::Failed) sc = ui::danger();
        ui::centerText(status_.c_str(), cx, 312, 22, sc);

        if (phase_ == Phase::Hosting || phase_ == Phase::Connecting) {
            for (int i = 0; i < 8; ++i) {
                float a = time_ * 4.0f + i * (2.0f * PI / 8.0f);
                float fade = (float)i / 8.0f;
                DrawCircle(cx + (int)(std::cos(a) * 26),
                           376 + (int)(std::sin(a) * 26),
                           5.0f, Color{255,196,92,(unsigned char)(60+180*fade)});
            }
            if (phase_ == Phase::Hosting)
                ui::centerText("waiting for a player to join...", cx, 412,
                               16, ui::inkDim());
        } else if (phase_ == Phase::Ready) {
            float p = ui::pulse(3.0f);
            Color c = ui::ink(); c.a = (unsigned char)(120 + 135 * p);
            ui::centerText("entering the hallway...", cx, 378, 20, c);
        } else if (phase_ == Phase::Failed) {
            ui::centerText("press any key to go back", cx, 392, 18,
                           ui::inkDim());
        }
    }

    ui::vignette(ctx.screenW, ctx.screenH, 0.7f);
}
