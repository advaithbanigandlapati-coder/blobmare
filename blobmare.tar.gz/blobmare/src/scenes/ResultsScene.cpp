#include "scenes/ResultsScene.h"
#include "core/GameContext.h"
#include "core/UIText.h"
#include "render/Prims.h"
#include "raymath.h"
#include <cmath>

namespace {
constexpr float kFixed = 1.0f / 120.0f;
}

void ResultsScene::enter(GameContext& ctx, SceneManager& mgr) {
    (void)mgr;
    time_ = 0.0f;
    accum_ = 0.0f;
    row_ = 0;
    confettiTimer_ = 0.0f;

    winner_ = ctx.match.leader();
    tie_ = (winner_ < 0);

    world_.clear();
    world_.setGravity(Vector3{ 0, -26, 0 });
    world_.setGround(0.0f);
    world_.setKillY(-30.0f);
    // Podium blocks: winner stands higher.
    world_.addBox(phys::makeBox(Vector3{ -1.8f, 0.5f, 0 }, Vector3{ 1.0f, 0.5f, 1.0f }));
    world_.addBox(phys::makeBox(Vector3{  1.8f, 0.5f, 0 }, Vector3{ 1.0f, 0.5f, 1.0f }));

    for (int i = 0; i < 2; ++i) {
        blobs_[i].init(i, ctx.config.playerColor[i], ctx.config.playerSize[i]);
        float h = 1.0f;
        // Winner podium is taller.
        if (!tie_ && i == winner_) {
            world_.addBox(phys::makeBox(Vector3{ (i==0?-1.8f:1.8f), 1.3f, 0 },
                                        Vector3{ 1.0f, 0.3f, 1.0f }));
            h = 2.3f;
        }
        blobs_[i].respawn(Vector3{ (i==0?-1.8f:1.8f), h + 0.8f, 0 });
        if (tie_)               blobs_[i].setEmote(Emote::Neutral);
        else if (i == winner_)  blobs_[i].setEmote(Emote::Happy);
        else                    blobs_[i].setEmote(Emote::Dizzy);
    }

    ctx.camera.init();
    ctx.camera.clearStaticShot();
    ctx.camera.setStaticShot(Vector3{ 0.0f, 4.2f, 9.5f },
                             Vector3{ 0.0f, 2.0f, 0.0f });
    ctx.camera.snap();

    ctx.audio.setMusic(Audio::Music::Results);
    ctx.audio.play(tie_ ? Sfx::Lose : Sfx::Win);
    ctx.particles.clear();
}

void ResultsScene::update(GameContext& ctx, SceneManager& mgr, float dt) {
    time_ += dt;

    accum_ += dt;
    int steps = 0;
    while (accum_ >= kFixed && steps < 8) {
        for (int i = 0; i < 2; ++i) {
            PlayerInput idle{};
            // The winner hops for joy.
            if (!tie_ && i == winner_ &&
                std::fmod(time_, 1.1f) < kFixed) {
                idle.jump = idle.jumpPressed = true;
            }
            blobs_[i].control(idle, kFixed, true, true);
            blobs_[i].integrate(world_, kFixed);
            if (!blobs_[i].alive())
                blobs_[i].respawn(Vector3{ (i==0?-1.8f:1.8f), 3.0f, 0 });
        }
        accum_ -= kFixed; ++steps;
    }

    // Periodic confetti over the winner.
    confettiTimer_ -= dt;
    if (!tie_ && confettiTimer_ <= 0.0f) {
        confettiTimer_ = 0.9f;
        Vector3 wp = blobs_[winner_].position();
        ctx.particles.confetti(Vector3{ wp.x, wp.y + 3.0f, wp.z }, 40);
        ctx.audio.play(Sfx::Pop, 0.4f, 0.2f);
    }

    ctx.shake.update(dt);
    ctx.particles.update(dt);
    ctx.camera.update(dt, ctx.shake);

    int dy = ctx.input.navY();
    if (dy != 0) { row_ = (row_ + 1) & 1; ctx.audio.play(Sfx::UiMove); }

    if (ctx.input.confirmPressed()) {
        ctx.audio.play(Sfx::UiSelect);
        if (row_ == 0) {
            // Rematch: clear the slate so the Hub draws a fresh one.
            ctx.match.reset();
            mgr.requestSwitch(SceneId::Hub);
        } else {
            ctx.match.reset();
            mgr.requestSwitch(SceneId::Menu);
        }
    }
    if (ctx.input.cancelPressed()) {
        ctx.audio.play(Sfx::UiBack);
        ctx.match.reset();
        mgr.requestSwitch(SceneId::Menu);
    }
}

void ResultsScene::draw(GameContext& ctx) {
    ClearBackground(ui::bg());

    BeginMode3D(ctx.camera.cam());
    {
        ctx.lighting.setCamera(ctx.camera.eye());
        prims::checkerFloor(Vector3{0,-0.06f,0}, 6.0f, 1.0f,
                            Color{34,30,46,255}, Color{27,24,38,255});
        prims::groundGrid(Vector3{0,0.01f,0}, 16.0f, 1.0f, Color{70,64,92,80});

        // Podiums.
        for (int i = 0; i < 2; ++i) {
            float x = (i==0?-1.8f:1.8f);
            float h = (!tie_ && i==winner_) ? 1.6f : 1.0f;
            Color top = ctx.config.playerColor[i];
            prims::platform(Vector3{ x, h, 0 }, 2.0f, 2.0f, h,
                            Color{ (unsigned char)(top.r*0.5f),
                                   (unsigned char)(top.g*0.5f),
                                   (unsigned char)(top.b*0.5f), 255 },
                            top);
        }
        // Spotlight pillars behind.
        prims::pillar(Vector3{-4.5f,0,-2.5f}, 0.4f, 5.0f, Color{40,36,54,255});
        prims::pillar(Vector3{ 4.5f,0,-2.5f}, 0.4f, 5.0f, Color{40,36,54,255});

        for (auto& b : blobs_) b.draw(ctx.lighting, accum_ / kFixed);

        ctx.lighting.begin();
        ctx.particles.draw();
        ctx.lighting.end();
    }
    EndMode3D();

    // --- HUD --------------------------------------------------------------
    int cx = ctx.screenW / 2;
    float bob = std::sin(time_ * 2.0f) * 5.0f;

    if (tie_) {
        ui::centerTextShadow("A DRAW", cx, 50 + (int)bob, 76, ui::inkDim());
        ui::centerText("the Blobmare claims no champion", cx, 134, 24,
                       ui::inkDim());
    } else {
        ui::centerTextShadow(
            TextFormat("%s SURVIVES THE BLOBMARE",
                       ctx.config.playerName[winner_]),
            cx, 46 + (int)bob, 52, ctx.config.playerColor[winner_]);
        ui::centerText("champion of the hallway", cx, 116, 24, ui::ink());
    }

    // Final score panel.
    Rectangle box{ cx - 220.0f, 170.0f, 440.0f, 110.0f };
    ui::panelBox(box, ui::panel(), ui::accent());
    for (int i = 0; i < 2; ++i) {
        int x = (i==0) ? cx - 150 : cx + 60;
        DrawCircle(x, 210, 22, ctx.config.playerColor[i]);
        DrawText(ctx.config.playerName[i], x + 34, 196, 22, ui::ink());
        DrawText(TextFormat("%d", ctx.match.score[i]), x + 34, 222, 36,
                 ui::accent());
    }
    ui::centerText("-", cx, 200, 40, ui::inkDim());

    // Menu rows.
    const char* opts[2] = { "REMATCH  (new random slate)", "back to menu" };
    for (int i = 0; i < 2; ++i) {
        int y = 360 + i * 64;
        bool sel = (row_ == i);
        if (sel) {
            float p = 0.5f + 0.5f * std::sin(time_ * 6.0f);
            Rectangle hl{ cx - 240.0f, (float)y - 8, 480.0f, 52.0f };
            Color hc = ui::accent(); hc.a = (unsigned char)(40 + 50 * p);
            ui::panelBox(hl, hc, ui::accent());
        }
        ui::centerText(opts[i], cx, y, 30, sel ? ui::accent() : ui::inkDim());
    }

    ui::vignette(ctx.screenW, ctx.screenH, 0.85f);
}
