# Blobmare Netcode — Design & Staged Build Plan

This document is the engineering roadmap for Blobmare's network play and
proximity voice chat. It records what is **built and tested**, what is
**designed but not yet built**, and exactly how the remaining stages slot in.

---

## Why staged

Networking is the one domain where untested code is reliably, subtly broken.
A single development environment cannot validate real netcode — that needs two
machines with genuine latency and loss. So Blobmare's netcode is built in
stages, each independently testable, with a clear honest line between
"verified" and "needs hardware".

---

## Architecture overview

Blobmare uses a **client–server model** with a **deterministic fixed-step
simulation** (1/120 s). One peer is the **host** (authoritative); the other is
a **client**.

```
            HOST (authoritative)                 CLIENT
   ┌────────────────────────────┐    ┌────────────────────────────┐
   │ sample local input         │    │ sample local input         │
   │ recv client input  ◄───────┼────┤ send input ───────────────►│
   │ step authoritative sim     │    │ predict local blob         │
   │ send snapshot ────────────►┼────┤ recv snapshot, apply remote │
   └────────────────────────────┘    └────────────────────────────┘
```

The layering, bottom to top:

| Layer            | File                | Status |
|------------------|---------------------|--------|
| Wire types       | `net/NetTypes.*`    | **Built + tested** |
| Transport iface  | `net/Transport.*`   | **Built + tested** (Loopback) |
| Session protocol | `net/NetSession.*`  | **Built + tested** |
| Game bridge      | `net/NetPlay.*`     | **Built + tested** |
| Lobby UI         | `scenes/LobbyScene.*`| **Built** |
| UDP transport    | `net/UdpTransport.*`| **Built + tested** (localhost + 2-process) |
| Client prediction| `net/ClientPredictor.*` | **Built + tested** |
| Proximity VC     | `net/VoiceChat.*` + `RtMicSource` | **Built**; real-mic audio quality needs hardware |

---

## What is built and verified

### Wire format (`NetTypes`)
Fixed-layout little-endian packing via `ByteWriter`/`ByteReader`. No struct
`memcpy` — the protocol is stable across compilers and architectures. Readers
bounds-check and set an error flag; a truncated packet fails safely instead of
reading out of bounds.

`InputCommand` is **7 bytes** (tick + 2 axes + button bitfield). `Snapshot` is
**86 bytes** (tick, per-player input acks, two blob states, match context).
Both are tiny — well within a single UDP datagram with room to spare.

*Tested by `nettest1`*: round-trip equality, truncation safety.

### Transport (`Transport` + `LoopbackTransport`)
An opaque-packet interface. `LoopbackTransport` connects two peers in one
process and **simulates latency, jitter, and packet loss** — it is a real test
rig, not a stub. The UDP transport will implement the identical interface, so
no layer above changes.

*Tested by `nettest1`*: synchronous delivery, latency gating.

### Session protocol (`NetSession`)
The protocol state machine: `Disconnected → Handshaking → Connected`.
Handles handshake (`Hello`/`Welcome`), input upload, snapshot broadcast,
keep-alive ping/pong, and graceful `Bye`.

Two robustness features:
- **Input redundancy**: each input packet carries the last 3 commands. A
  single dropped packet does not stall the host; it de-duplicates by tick.
- **Input extrapolation**: if the host is missing a remote input for a tick,
  it reuses that player's last known command, masking brief loss.

*Tested by `nettest2`* (6 tests): handshake, input flow, snapshot flow, input
acknowledgement, a **120-tick run under 80 ms latency + 15 ms jitter + 10 %
packet loss** (host recovered 120/120 input ticks via redundancy), and
graceful disconnect.

### Game bridge (`NetPlay`)
Converts between the game's `PlayerInput`/`Blob` and the wire
`InputCommand`/`Snapshot`. Three modes: `Local` (offline — netcode entirely
bypassed, the original game is provably unchanged), `Host`, `Client`.

The integration seam is a single point in `MatchScene::stepSim()`:
`sampleAndSync()` → blobs read `inputForBlob()` → host `captureAndPublish()` /
client `applyLatestSnapshot()` → `advanceTick()`.

*Tested by `nettest3`*: two full game simulations (host + client), each
running real blobs and physics, kept in sync across a 40 ms-latency loopback
link for 600 ticks — **15/15 sync checks within tolerance**. Also verified
through the real scene system (`netmatch`): 2550 sim ticks of a networked
match, both sessions Connected throughout.

### Lobby (`LobbyScene`)
Entry point to multiplayer. `Local 2P` and `Networked Match` (loopback) are
live; `Host Online` / `Join Online` are shown disabled until the UDP stage.

---

## Stage 2 — UDP transport  ✅ DONE

`net/UdpTransport.{h,cpp}` implements the `Transport` interface with real,
non-blocking BSD/Winsock UDP sockets. Nothing above it changed — `NetSession`,
`NetPlay`, and the scenes are identical whether the transport is loopback or
UDP.

**What it does:**
- Host binds a UDP port (`SO_REUSEADDR`, non-blocking) and learns the client's
  address from its first datagram. Client opens a socket toward a host
  `ip:port`; the OS assigns the ephemeral local port.
- `poll()` drains the OS receive buffer into an inbox each call (bounded).
- Datagrams capped at 1400 bytes — safely under typical MTU. The 7-byte input
  and 86-byte snapshot are far within this.

**Verified in this environment:**
- Raw bidirectional datagrams on `127.0.0.1`.
- The full `NetSession` protocol (handshake, input, snapshots) over real UDP
  sockets — `udptest`.
- **Two separate OS processes** communicating over UDP — `udppeer host` and
  `udppeer client` as independent processes: 434 sim ticks exchanged with
  100% input and snapshot delivery.

**Bug found and fixed by the two-process test:** when the client process
started *before* the host, its first `Hello` datagram was lost (nothing bound
yet) and the handshake stalled forever. Fix: the client now retransmits
`Hello` 4×/second while in `Handshaking` until a `Welcome` arrives. Re-tested
in reversed start order — connects cleanly. This is exactly the class of bug
that only real testing surfaces.

**Lobby:** `Host Online` and `Join Online` are now live. Join shows an IP
text-entry field. Default port 41730.

**Still needs two physical machines to verify** (cannot be done in one
environment): NAT traversal, real internet latency/jitter/reordering, firewall
behaviour. Localhost + cross-process prove the *code*; only two machines prove
the *network path*. To test: one player picks Host Online, the other picks
Join Online and enters the host's IP. Same LAN works directly; over the
internet the host must port-forward UDP 41730. Use `tc netem` (Linux) or
`clumsy` (Windows) to inject artificial loss and confirm the redundancy +
extrapolation hold on real sockets.

## Stage 3 — Client-side prediction & reconciliation  ✅ DONE

`net/ClientPredictor.{h,cpp}` implements standard client-side prediction with
reconciliation for the local player's blob.

**How it works:** every tick the client records its predicted local-blob state
and the input used, in a 256-frame ring. When a host snapshot for tick T
arrives, the predictor compares the authoritative local state against its
recorded prediction for T. If they diverge past a threshold (0.04 u), it snaps
an internal cursor to the authoritative state and **re-simulates** ticks
T+1..now from the buffered inputs — producing a corrected "now". The visible
blob then eases toward the correction over ~100 ms (a slide, not a teleport);
corrections too large to ease are snapped.

**Verified** (`predtest`, deterministic — no network needed):
- Accurate prediction → zero correction (no needless re-sim).
- A 1.0-unit host/client divergence → re-simulated 30 ticks, corrected "now"
  matched an independently-computed true path to 0.00000 error.
- Re-simulation is bit-identical across runs (determinism).

**Verified in a real match** (`predmatch`): host + client running real
minigame sims over loopback with 50 ms latency + 12 ms jitter for 900 ticks —
the client's predicted-and-reconciled blob tracked the host's authoritative
truth with 0.30 u worst-case drift, 0.20 u average. Without reconciliation
that drift grows unbounded.

Integrated into `NetPlay` + `MatchScene`: the predictor binds the active
minigame's `World` at setup, records each tick, and reconciles inside
`applyLatestSnapshot`. The render offset is applied cosmetically to the local
blob only.

## Stage 4 — Proximity voice chat  ✅ BUILT  (real-mic audio quality needs hardware)

`net/VoiceChat.{h,cpp}` implements the full proximity-VC pipeline:

```
capture (mic) -> encode -> VoiceFrame packet -> [network]
              -> decode -> proximity attenuation -> mix -> playback
```

**Built and verified** (no hardware needed — `voicetest`, `voicenet`):
- **Codec**: 20 ms / 16 kHz mono frames (320 samples), mu-law-style companding
  to 8-bit — dependency-free, ~50% of raw PCM, round-trip RMS error 0.006
  (intelligible-grade).
- **Capture interface**: `MicSource` is abstract. `SyntheticMicSource` emits a
  test tone so the whole pipeline runs headless and is verifiable.
- **Transport**: voice frames go in `MsgType::VoiceFrame` packets over the
  *existing* `NetSession`/transport — verified traversing a loopback link
  (200 frames sent, 199 received, bidirectional).
- **Proximity attenuation**: remote voice gain is a cosine falloff over the
  in-world blob distance — full volume within ~1/4 range, silent past the max
  hearing range. Verified: gain 1.00 adjacent → 0.61 at 8 m → 0.00 at 14 m.
- **Playback**: decoded, attenuated audio is streamed via a raylib
  `AudioStream`. Integrated into `NetPlay`/`MatchScene`: a networked match
  brings up voice automatically and drives proximity from blob distance.

**Real microphone capture — BUILT.** `net/RtMicSource.{h,cpp}` is the
production `MicSource`, backed by `miniaudio` (vendored in `third_party/`,
public domain). It opens the system default capture device, bridges
miniaudio's audio-thread callback to the game thread through a lock-free-ish
ring buffer, and resamples the device's native rate to the codec's 16 kHz.
A networked match uses `RtMicSource` automatically and falls back to the
synthetic source if no microphone is present or permission is denied.

Note: raylib already embeds its own miniaudio internally; `RtMicSource.cpp`
defines `MA_API` as `static` so its miniaudio copy is translation-unit-local
and does not clash at link time.

**Verified here:** builds clean, integrates, and the graceful-failure /
clean-shutdown paths are tested (`mictest`) — no crash whether a device is
absent, present-but-silent, or working. **Still needs a real microphone on a
real machine** to judge the one thing hardware-in-the-loop testing alone can
confirm: actual captured-voice quality, latency feel, and echo.

**Codec upgrade path:** swapping the companding codec for **Opus** (link
`libopus`, ~24 kbps, encode/decode in `VoiceCodec`) would improve quality and
cut bandwidth. The interface is already shaped for it — only `VoiceCodec`'s
two functions change.


## Honest status line

- **Built & verified in this environment:** wire format, transport
  abstraction, session protocol, game bridge, lobby — proven by three test
  suites and an in-game networked-match run.
- **Built, needs two machines for final sign-off:** UDP transport — code
  verified localhost + cross-process; cross-machine play is the open item.
- **Voice chat fully built** — pipeline + real `RtMicSource` mic capture.
  Verified to build, integrate, and fail gracefully; real-voice audio
  quality is the last thing needing a microphone to confirm.

The hard part of netcode — a correct, loss-tolerant, deterministic protocol —
is done and tested. What remains is the transport and the voice pipeline, both
of which are hardware-in-the-loop by nature.
