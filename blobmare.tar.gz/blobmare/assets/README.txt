Blobmare uses fully procedural art and audio. This folder is intentionally near-empty; it exists so the game has a stable assets/ path next to the binary for any future drop-in files.
