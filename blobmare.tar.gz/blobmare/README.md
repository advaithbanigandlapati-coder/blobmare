# Blobmare

*A blob party nightmare.* A 3D local-multiplayer party game where two squishy
blobs journey through a dim, doorway-lined hallway, competing in a random
slate of minigames drawn from a large pool. First blob to the round target
survives the Blobmare.

Built in C++17 with [raylib](https://www.raylib.com/) 5.5. **Asset-free**: all
art is procedural 3D geometry and all audio is synthesised at startup, so the
repo is fully self-contained.

---

## Building

raylib is fetched and built automatically by CMake — you only need a C++17
compiler, CMake ≥ 3.16, and the usual OpenGL / X11 development headers.

```sh
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build
./build/blobmare
```

On Linux you may need the dev packages for OpenGL, X11 and ALSA
(`libgl1-mesa-dev libx11-dev libxrandr-dev libxinerama-dev libxcursor-dev
libxi-dev libasound2-dev`). raylib's docs list the macOS/Windows equivalents.

The project compiles **warning-free** under `-Wall -Wextra` with warnings as
errors for the game's own code.

---

## Controls

| Action | Player 1 (keyboard) | Player 2 (gamepad *or* keyboard) |
|--------|---------------------|----------------------------------|
| Move   | `W A S D`           | Left stick / D-pad — or arrow keys |
| Jump   | `Space`             | A button — or `Right Shift` / Numpad 0 |
| Action | `J` (or `F`)        | X button — or `Right Ctrl` / Numpad 2 |
| Dash   | `Left Shift` (or `K`)| B button / RT — or `Right Alt` / Numpad 1 |
| Pause  | `Esc` / `P`         | Start button |

A gamepad, if connected, is claimed by Player 2 automatically (hot-plug
aware). With no gamepad, Player 2 uses the arrow-key cluster.

The pause menu (`Esc`) has a settings page: music & SFX volume, fullscreen,
and a screen-shake toggle for accessibility.

---

## The blob

The blob is a real **soft-body jiggle mesh**. A UV sphere is deformed every
frame by a lattice of spring-coupled control points (three stacked rings):
acceleration sloshes it, landing splats it, jumps stretch it, hits dent it
directionally. It is a genuine mass-spring system — but a *safe* one: each
point's offset is hard-clamped and velocity-damped, so it physically cannot
explode, and it never touches collision (the rigid body stays a clean sphere).
Squash & stretch, googly tracking eyes, and an emoting mouth complete the look.

---

## Minigames

A match draws a random, non-repeating slate from the pool
(`MatchConfig::minigameCount`, default 5, adjustable on the menu). The registry
is **pool-size-agnostic** — adding a minigame is one new file plus one
`REGISTER_MINIGAME(...)` line.

This build ships **14 distinct, hand-tuned minigames** across all four win
conditions:

| Minigame | Kind | Hook |
|----------|------|------|
| Sumo Smash       | last standing | shove off a shrinking ring |
| Floor Is Lava    | last standing | rising lava, sinking platforms |
| Meteor Dodge     | last standing | dodge telegraphed meteors |
| Spin Sweep       | last standing | jump a rotating beam |
| Bounce Battle    | last standing | trampoline floor, no walls |
| Hot Potato       | last standing | pass the bomb before it blows |
| **The Hunt**     | survival      | an AI hunter stalks a maze |
| Safe Zone        | survival      | reach the safe patch before each sweep |
| Coin Rush        | high score    | grab the most coins |
| King of the Hill | high score    | hold the centre zone |
| Plate Panic      | high score    | claim glowing floor tiles |
| **Splat Arena**  | high score    | paint more floor than your rival |
| Dash Race        | first to goal | obstacle sprint |
| Tower Climb      | first to goal | vertical scramble |

**The Hunt** has a proper AI: an A* pathfinder over a nav grid, and a
Patrol → Investigate → Chase → Lunge state machine driven by a vision cone,
line-of-sight, and hearing (sprinting is loud). It is tuned to be tense but
fair — the hunter is slightly slower than a sprinting blob, but its lunge
briefly outpaces you.

**Splat Arena** is the only minigame with state that accumulates over the
whole round — a territory tug-of-war rather than a reflex test.

If the slate ends on a tied score, a **sudden-death** round is appended so the
match always produces a winner.

---

## Networking (in progress — see `docs/NETCODE.md`)

Blobmare is being extended with online play. The networking is built in
testable stages:

**Done and verified** (loopback-tested):
- Wire protocol, transport abstraction, full session protocol (handshake,
  input exchange, snapshots, reconciliation), and the game-integration bridge.
- Verified by three test suites including a 120-tick run under 80 ms latency +
  10 % packet loss, and an in-game networked match.
- A **Lobby** screen with Local and Networked (loopback) play.

**Designed, pending** (needs two machines to build/verify):
- Real UDP transport, client-side prediction smoothing, and proximity voice
  chat. The full plan is in `docs/NETCODE.md`.

`docs/NETCODE.md` is the authoritative roadmap for the remaining stages.

---

## Project layout

```
src/
  core/      shared services: input, audio, lighting, camera, UI, context
  fx/        easing, screen shake, particle system
  physics/   collision primitives + the static-collider World
  blob/      the Blob rigid body + its soft-body BlobMesh
  render/    shared stylised 3D drawing primitives
  ai/        NavGrid + A* pathfinding (used by The Hunt)
  net/       wire types, transport, session, game bridge
  game/      Scene framework, Minigame interface + registry, MatchState
  scenes/    Title / Menu / Lobby / Hub / Match / Results
  ui/        the pause menu + settings overlay
  minigames/ one file per minigame
  main.cpp   entry point
docs/
  NETCODE.md netcode design + staged build plan
```

---

## Notes & deliberate design decisions

* **Blob body is a sphere**, not the capsule some designs assume — the blob is
  a literal ball, and a sphere body is more robust and trivially deterministic
  against the world. Documented in `src/physics/Collision.h`.
* **Fixed-step sim** at 1/120 s; rendering interpolates for smooth motion at
  any frame rate. The determinism is also what makes the netcode tractable.
* **Verified**: compiles warning-free, boots cleanly, and headless test
  harnesses drive every minigame through a full lifecycle (all 14 resolve
  without stalling or crashing), the A* pathfinder, the netcode protocol, and
  the full scene flow. What automated tests cannot judge is *feel* — jump
  heights, AI tuning, timer lengths — those are sensible starting points and
  live as named constants for tuning with a controller in hand.

---

Built with raylib. No external assets.
